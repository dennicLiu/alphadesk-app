/* AlphaDesk 量化研究终端前端 (Vue 3 + Element Plus + ECharts, 全部本地 vendor, 无需外网CDN) */
/* eslint-disable */
const { createApp } = Vue;
const { ElMessage, ElMessageBox } = ElementPlus;

function licExpired(r) {
  // 私有化一机一码: 无账号体系, 402 = 授权失效, 弹窗激活
  if (r.status === 402 && window.__AD__) {
    window.__AD__.licenseDlg = true;
  }
}
const API = {
  async get(path) {
    const r = await fetch(path);
    if (r.status === 402) { licExpired(r); throw new Error("授权已到期, 请输入激活码"); }
    if (!r.ok) throw new Error(await errText(r));
    return r.json();
  },
  async _send(method, path, body) {
    const r = await fetch(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body !== undefined ? JSON.stringify(body) : null,
    });
    if (r.status === 402) { licExpired(r); throw new Error("授权已到期, 请输入激活码"); }
    if (!r.ok) throw new Error(await errText(r));
    return r.json();
  },
  post(path, body) { return this._send("POST", path, body); },
  put(path, body) { return this._send("PUT", path, body || {}); },
  del(path) { return this._send("DELETE", path, undefined); },
};
async function errText(r) {
  try {
    const j = await r.json();
    const d = j.detail ?? j.message ?? j;
    // 422 校验错误的 detail 是对象数组, 直接拼会显示 [object Object]
    const s = typeof d === "string" ? d : JSON.stringify(d);
    return s.slice(0, 300) || `HTTP ${r.status}`;
  } catch (e) {
    return `HTTP ${r.status}`;
  }
}

/* ---------- 协议文本(草稿, 律师终审前以上线版为准) ---------- */
const TERMS_HTML = `
<p><b>一、授权方式</b><br/>本软件为单机授权(一机一码)，激活码与本机机器码绑定，换电脑、重装系统或更换网卡需重新获取激活码。</p>
<p><b>二、试用与正式</b><br/>首次运行自动进入 7 天试用；试用到期或未激活时数据接口锁定，输入卖家提供的激活码即时解锁。</p>
<p><b>三、使用义务</b><br/>不得将激活码转售、批量激活；不得利用本产品从事内幕交易、操纵市场等违法行为。</p>
<p><b>四、免责</b><br/>行情数据来源于公开渠道，可能存在延迟或缺失；评分、选股与 AI 结论仅供学习研究，不构成投资建议。市场有风险，投资需谨慎。</p>`;const PRIVACY_HTML = `
<p><b>一、数据存储</b><br/>本软件为纯单机运行，所有数据（自选池、策略、分析记录）仅保存在本机 data 目录，不上传任何服务器。</p>
<p><b>二、无账号体系</b><br/>不注册、不登录、不收集手机号与个人信息；激活时仅校验本机机器码。</p>
<p><b>三、联网说明</b><br/>仅在拉取公开行情、AI 分析（需配置密钥）时联网；断网状态下本地已有数据仍可查看。</p>`;/* ---------- 纯前端指标计算(用于K线图叠加) ---------- */
function sma(arr, n) {
  const out = [];
  let s = 0;
  for (let i = 0; i < arr.length; i++) {
    s += arr[i];
    if (i >= n) s -= arr[i - n];
    out.push(i >= n - 1 ? +(s / n).toFixed(4) : null);
  }
  return out;
}
function ema(arr, n) {
  const k = 2 / (n + 1);
  const out = [];
  let prev = 0;
  for (let i = 0; i < arr.length; i++) {
    prev = i ? arr[i] * k + prev * (1 - k) : arr[i];
    out.push(+prev.toFixed(4));
  }
  return out;
}
function rsiCalc(closes, period) {
  const out = new Array(closes.length).fill(null);
  let avgGain = 0, avgLoss = 0;
  for (let i = 1; i < closes.length; i++) {
    const chg = closes[i] - closes[i - 1];
    const gain = Math.max(chg, 0), loss = Math.max(-chg, 0);
    if (i <= period) {
      avgGain += gain; avgLoss += loss;
      if (i === period) {
        avgGain /= period; avgLoss /= period;
        out[i] = avgLoss === 0 ? 100 : +(100 - 100 / (1 + avgGain / avgLoss)).toFixed(2);
      }
    } else {
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
      out[i] = avgLoss === 0 ? 100 : +(100 - 100 / (1 + avgGain / avgLoss)).toFixed(2);
    }
  }
  return out;
}
function macdCalc(closes) {
  const dif = closes.map((_, i) => +(ema(closes, 12)[i] - ema(closes, 26)[i]).toFixed(4));
  const dea = ema(dif, 9);
  const hist = dif.map((d, i) => +((d - dea[i]) * 2).toFixed(4));
  return { dif, dea, hist };
}
function fmtPctText(v) {
  if (v === null || v === undefined) return "-";
  return (v > 0 ? "+" : "") + (+v).toFixed(1) + "%";
}

// 轻量版多维共振(客户端兜底, 无快照时用K线实时计算; 完整版以后端 algo.confluence 为准)
function clientConfluence(klines) {
  const closes = klines.map((k) => k.close);
  const vols = klines.map((k) => k.volume);
  const close = closes[closes.length - 1];
  const bull = [], bear = [], neutral = [];
  const sig = (b, name, detail) => b.push({ name, detail, weight: 1 });
  const ma = (n) => sma(closes, n).at(-1);
  const above = ["ma5", "ma10", "ma20", "ma60"].map((n) => ma(+n.slice(2)))
    .filter((v) => v != null && close > v).length;
  const below = ["ma5", "ma10", "ma20", "ma60"].map((n) => ma(+n.slice(2)))
    .filter((v) => v != null && close < v).length;
  if (above === 4) bull.push({ name: "均线多头", detail: "站上全部均线", weight: 2 });
  else if (below === 4) bear.push({ name: "均线空头", detail: "跌破全部均线", weight: 2 });
  const m = macdCalc(closes);
  const dif = m.dif.at(-1), dea = m.dea.at(-1), hist = m.hist.at(-1);
  if (dif != null && dea != null) {
    if (dif > dea) bull.push({ name: "MACD多头", detail: "DIF>DEA", weight: 2 });
    else bear.push({ name: "MACD空头", detail: "DIF<DEA", weight: 2 });
  }
  if (hist != null) (hist > 0 ? bull : bear).push({ name: "MACD柱", detail: hist > 0 ? "红柱" : "绿柱", weight: 1 });
  const rsi12 = rsiCalc(closes, 12).at(-1);
  if (rsi12 != null) (rsi12 >= 50 ? bull : bear).push({ name: "RSI强弱", detail: "RSI12=" + rsi12.toFixed(0), weight: 1 });
  const kArr = klines.slice(-9).map((k) => k.low), hArr = klines.slice(-9).map((k) => k.high);
  const ll = Math.min(...kArr), hh = Math.max(...hArr);
  if (hh > ll) {
    const rsv = (close - ll) / (hh - ll) * 100;
    (rsv > 50 ? bull : bear).push({ name: "KDJ区间", detail: "RSV=" + rsv.toFixed(0), weight: 1 });
  }
  const v5 = sma(vols, 5).at(-1);
  if (v5 > 0) {
    const ratio = vols.at(-1) / v5;
    if (ratio >= 1.5) neutral.push({ name: "放量", detail: ratio.toFixed(1) + "倍于5日均量", weight: 1 });
    else if (ratio <= 0.6) neutral.push({ name: "缩量", detail: ratio.toFixed(1) + "倍于5日均量", weight: 1 });
  }
  const bw = bull.reduce((s, x) => s + x.weight, 0), rw = bear.reduce((s, x) => s + x.weight, 0);
  const ratio = Math.round(bw / (bw + rw || 1) * 1000) / 10;
  let level = "mixed", label = "多空分歧", dir = "→";
  if (bw >= 5 && ratio >= 60) { level = "bull"; label = "多头共振"; dir = "↑"; }
  else if (rw >= 5 && ratio <= 40) { level = "bear"; label = "空头共振"; dir = "↓"; }
  return { bull, bear, neutral, bull_count: bull.length, bear_count: bear.length,
           total: bull.length + bear.length + neutral.length,
           bull_weight: bw, bear_weight: rw, ratio, level, level_label: label, direction: dir };
}

const UP = "#ff5c6e", DOWN = "#00e5a0", FLAT = "#5f7191";

/* 科技暗色图表主题: 全站 7 处图表统一注册, 红涨绿跌保持 A 股惯例 */
if (typeof echarts !== "undefined") {
  echarts.registerTheme("tech", {
    backgroundColor: "transparent",
    textStyle: { color: "#9fb0c9", fontFamily: "inherit" },
    categoryAxis: {
      axisLine: { lineStyle: { color: "rgba(120,160,220,.25)" } },
      axisTick: { lineStyle: { color: "rgba(120,160,220,.25)" } },
      axisLabel: { color: "#5f7191" },
      splitLine: { lineStyle: { color: "rgba(120,160,220,.08)" } },
    },
    valueAxis: {
      axisLine: { lineStyle: { color: "rgba(120,160,220,.25)" } },
      axisLabel: { color: "#5f7191" },
      splitLine: { lineStyle: { color: "rgba(120,160,220,.08)" } },
    },
    tooltip: {
      backgroundColor: "#0d1728", borderColor: "rgba(34,211,238,.35)", borderWidth: 1,
      textStyle: { color: "#e6edf7", fontSize: 12 },
      axisPointer: { lineStyle: { color: "rgba(34,211,238,.5)" },
                     crossStyle: { color: "rgba(34,211,238,.5)" } },
    },
  });
}
function EInit(el) { return echarts.init(el, "tech"); } // eslint-disable-line

const MARKET_NAMES = {
  sh: "沪市", sz: "深市", bj: "北交所", hk: "港股",
  us: "美股", usny: "美股·NYSE", usamx: "美股·AMEX",
};

const TEMPLATE = `
<div class="layout">
  <!-- 侧边栏 -->
  <aside class="sidebar">
    <div class="logo"><span class="logo-mark">🐱</span><span class="logo-text">AlphaDesk<small>多因子研究 · AI 分析 · 自动化监控</small></span></div>
    <nav class="nav">
      <div v-for="p in pages" :key="p.key" class="nav-item" :class="{active: page===p.key}"
           @click="switchPage(p.key)"><span class="nav-icon">{{ p.icon }}</span>{{ p.label }}</div>
    </nav>
    <div class="sidebar-foot">
      <div class="muted" style="text-align:center;font-size:11px;margin-bottom:4px">AlphaDesk v1.0.1</div>
      <div class="lucky-row" title="日进斗金">
        <span class="lucky-item">🌳</span>
        <span class="lucky-item">🐱</span>
        <span class="lucky-item">🦁</span>
      </div>
      <div class="me-chip" @click="licenseDlg = true" title="点击管理授权">
        <span class="me-dot"></span>
        <span class="me-name">{{ license.mode === 'licensed' ? '正式版' : license.mode === 'trial' ? '试用版' : '已到期' }}</span>
        <el-tag :type="license.ok ? 'warning' : 'danger'"
                size="small" effect="dark">{{ licLeftText }}</el-tag>
      </div>
      <el-button type="primary" style="width:100%" :loading="status.running" @click="runPipeline">
        {{ status.running ? '流水线运行中…' : '▶ 运行流水线' }}
      </el-button>
      <div class="muted" style="margin-top:8px;text-align:center;">
        {{ health.trading ? '🟢 交易时段' : '⚪ 非交易时段' }} · {{ health.time.slice(11) || '--:--' }}
      </div>
    </div>
  </aside>

  <!-- 主区域 -->
  <main class="main">
    <!-- 授权横幅(试用/即将到期/已过期): 私有化一机一码 -->
    <div v-if="missedInfo && missedInfo.missed" class="sub-banner expired">
      <span>😴</span>
      <span style="flex:1">{{ missedInfo.last_trading_day }} 收盘任务没跑（电脑关机/睡眠）
        <span class="muted">上次收盘: {{ missedInfo.last_close_date || '从未' }} · {{ missedInfo.schemes }} 个定时方案</span></span>
      <el-button size="small" type="warning" :loading="catchupLoading" @click="runCatchup">一键补跑</el-button>
    </div>
    <div v-if="licenseBanner" class="sub-banner" :class="{ expired: licenseBanner.expired }">
      <span>{{ licenseBanner.expired ? '⛔' : '🔑' }}</span>
      <span style="flex:1">{{ licenseBanner.text }}</span>
      <el-button size="small" type="warning" @click="licenseDlg = true">
        {{ licenseBanner.expired ? '立即激活' : '输入激活码' }}</el-button>
    </div>
    <!-- 激活弹窗 -->
    <el-dialog v-model="licenseDlg" title="激活 AlphaDesk" width="440px">
      <div class="muted" style="margin-bottom:8px">本机机器码(发给卖家获取激活码):</div>
      <div style="display:flex;gap:8px;margin-bottom:12px">
        <el-input :value="license.machine" readonly />
        <el-button @click="copyMachine">复制</el-button>
      </div>
      <el-input v-model="licenseToken" type="textarea" :rows="3" placeholder="粘贴激活码" />
      <el-divider content-position="left">换电脑了？</el-divider>
      <div class="muted" style="margin-bottom:8px">
        年卡用户可免费换机：在<b>新电脑</b>点下面按钮生成申请串，发给卖家即得新激活码。</div>
      <div style="display:flex;gap:8px">
        <el-button size="small" @click="genTransferReq">生成换机申请串</el-button>
        <el-button size="small" text type="primary" v-if="transferReq" @click="copyTransferReq">复制申请串</el-button>
      </div>
      <el-input v-if="transferReq" :value="transferReq" type="textarea" :rows="2" readonly
                style="margin-top:8px" />
      <template #footer>
        <el-button @click="licenseDlg = false">取消</el-button>
        <el-button type="warning" :loading="licenseLoading" @click="activateLicense">激活</el-button>
      </template>
    </el-dialog>
    <el-dialog v-model="guideVisible" title="🎉 欢迎使用 AlphaDesk" width="520px">
      <div class="steps">
        <div class="step"><b>第一步：加点股票</b>
          <p>自选池是空的？点下面按钮一键导入 10 只示例，或右上角手动添加。</p></div>
        <div class="step"><b>第二步：写一句话选股</b>
          <p>去「智能选股器」，比如"连续下跌后出现止跌信号的股票"，点筛选。</p></div>
        <div class="step"><b>第三步：验证再信</b>
          <p>看「条件胜率」和回测「样本外」两栏，绿了再考虑，红了直接扔。</p></div>
      </div>
      <template #footer>
        <el-button @click="dismissGuide">我先自己逛逛</el-button>
        <el-button type="primary" @click="guideGoSamples">一键导入示例，开始</el-button>
      </template>
    </el-dialog>
    <!-- ============ 仪表盘 ============ -->
    <section v-if="page==='dashboard'">
      <div class="page-head">
        <h1>仪表盘</h1>
        <span class="sub">自选池全景 · 评分 / 信号 / 共振一屏总览</span>
        <span class="spacer"></span>
        <el-button size="small" @click="refreshAll">刷新数据</el-button>
      </div>
      <div class="sub-banner">
        <span>🔑</span>
        <span style="flex:1">本机机器码 <b>{{ license.machine || '…' }}</b>，发给卖家获取激活码。</span>
        <el-button size="small" type="warning" @click="licenseDlg = true">输入激活码</el-button>
      </div>

      <div class="kpi">
        <div class="item"><div class="l">📅 自选池</div>
          <div class="v">{{ watchlist.length }}<span class="muted" style="font-size:14px;font-weight:400"> / {{ poolMax }}</span></div></div>
        <div class="item"><div class="l">🎯 平均评分</div>
          <div class="v" :style="{color: scoreColor(avgScore)}">{{ avgScore ?? '-' }}</div></div>
        <div class="item"><div class="l">🔥 重点信号(库内)</div>
          <div class="v" style="color:#f5c542">{{ alerts.length }}</div></div>
        <div class="item"><div class="l">🤖 AI 分析</div>
          <div class="v" style="font-size:17px;line-height:1.9">
            <el-tag :type="cfg.ai_enabled ? 'success' : 'info'" size="small" effect="light">{{ cfg.ai_enabled ? '已启用' : '未启用' }}</el-tag>
            <el-tag :type="cfg.email_enabled ? 'success' : 'info'" size="small" effect="light" style="margin-left:6px">邮件 {{ cfg.email_enabled ? '开' : '关' }}</el-tag>
          </div></div>
        <div class="item"><div class="l">⏱ 上次运行</div>
          <div class="v" style="font-size:15px;line-height:1.5">{{ status.finished_at || '尚未运行' }}</div></div>
        <div class="item"><div class="l">🩺 数据健康
            <el-button size="small" text type="primary" style="margin-left:4px" :loading="healthLoading"
              @click="runHealthCheck">检查</el-button></div>
          <div class="v" style="font-size:15px;line-height:1.5">
            <span v-if="!dataHealth">未检查</span>
            <span v-else-if="dataHealth.ok" style="color:#00e5a0">正常 · {{ dataHealth.checks.length }} 项</span>
            <span v-else style="color:#ff5c6e">异常 {{ dataHealth.checks.filter((c) => !c.ok).length }} 项</span>
          </div>
          <div class="muted" style="font-size:11px" v-if="dataHealth">{{ dataHealth.ts }}</div></div>
      </div>
      <div class="card" v-if="dataHealth && !dataHealth.ok">
        <h3><span class="h-ico">⚠️</span>数据健康异常</h3>
        <div v-for="c in dataHealth.checks.filter((x) => !x.ok)" :key="c.name" class="strategy-item">
          <b>{{ c.name }}</b><span class="muted">{{ c.detail }}</span>
          <span style="flex:1"></span><span class="muted">{{ c.ms }}ms</span>
        </div>
      </div>

      <div class="card" v-if="status.running">
        <h3><span class="h-ico">⏳</span>流水线运行中</h3>
        <div class="progress-line">
          <span class="muted" style="min-width:210px">{{ status.progress }}</span>
          <el-progress :percentage="status.stocks_total ? Math.round(status.stocks_done*100/status.stocks_total) : 0"
                       style="flex:1" />
          <span class="muted">{{ status.stocks_done }}/{{ status.stocks_total }}</span>
        </div>
        <el-alert v-for="(e,i) in status.errors" :key="i" :title="e" type="error" :closable="false"
                  style="margin-top:8px" />
      </div>

      <div class="dash-grid">
        <div class="card">
          <h3><span class="h-ico">📊</span>自选池总览
            <el-tag v-if="dashFilter" size="small" type="primary" effect="light" closable
                    style="margin-left:10px" @close="dashFilter = null">
              筛选: {{ dashFilter.label }} ({{ analysesTable.length }})
            </el-tag>
            <el-button size="small" text type="primary" style="margin-left:auto" @click="switchPage('analyses')">AI 分析 →</el-button>
          </h3>
          <el-table :data="analysesTable" size="default" @row-click="openDetail" style="cursor:pointer;width:100%"
                    empty-text="暂无分析数据, 点击左侧「运行流水线」开始">
            <el-table-column label="股票" min-width="150">
              <template #default="s">
                <b>{{ s.row.name || s.row.code }}</b>
                <span class="muted"> {{ s.row.code }}</span>
              </template>
            </el-table-column>
            <el-table-column label="现价" width="95" align="right">
              <template #default="s">{{ fmtNum(s.row.payload?.price) }}</template>
            </el-table-column>
            <el-table-column label="涨跌幅" width="92" align="right">
              <template #default="s"><span v-html="fmtPct(s.row.payload?.change_pct)"></span></template>
            </el-table-column>
            <el-table-column label="算法评分" width="160">
              <template #default="s">
                <div class="score-bar">
                  <el-progress :percentage="s.row.payload?.score ?? 0" :stroke-width="8"
                               :color="scoreColor(s.row.payload?.score)" :show-text="false" />
                  <b :style="{color: scoreColor(s.row.payload?.score)}">{{ s.row.payload?.score ?? '-' }}</b>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="共振" width="132">
              <template #default="s">
                <el-tag v-if="s.row.payload?.confluence && s.row.payload.confluence.level !== 'none'"
                        size="small" effect="light"
                        :type="cfLevelTagType(s.row.payload.confluence.level)">
                  {{ s.row.payload.confluence.direction }} {{ s.row.payload.confluence.level_label }}
                </el-tag>
                <span v-else class="muted">—</span>
              </template>
            </el-table-column>
            <el-table-column label="信号" width="76">
              <template #default="s">
                <el-tag :type="signalType(s.row.payload?.signal)" size="small" effect="light">{{ s.row.payload?.signal || '-' }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="AI 摘要" min-width="240">
              <template #default="s">
                <span v-if="s.row.payload?.ai" class="muted">{{ s.row.payload.ai.trend }} {{ s.row.payload.ai.summary }}</span>
                <span v-else class="muted">—</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="80" fixed="right">
              <template #default="s">
                <el-button size="small" text type="primary" @click.stop="openDetail(s.row)">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <div class="dash-side">
          <div class="card">
            <h3><span class="h-ico">📈</span>涨跌分布
              <span class="muted" style="font-weight:400;margin-left:auto">hover 查看成分 · 点击行筛选</span>
            </h3>
            <div class="cf-meter" style="height:12px">
              <div class="cf-meter-bear" :style="{flex: distStats.down || 0.001}"></div>
              <div class="cf-meter-mid" :style="{flex: distStats.flat || 0.001}"></div>
              <div class="cf-meter-bull" :style="{flex: distStats.up || 0.001}"></div>
            </div>
            <div class="cf-legend" style="font-size:12px;flex-wrap:wrap">
              <el-popover v-for="(g, key) in distLegend" :key="'dg-'+key"
                          placement="bottom-start" :width="250" trigger="hover" popper-class="stock-pop">
                <template #reference>
                  <span class="dist-chip" :class="[{active: isDashFilter('dist', key)}, key]"
                        @click="toggleDashFilter('dist', key, g.label)">{{ g.label }} {{ g.list.length }}</span>
                </template>
                <div class="pop-title">{{ g.label }} · {{ g.list.length }} 只
                  <span class="muted" style="float:right">点击个股看详情</span></div>
                <div class="pop-list">
                  <div v-for="a in g.list" :key="a.code" class="pop-item" @click="openDetail(a)">
                    <span class="pi-name"><b>{{ a.name || a.code }}</b> <span class="muted">{{ a.code }}</span></span>
                    <span class="pi-chg" :class="(a.payload?.change_pct ?? 0) > 0 ? 'up' : ((a.payload?.change_pct ?? 0) < 0 ? 'down' : 'flat')">
                      {{ fmtPctRaw(a.payload?.change_pct) }}
                    </span>
                  </div>
                  <div v-if="!g.list.length" class="muted" style="padding:6px 2px">暂无</div>
                </div>
              </el-popover>
            </div>
            <div class="section-title">共振全景
              <span class="muted" style="font-weight:400;float:right">点击行可筛选左侧总览</span>
            </div>
            <el-popover v-for="(c, lv) in cfDist" :key="'cf-'+lv"
                        placement="left-start" :width="270" trigger="hover" popper-class="stock-pop">
              <template #reference>
                <div class="dist-row" :class="{active: isDashFilter('cf', lv)}"
                     @click="toggleDashFilter('cf', lv, c.label)">
                  <span class="dr-label muted">{{ c.label }}</span>
                  <div class="dr-bar">
                    <div :style="{width: (c.count / (analyses.length || 1) * 100) + '%',
                                  background: lv.indexOf('bull') >= 0 ? 'var(--up)' : lv.indexOf('bear') >= 0 ? 'var(--down)' : '#c2c7d2',
                                  height: '100%'}"></div>
                  </div>
                  <b class="dr-count">{{ c.count }}</b>
                </div>
              </template>
              <div class="pop-title">{{ c.label }} · {{ c.count }} 只
                <span class="muted" style="float:right">点击个股看详情</span></div>
              <div class="pop-list">
                <div v-for="a in cfGroups[lv]" :key="a.code" class="pop-item" @click="openDetail(a)">
                  <span class="pi-name"><b>{{ a.name || a.code }}</b> <span class="muted">{{ a.code }}</span></span>
                  <span class="pi-chg" :style="{color: scoreColor(a.payload?.score)}">{{ a.payload?.score ?? '-' }}</span>
                </div>
                <div v-if="!cfGroups[lv].length" class="muted" style="padding:6px 2px">暂无</div>
              </div>
            </el-popover>
          </div>

          <div class="card">
            <h3><span class="h-ico">🔥</span>最新重点信息
              <el-button size="small" text type="primary" style="margin-left:auto"
                         @click="switchPage('alerts')">全部 →</el-button>
            </h3>
            <template v-if="alerts.length">
              <div v-for="a in alerts.slice(0,10)" :key="a.id" class="alert-line">
                <el-tag :type="levelType(a.level)" size="small" effect="dark">{{ a.level }}</el-tag>
                <div style="flex:1;min-width:0">
                  <b>{{ a.name || a.code }}</b> <span class="muted">{{ a.title }}</span>
                  <div class="muted" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ a.detail }}</div>
                </div>
                <span class="muted" style="white-space:nowrap">{{ fmtTs(a.ts).slice(5) }}</span>
              </div>
            </template>
            <el-empty v-else description="暂无重点信息" :image-size="60" />
          </div>
        </div>
      </div>
    </section>

    <!-- ============ 自选池 ============ -->
    <section v-if="page==='hold'">
      <div class="page-head">
        <h1>模拟持仓</h1>
        <span class="sub">手动记录买入价/数量，每日盯盈亏（模拟盘，不连券商）</span>
        <span class="spacer"></span>
        <el-button size="small" type="primary" @click="holdDlg = true">＋ 加持仓</el-button>
        <el-button size="small" @click="loadHoldings">刷新盈亏</el-button>
      </div>
      <div class="kpi" v-if="holdSummary">
        <div class="item"><div class="l">💰 总成本</div>
          <div class="v">{{ holdSummary.total_cost?.toLocaleString() }}</div></div>
        <div class="item"><div class="l">📊 总市值</div>
          <div class="v">{{ holdSummary.total_mv?.toLocaleString() }}</div></div>
        <div class="item"><div class="l">📈 总盈亏</div>
          <div class="v" :style="{color: btColor(holdSummary.total_pnl)}">
            {{ holdSummary.total_pnl > 0 ? '+' : '' }}{{ holdSummary.total_pnl?.toLocaleString() }}</div></div>
      </div>
      <div class="card">
        <el-empty v-if="!holdings.length" description="还没有持仓，点右上角加一笔（按买入价记）" :image-size="60" />
        <el-table v-else :data="holdings" size="small" @row-click="openDetail" style="cursor:pointer;width:100%">
          <el-table-column label="股票" width="170"><template #default="s">
            <b>{{ s.row.name || s.row.code }}</b> <span class="muted">{{ s.row.code }}</span></template></el-table-column>
          <el-table-column label="现价" width="100"><template #default="s">
            {{ s.row.price ?? '-' }}
            <span class="muted" v-if="s.row.change_pct != null">{{ s.row.change_pct }}%</span></template></el-table-column>
          <el-table-column label="成本" width="90"><template #default="s">{{ s.row.buy_price }}</template></el-table-column>
          <el-table-column label="数量" width="90"><template #default="s">{{ s.row.qty }}</template></el-table-column>
          <el-table-column label="盈亏" width="130"><template #default="s">
            <b :style="{color: btColor(s.row.pnl)}">{{ s.row.pnl == null ? '-' : ((s.row.pnl > 0 ? '+' : '') + s.row.pnl) }}</b>
            <span class="muted" v-if="s.row.pnl_pct != null">({{ s.row.pnl_pct }}%)</span></template></el-table-column>
          <el-table-column label="买入日" width="110"><template #default="s">{{ s.row.buy_date }}</template></el-table-column>
          <el-table-column label="操作" width="90"><template #default="s">
            <el-button size="small" text type="danger" @click.stop="delHolding(s.row.id)">删除</el-button></template></el-table-column>
        </el-table>
      </div>
    </section>
    <el-dialog v-model="holdDlg" title="加一笔持仓" width="420px">
      <el-form label-width="80px" size="small">
        <el-form-item label="代码"><el-input v-model="holdForm.code" placeholder="如 600519" /></el-form-item>
        <el-form-item label="买入价"><el-input-number v-model="holdForm.buy_price" :min="0" :precision="2" /></el-form-item>
        <el-form-item label="数量(股)"><el-input-number v-model="holdForm.qty" :min="100" :step="100" /></el-form-item>
        <el-form-item label="买入日"><el-date-picker v-model="holdForm.buy_date" type="date" value-format="YYYY-MM-DD" /></el-form-item>
        <el-form-item label="备注"><el-input v-model="holdForm.note" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="holdDlg = false">取消</el-button>
        <el-button type="primary" @click="saveHolding">保存</el-button>
      </template>
    </el-dialog>
    <section v-if="page==='pool'">
      <div class="page-head">
        <h1>自选池</h1>
        <span class="sub">管理关注标的 · 分析状态一览</span>
        <span class="spacer"></span>
        <el-button type="primary" @click="openAdd">＋ 新增股票</el-button>
      </div>

      <div class="kpi">
        <div class="item"><div class="l">📋 池内股票</div>
          <div class="v">{{ watchlist.length }}<span class="muted" style="font-size:14px;font-weight:400"> / {{ poolMax }}</span></div></div>
        <div class="item"><div class="l">✅ 已分析</div>
          <div class="v">{{ analyzedCount }}</div></div>
        <div class="item"><div class="l">⌛ 待分析</div>
          <div class="v" style="color:#5f7191">{{ watchlist.length - analyzedCount }}</div></div>
        <div class="item"><div class="l">🎯 平均评分</div>
          <div class="v" :style="{color: scoreColor(avgScore)}">{{ avgScore ?? '-' }}</div></div>
      </div>

      <div class="card">
        <h3><span class="h-ico">📋</span>股票列表
          <el-radio-group v-model="poolFilterGroup" size="small" style="margin-left:12px">
            <el-radio-button label="全部"></el-radio-button>
            <el-radio-button v-for="g in poolGroupsList" :key="g" :label="g"></el-radio-button>
          </el-radio-group>
          <el-button size="small" text type="primary" @click="newPoolGroup">＋分组</el-button>
          <el-button size="small" text type="danger" v-if="poolFilterGroup!=='全部' && poolFilterGroup!=='默认'"
            @click="delPoolGroup(poolFilterGroup)">删除该分组</el-button>
          <span class="muted" style="font-weight:400;margin-left:auto">点击行查看详情</span>
        </h3>
        <el-empty v-if="!watchlist.length" description="自选池是空的, 先加点股票开始吧">
          <el-button type="primary" @click="importSamples">一键导入 10 只示例</el-button>
        </el-empty>
        <el-table v-else :data="filteredWatchlist" empty-text="该分组暂无股票" @row-click="openDetail"
                  style="cursor:pointer;width:100%">
          <el-table-column label="代码" width="110">
            <template #default="s"><b>{{ s.row.code }}</b></template>
          </el-table-column>
          <el-table-column label="名称" min-width="130">
            <template #default="s">{{ s.row.name || '-' }}</template>
          </el-table-column>
          <el-table-column label="分组" width="120">
            <template #default="s">
              <el-select :model-value="s.row.group_name || '默认'" size="small"
                @change="(v) => movePoolGroup(s.row, v)" @click.stop>
                <el-option v-for="g in poolGroupsList" :key="g" :label="g" :value="g"></el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column prop="note" label="备注" min-width="150" show-overflow-tooltip />
          <el-table-column label="现价" width="95" align="right">
            <template #default="s">{{ fmtNum(analysesByCode[s.row.code]?.payload?.price) }}</template>
          </el-table-column>
          <el-table-column label="涨跌幅" width="92" align="right">
            <template #default="s">
              <span v-if="analysesByCode[s.row.code]" v-html="fmtPct(analysesByCode[s.row.code].payload?.change_pct)"></span>
              <span v-else class="muted">—</span>
            </template>
          </el-table-column>
          <el-table-column label="最新评分" width="150">
            <template #default="s">
              <div v-if="analysesByCode[s.row.code]" class="score-bar">
                <el-progress :percentage="analysesByCode[s.row.code].payload?.score ?? 0" :stroke-width="8"
                             :color="scoreColor(analysesByCode[s.row.code].payload?.score)" :show-text="false" />
                <b :style="{color: scoreColor(analysesByCode[s.row.code].payload?.score)}">
                  {{ analysesByCode[s.row.code].payload?.score ?? '-' }}
                </b>
              </div>
              <span v-else class="muted">未分析</span>
            </template>
          </el-table-column>
          <el-table-column label="信号" width="84">
            <template #default="s">
              <el-tag v-if="analysesByCode[s.row.code]" :type="signalType(analysesByCode[s.row.code].payload?.signal)"
                      size="small" effect="light">
                {{ analysesByCode[s.row.code].payload?.signal }}
              </el-tag>
              <span v-else class="muted">—</span>
            </template>
          </el-table-column>
          <el-table-column label="共振" width="130">
            <template #default="s">
              <el-tag v-if="analysesByCode[s.row.code]?.payload?.confluence?.level && analysesByCode[s.row.code].payload.confluence.level !== 'none'"
                      size="small" effect="light"
                      :type="cfLevelTagType(analysesByCode[s.row.code].payload.confluence.level)">
                {{ analysesByCode[s.row.code].payload.confluence.direction }} {{ analysesByCode[s.row.code].payload.confluence.level_label }}
              </el-tag>
              <span v-else class="muted">—</span>
            </template>
          </el-table-column>
          <el-table-column label="添加时间" width="110">
            <template #default="s">{{ fmtTs(s.row.created_at).slice(5, 10) }}</template>
          </el-table-column>
          <el-table-column label="操作" width="170" fixed="right">
            <template #default="s">
              <el-button size="small" text type="primary" @click.stop="openDetail(s.row)">详情</el-button>
              <el-button size="small" text @click.stop="openEdit(s.row)">编辑</el-button>
              <el-button size="small" text type="danger" @click.stop="removeStock(s.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </section>

    <!-- ============ AI 分析 ============ -->
    <section v-if="page==='analyses'">
      <div class="page-head">
        <h1>AI 分析</h1>
        <span class="sub">算法评分 × 多维共振 × AI 结论 · 三位一体研判</span>
      </div>
      <div class="risk-line">⚠️ 以下评分与 AI 结论仅供学习研究，不构成投资建议。市场有风险，投资需谨慎。</div>

      <div class="card" v-if="!cfg.ai_enabled">
        <el-alert type="info" :closable="false" show-icon
                  title="AI 分析未启用"
                  description="可在「设置 → AI 分析」中开启, 并配置 OpenAI 兼容接口(DeepSeek / 通义 / Kimi 等)。算法评分与技术分析不受影响, 始终可用。" />
      </div>

      <div class="kpi" v-if="analyses.length">
        <div class="item"><div class="l">📦 已分析</div><div class="v">{{ analyses.length }}</div></div>
        <div class="item"><div class="l">▲ 看多</div><div class="v" style="color:var(--up)">{{ aiSummary.bull }}</div></div>
        <div class="item"><div class="l">◆ 中性</div><div class="v" style="color:#5f7191">{{ aiSummary.neutral }}</div></div>
        <div class="item"><div class="l">▼ 看空</div><div class="v" style="color:var(--down)">{{ aiSummary.bear }}</div></div>
        <div class="item"><div class="l">🎯 平均评分</div>
          <div class="v" :style="{color: scoreColor(aiSummary.avgScore)}">{{ aiSummary.avgScore }}</div></div>
        <div class="item"><div class="l">⏱ 最近分析</div>
          <div class="v" style="font-size:16px;line-height:2.2">{{ aiSummary.lastRun }}</div></div>
      </div>

      <div class="card" v-if="analyses.length">
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
          <el-radio-group v-model="aiFilter" size="default">
            <el-radio-button label="全部" />
            <el-radio-button label="看多" />
            <el-radio-button label="中性" />
            <el-radio-button label="看空" />
          </el-radio-group>
          <el-select v-model="aiSort" size="default" style="width:160px">
            <el-option label="按综合评分" value="score" />
            <el-option label="按AI置信度" value="confidence" />
            <el-option label="按净利同比" value="profit_yoy" />
            <el-option label="按代码" value="code" />
          </el-select>
          <el-input v-model="aiQuery" size="default" clearable placeholder="搜索名称 / 代码"
                    style="width:200px" />
          <span class="muted" style="margin-left:auto">展示 {{ analysesView.length }} / {{ analyses.length }} 只</span>
        </div>
      </div>

      <div class="ai-grid" v-if="analysesView.length">
        <div class="card ai-card" v-for="a in analysesView" :key="a.code">
          <div class="ai-head">
            <b class="ai-name">{{ a.name || a.code }}</b>
            <span class="muted">{{ a.code }}</span>
            <el-tag :type="signalType(a.payload?.signal)" size="small">{{ a.payload?.signal }}</el-tag>
            <span class="ai-score" :style="{background: scoreColor(a.payload?.score)}">{{ a.payload?.score ?? '-' }}</span>
          </div>

          <template v-if="a.payload?.ai">
            <div class="ai-trendline">
              <span class="muted">AI 判断</span>
              <el-tag size="small" effect="plain" :type="aiTrendType(a.payload.ai.trend)">{{ a.payload.ai.trend }}</el-tag>
              <el-progress :percentage="aiConf(a.payload.ai.confidence)" :stroke-width="8"
                           :color="confidenceColor" style="flex:1" />
            </div>
            <div class="ai-sec"><b>💡 分析</b><p>{{ a.payload.ai.summary }}</p></div>
            <div class="ai-sec risk" v-if="a.payload.ai.risk"><b>⚠️ 风险</b><p>{{ a.payload.ai.risk }}</p></div>
            <div class="ai-sec sugg" v-if="a.payload.ai.suggestion"><b>🎯 建议</b><p>{{ a.payload.ai.suggestion }}</p></div>
          </template>
          <el-empty v-else :description="a.payload?.ai_error ? 'AI 未返回: ' + a.payload.ai_error : '暂无 AI 分析结果'" :image-size="48" />

          <div class="cf-banner" v-if="a.payload?.confluence && a.payload.confluence.level !== 'none'"
               :class="'cf-' + a.payload.confluence.level">
            <span class="cf-arrow">{{ a.payload.confluence.direction }}</span>
            <div style="flex:1">
              <b>{{ a.payload.confluence.level_label }}</b>
              <span class="muted"> · 多 {{ a.payload.confluence.bull_count }} / 空 {{ a.payload.confluence.bear_count }} · 共振度 {{ a.payload.confluence.ratio }}%</span>
            </div>
          </div>

          <div class="pros-line" v-if="a.payload?.prosperity">
            {{ a.payload.prosperity.icon }} 景气度
            <b :style="{color: a.payload.prosperity.color}">{{ a.payload.prosperity.score }}</b>
            <el-tag size="small" effect="plain"
                    :style="{color: a.payload.prosperity.color, borderColor: a.payload.prosperity.color}">
              {{ a.payload.prosperity.level_label }}</el-tag>
            <span class="muted">{{ a.payload.prosperity.outlook }}</span>
          </div>

          <div class="fin-line" v-if="a.payload?.financials?.report_date">
            🧾 {{ a.payload.financials.report_name }} · 净利同比
            <b :style="{color: (a.payload.financials.profit_yoy ?? 0) > 0 ? '#ff5c6e' : ((a.payload.financials.profit_yoy ?? 0) < 0 ? '#00e5a0' : '#9fb0c9')}">
              {{ fmtPctText(a.payload.financials.profit_yoy) }}</b>
            · ROE {{ a.payload.financials.roe ?? '-' }}% · 负债率 {{ a.payload.financials.debt_ratio ?? '-' }}%
          </div>

          <div class="factor-bars" v-if="a.payload?.factors">
            <div class="fb" v-for="(v, k) in a.payload.factors" :key="k">
              <span class="fl">{{ factorLabel(k) }}</span>
              <div class="fbar"><i :style="{width: (v ?? 0) + '%', background: factorColor(v)}"></i></div>
              <b class="fv">{{ v ?? '-' }}</b>
            </div>
          </div>

          <div class="ai-foot">
            <span class="muted">{{ fmtTs(a.ts) }}</span>
            <el-button size="small" text type="primary" @click="openDetail(a)">K线 · 技术面 · 新闻 →</el-button>
          </div>
        </div>
      </div>
      <el-empty v-if="!analyses.length" description="暂无分析数据, 点击左下角「▶ 运行流水线」生成" />
    </section>

    <!-- ============ 新闻 ============ -->
    <section v-if="page==='news'">
      <div class="page-head">
        <h1>新闻资讯</h1>
        <span class="sub">自选池个股动态 · 按发布时间倒序</span>
        <span class="spacer"></span>
        <el-button size="small" :loading="eventsLoading" @click="loadEvents">
          📅 事件日历 ({{ eventsTotal }})</el-button>
        <el-select v-model="newsCode" clearable placeholder="按股票筛选" style="width:200px">
          <el-option v-for="s in watchlist" :key="s.code" :label="(s.name||'')+' '+s.code" :value="s.code" />
        </el-select>
      </div>

      <div class="card" v-if="eventsGroups.length">
        <h3><span class="h-ico">📅</span>公告事件日历
          <span class="muted" style="font-weight:400">近{{ eventsDays }}天自选池利好/利空公告 · {{ eventsTotal }} 起</span>
          <span class="spacer"></span>
          <el-button size="small" :loading="eventsScanning" @click="scanEvents">🔍 立即扫描</el-button>
        </h3>
        <div v-for="g in eventsGroups" :key="g.date" style="margin-bottom:10px">
          <div class="section-title">{{ g.date }} ({{ g.items.length }})</div>
          <div v-for="(e, i) in g.items" :key="i" class="alert-line">
            <el-tag size="small" :type="e.level==='bad' ? 'danger' : 'success'">{{ e.cat }}</el-tag>
            <div style="flex:1">
              <b>{{ e.name }}</b> <span class="muted">{{ e.code }}</span><br />
              <a class="news-title" :href="e.url" target="_blank" rel="noopener">{{ e.title }}</a>
            </div>
            <el-button size="small" text type="primary" @click="openDetail({code: e.code, name: e.name})">详情</el-button>
          </div>
        </div>
      </div>

      <div class="kpi">
        <div class="item"><div class="l">📰 新闻总数</div><div class="v">{{ newsFiltered.length }}</div></div>
        <div class="item"><div class="l">🗂 覆盖个股</div>
          <div class="v">{{ new Set(newsFiltered.map(n => n.code)).size }}</div></div>
        <div class="item"><div class="l">🕐 最新一条</div>
          <div class="v" style="font-size:16px;line-height:2.2">{{ (newsFiltered[0]?.published || '').slice(5, 16) || '-' }}</div></div>
      </div>

      <div class="card">
        <h3><span class="h-ico">📰</span>资讯流
          <span class="muted" style="font-weight:400;margin-left:auto">
            {{ newsCode ? '已筛选: ' + (watchlistByName[newsCode]?.name || newsCode) : '全部自选池' }}
          </span>
        </h3>
        <el-table :data="newsFiltered" empty-text="暂无新闻, 运行流水线后自动抓取">
          <el-table-column label="股票" width="150">
            <template #default="s">
              <b>{{ s.row.name || s.row.code }}</b><span class="muted"> {{ s.row.code }}</span>
            </template>
          </el-table-column>
          <el-table-column label="标题" min-width="520">
            <template #default="s">
              <a class="news-title" :href="s.row.url" target="_blank" rel="noopener">{{ s.row.title }}</a>
              <div class="muted" v-if="s.row.summary">{{ s.row.summary.slice(0, 90) }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="source" label="来源" width="120" />
          <el-table-column label="时间" width="130">
            <template #default="s">{{ (s.row.published || '').slice(0,16) }}</template>
          </el-table-column>
        </el-table>
      </div>
    </section>

    <!-- ============ 重点信息 ============ -->
    <section v-if="page==='alerts'">
      <div class="page-head">
        <h1>重点信息</h1>
        <span class="sub">价格 / 量能 / 共振 / 财报信号实时监控</span>
        <span class="spacer"></span>
        <el-button @click="sendDigest">✉ 立即发送摘要邮件</el-button>
      </div>

      <div class="kpi">
        <div class="item"><div class="l">🔥 信号总数</div><div class="v">{{ alerts.length }}</div></div>
        <div class="item"><div class="l">🚨 高级别</div>
          <div class="v" style="color:var(--up)">{{ alerts.filter(a => a.level === 'high').length }}</div></div>
        <div class="item"><div class="l">⚡ 中级别</div>
          <div class="v" style="color:#f5c542">{{ alerts.filter(a => a.level === 'medium').length }}</div></div>
        <div class="item"><div class="l">ℹ️ 低级别</div>
          <div class="v" style="color:var(--down)">{{ alerts.filter(a => a.level === 'low').length }}</div></div>
      </div>

      <div class="card">
        <h3><span class="h-ico">🔥</span>信号列表
          <span class="muted" style="font-weight:400;margin-left:auto">点击行查看个股详情</span>
        </h3>
        <el-table :data="alerts" @row-click="openDetail" style="cursor:pointer;width:100%"
                  empty-text="暂无重点信息, 运行流水线后自动产生">
          <el-table-column label="时间" width="150">
            <template #default="s">{{ fmtTs(s.row.ts) }}</template>
          </el-table-column>
          <el-table-column label="级别" width="84">
            <template #default="s">
              <el-tag :type="levelType(s.row.level)" size="small" effect="dark">{{ s.row.level }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="股票" width="150">
            <template #default="s">
              <b>{{ s.row.name || s.row.code }}</b><span class="muted"> {{ s.row.code }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="kind" label="类型" width="112">
            <template #default="s"><span class="muted">{{ s.row.kind }}</span></template>
          </el-table-column>
          <el-table-column prop="title" label="信号" min-width="190">
            <template #default="s"><b>{{ s.row.title }}</b></template>
          </el-table-column>
          <el-table-column prop="detail" label="说明" min-width="240" show-overflow-tooltip />
          <el-table-column label="评分" width="82" align="right">
            <template #default="s">
              <b :style="{color: scoreColor(s.row.score)}">{{ s.row.score ?? '-' }}</b>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </section>

    <!-- ============ 量化实验室 ============ -->
    <section v-if="page==='quant'">
      <div class="page-head">
        <h1>量化实验室</h1>
        <span class="sub">自编策略 · 后复权数据 · T+1 开盘成交 · 无前视偏差回测</span>
      </div>

      <el-tabs v-model="quantTab" type="border-card" class="quant-tabs">
        <!-- ===== 自我进化 ===== -->
        <el-tab-pane label="🧬 自我进化" name="evolve">
          <div class="card">
            <h3><span class="h-ico">🧬</span>AI 自我进化
              <span class="muted" style="font-weight:400;margin-left:auto">
                AI 定标准 → 出候选 → 回测验证 → 淘汰迭代 · 自动去重
              </span>
            </h3>
            <div class="evolve-ctrl">
              <span class="muted">进化轮数</span>
              <el-input-number v-model="evolveCfg.generations" :min="1" :max="12" size="small" style="width:100px" />
              <span class="muted">每轮候选</span>
              <el-input-number v-model="evolveCfg.population" :min="3" :max="12" size="small" style="width:90px" />
              <span class="muted">K线数量</span>
              <el-input-number v-model="evolveCfg.kline_count" :min="60" :max="260" :step="10" size="small" style="width:100px" />
              <el-button type="warning" :loading="evolveStatus.running" @click="startEvolve">
                {{ evolveStatus.running ? '进化中…' : '🚀 启动进化' }}</el-button>
              <el-button v-if="evolveStatus.running" @click="stopEvolve">停止</el-button>
            </div>
            <div class="evolve-progress" v-if="evolveStatus.running || evolveStatus.progress">
              <el-progress :percentage="evolvePct" :stroke-width="10"
                           :status="evolveStatus.running ? '' : 'success'" />
              <div class="muted" style="margin-top:6px">{{ evolveStatus.progress }}</div>
            </div>
            <div class="evolve-stats">
              <span>已测 <b>{{ evolveStatus.tested }}</b> 个</span>
              <span>重复跳过 <b>{{ evolveStatus.skipped_dup }}</b></span>
              <span>淘汰 <b>{{ evolveStatus.invalid }}</b> 个</span>
              <span title="综合评分 0~100 分: 收益占 4 成、稳健占 3 成、月胜率占 3 成，越高越好">最高评分 <b :style="{color:'var(--brand)'}">{{ fitScore(evolveStatus.best_fitness) }}</b></span>
              <span v-if="evolveStatus.error" style="color:var(--up)">错误: {{ evolveStatus.error }}</span>
            </div>
          </div>

          <div class="card" v-if="evolveStatus.best">
            <h3><span class="h-ico">🏆</span>冠军策略 · {{ evolveStatus.best.spec.name }}
              <el-tag v-if="evolveStatus.best.oos" size="small" style="margin-left:8px"
                      :type="evolveStatus.best.oos.pass ? 'success' : 'danger'" effect="dark"
                      :title="evolveStatus.best.oos.reason">
                样本外{{ evolveStatus.best.oos.pass ? '验证通过' : '未通过' }}({{ evolveStatus.best.oos.test_ret }}%)</el-tag>
              <el-button type="primary" size="small" style="margin-left:auto"
                         @click="adoptStrategy(evolveStatus.best.fingerprint)">采用为正式策略</el-button>
            </h3>
            <div class="champ-grid">
              <div class="muted" v-for="(v, k) in champStats" :key="k">
                <div class="l">{{ k }}</div><div class="v">{{ v }}</div>
              </div>
            </div>
            <div class="strategy-rules">
              <div><b>买入:</b> {{ rulesText(evolveStatus.best.spec.entry) }}</div>
              <div><b>卖出:</b> {{ rulesText(evolveStatus.best.spec.exit) || '无(依赖风控退出)' }}</div>
              <div><b>风控:</b> 止损 {{ evolveStatus.best.spec.stop_loss_pct }}% · 止盈
                {{ evolveStatus.best.spec.take_profit_pct }}% · 最长持有 {{ evolveStatus.best.spec.max_hold_days }} 日</div>
            </div>
          </div>

          <div class="card" v-if="evolveStatus.leaderboard.length">
            <h3><span class="h-ico">🥇</span>候选排行榜
              <span class="muted" style="font-weight:400;margin-left:auto">综合评分 0~100 分 = 收益 × 40% + 稳健 × 30% + 月胜率 × 30%，越高越好</span>
            </h3>
            <el-table :data="evolveStatus.leaderboard" size="small" max-height="400">
              <el-table-column label="#" width="44" type="index" />
              <el-table-column label="策略" min-width="150">
                <template #default="s"><b>{{ s.row.spec.name }}</b></template>
              </el-table-column>
              <el-table-column label="评分" width="70" align="right">
                <template #default="s"><b :style="{color:'var(--brand)'}" :title="'原始分 ' + s.row.fitness">{{ fitScore(s.row.fitness) }}</b></template>
              </el-table-column>
              <el-table-column label="样本外" width="92" align="center">
                <template #default="s">
                  <el-tag v-if="s.row.oos" size="small"
                          :type="s.row.oos.pass ? 'success' : 'danger'" effect="dark"
                          :title="s.row.oos.reason">验{{ s.row.oos.pass ? '✓' : '✗' }} {{ s.row.oos.test_ret }}%</el-tag>
                  <span v-else class="muted">-</span>
                </template>
              </el-table-column>
              <el-table-column label="收益%" width="80" align="right">
                <template #default="s"><span :style="{color: btColor(s.row.stats.total_return_pct)}">{{ s.row.stats.total_return_pct }}%</span></template>
              </el-table-column>
              <el-table-column label="回撤%" width="76" align="right">
                <template #default="s">{{ s.row.stats.max_drawdown_pct }}%</template>
              </el-table-column>
              <el-table-column label="夏普比率" width="84" align="right">
                <template #default="s">{{ s.row.stats.sharpe }}</template>
              </el-table-column>
              <el-table-column label="胜率%" width="72" align="right">
                <template #default="s">{{ s.row.stats.win_rate_pct }}%</template>
              </el-table-column>
              <el-table-column label="交易" width="60" align="right">
                <template #default="s">{{ s.row.stats.trades_count }}</template>
              </el-table-column>
              <el-table-column label="买入规则" min-width="240" show-overflow-tooltip>
                <template #default="s"><span class="muted">{{ rulesText(s.row.spec.entry) }}</span></template>
              </el-table-column>
              <el-table-column label="操作" width="120" fixed="right">
                <template #default="s">
                  <el-button size="small" text type="primary" @click="loadSpec({id:null, name:s.row.spec.name, spec:s.row.spec})">载入</el-button>
                  <el-button size="small" text type="success" @click="adoptStrategy(s.row.fingerprint)">采用</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>

          <div class="card" v-if="evolveRuns.length">
            <h3><span class="h-ico">🗂</span>进化历史</h3>
            <el-table :data="evolveRuns" size="small">
              <el-table-column label="时间" width="150">
                <template #default="s">{{ fmtTs(s.row.created_at) }}</template>
              </el-table-column>
              <el-table-column label="参数" width="150">
                <template #default="s">{{ s.row.params.generations }}代 × {{ s.row.params.population }}候选</template>
              </el-table-column>
              <el-table-column label="测试/去重" width="96" align="right">
                <template #default="s">{{ s.row.tested }} / {{ s.row.skipped_dup }}</template>
              </el-table-column>
              <el-table-column label="冠军" min-width="160">
                <template #default="s">
                  <span v-if="s.row.best"><b>{{ s.row.best.spec.name }}</b>
                    <span class="muted">评分 {{ fitScore(s.row.best.fitness) }}</span></span>
                  <span v-else class="muted">无有效策略</span>
                </template>
              </el-table-column>
              <el-table-column label="冠军规则" min-width="260" show-overflow-tooltip>
                <template #default="s">
                  <span v-if="s.row.best" class="muted">{{ rulesText(s.row.best.spec.entry) }}</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>

        <!-- ===== 策略编辑 ===== -->
        <el-tab-pane label="策略" name="strategy">
          <div class="quant-layout">
            <div class="quant-main">
              <div class="card">
                <h3><span class="h-ico">🧩</span>策略定义
                  <el-input v-model="qspec.name" size="small" placeholder="策略名称"
                            style="width:200px;margin-left:auto" />
                </h3>

                <div class="rule-group" v-for="(gname, gkey) in {entry:'📈 买入条件', exit:'📉 卖出条件'}" :key="gkey">
                  <div class="rg-head">
                    <b>{{ gname }}</b>
                    <el-radio-group v-model="qspec[gkey].op" size="small">
                      <el-radio-button label="all">全部满足</el-radio-button>
                      <el-radio-button label="any">任一满足</el-radio-button>
                    </el-radio-group>
                  </div>
                  <div v-for="(r, i) in qspec[gkey].rules" :key="gkey+i" class="rule-row">
                    <el-select v-model="r.factor" filterable placeholder="因子"
                               style="width:180px" size="small">
                      <el-option-group v-for="grp in factorGroups" :key="grp.group" :label="grp.group">
                        <el-option v-for="f in grp.items" :key="f.key" :value="f.key"
                                   :label="f.label">
                          <span>{{ f.label }}</span>
                          <span class="muted" style="float:right;font-size:11px">{{ f.desc }}</span>
                        </el-option>
                      </el-option-group>
                    </el-select>
                    <el-select v-model="r.op" style="width:96px" size="small">
                      <el-option v-for="o in ruleOps" :key="o.key" :value="o.key" :label="o.label" />
                    </el-select>
                    <template v-if="isEventFactor(r.factor)">
                      <el-tag size="small" effect="plain" type="info">事件因子无需参数</el-tag>
                    </template>
                    <template v-else-if="isBetween(r.op)">
                      <el-input-number v-model="r.value" :controls="false" style="width:86px" size="small" placeholder="下限" />
                      <span class="muted">~</span>
                      <el-input-number v-model="r.value2" :controls="false" style="width:86px" size="small" placeholder="上限" />
                    </template>
                    <el-input-number v-else v-model="r.value" :controls="false"
                                     style="width:90px" size="small" placeholder="值" />
                    <span class="muted rule-desc">{{ factorDesc(r.factor) }}</span>
                    <el-button size="small" text type="danger" style="margin-left:auto"
                               @click="qspec[gkey].rules.splice(i, 1)">删除</el-button>
                  </div>
                  <el-button size="small" text type="primary" @click="addRule(gkey)">＋ 添加条件</el-button>
                </div>

                <div class="rule-group">
                  <div class="rg-head"><b>🛡 风控</b></div>
                  <div class="risk-row">
                    <span class="muted">止损</span>
                    <el-input-number v-model="qspec.stop_loss_pct" :min="1" :max="30" :step="0.5"
                                     size="small" style="width:100px" /> %
                    <span class="muted">止盈</span>
                    <el-input-number v-model="qspec.take_profit_pct" :min="5" :max="100" :step="1"
                                     size="small" style="width:100px" /> %
                    <span class="muted">最长持有</span>
                    <el-input-number v-model="qspec.max_hold_days" :min="1" :max="250"
                                     size="small" style="width:100px" /> 日
                    <span class="muted">初始资金</span>
                    <el-input-number v-model="qspec.initial_capital" :min="10000" :step="10000"
                                     size="small" style="width:130px" /> 元
                    <span class="muted">K线数量</span>
                    <el-input-number v-model="qspec.kline_count" :min="60" :max="260" :step="10"
                                     size="small" style="width:100px" />
                    <el-switch v-model="qPortfolio" size="small" active-text="组合模式"
                      inactive-text="逐只模式" />
                    <span class="muted" v-if="qPortfolio">最大持仓</span>
                    <el-input-number v-if="qPortfolio" v-model="qMaxPositions" :min="1" :max="20"
                                     size="small" style="width:100px" /> <span class="muted" v-if="qPortfolio">只</span>
                    <span class="muted" v-if="qPortfolio">滚动窗口</span>
                    <el-input-number v-if="qPortfolio" v-model="qWindows" :min="0" :max="8"
                                     size="small" style="width:90px" />
                    <span class="muted" v-if="qPortfolio" title="≥2 时做样本外检验: 历史等分多窗独立验证">0=关闭</span>
                    <el-checkbox v-model="qOos" size="small" title="前70%样本内 / 后30%样本外, 防过拟合自欺">样本内外切分</el-checkbox>
                  </div>
                </div>

                <div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap">
                  <el-button type="primary" :loading="qSaving" @click="saveStrategy">保存策略</el-button>
                  <el-button :loading="qScreening" @click="runScreen">🔍 按此策略选股</el-button>
                  <el-button type="warning" :loading="qBacktesting" @click="runBacktest">▶ 运行回测</el-button>
                  <el-button text @click="resetSpec">清空</el-button>
                </div>
              </div>

              <div class="card" v-if="screenResult">
                <h3><span class="h-ico">🔍</span>选股结果
                  <el-tag size="small" effect="light" type="success" style="margin-left:8px">
                    命中 {{ screenResult.hits }} / {{ screenResult.total }}
                  </el-tag>
                  <span class="muted" style="font-weight:400;margin-left:auto">数据日 {{ screenResult.date }} · 点击行看详情</span>
                </h3>
                <el-table :data="screenResult.items" size="small" max-height="420"
                          :row-class-name="screenRowClass" @row-click="openDetail" style="cursor:pointer;width:100%">
                  <el-table-column label="股票" width="140" fixed>
                    <template #default="s">
                      <b :style="{color: s.row.hit ? 'var(--up)' : 'inherit'}">{{ s.row.hit ? '✓ ' : '' }}{{ s.row.name || s.row.code }}</b>
                      <span class="muted"> {{ s.row.code }}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="收盘" width="86" align="right">
                    <template #default="s">{{ s.row.close ?? '-' }}</template>
                  </el-table-column>
                  <el-table-column v-for="f in screenFactorCols" :key="f" :label="factorLabel(f)"
                                   width="108" align="right">
                    <template #default="s">
                      <span v-if="screenCellHit(s.row, f)" style="font-weight:700;color:var(--up)">{{ fmtFactor(s.row.factors?.[f]) }}</span>
                      <span v-else>{{ fmtFactor(s.row.factors?.[f]) }}</span>
                    </template>
                  </el-table-column>
                </el-table>
                <div class="muted" style="margin-top:8px">
                  加粗红色 = 该因子在对应规则中触发。命中判定以策略全部规则为准。
                </div>
              </div>
            </div>

            <div class="quant-side">
              <div class="card">
                <h3><span class="h-ico">🗂</span>我的策略
                  <el-button size="small" text type="primary" style="margin-left:auto"
                             @click="loadStrategies">刷新</el-button>
                </h3>
                <el-empty v-if="!quantStrategies.length" description="暂无保存的策略" :image-size="56" />
                <div v-for="s in quantStrategies" :key="s.id" class="strategy-item">
                  <div style="flex:1;min-width:0">
                    <b>{{ s.name }}</b>
                    <div class="muted" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                      {{ strategySummary(s.spec) }}
                    </div>
                  </div>
                  <el-button size="small" text type="primary" @click="loadSpec(s)">载入</el-button>
                  <el-button size="small" text type="danger" @click="removeStrategy(s.id)">删除</el-button>
                </div>
              </div>

              <div class="card">
                <h3><span class="h-ico">⏮</span>回测历史</h3>
                <el-empty v-if="!btRuns.length" description="暂无回测记录" :image-size="56" />
                <div v-for="r in btRuns" :key="r.id" class="strategy-item">
                  <div style="flex:1;min-width:0">
                    <b>{{ r.strategy_name }}</b>
                    <div class="muted">
                      收益 <b :style="{color: btColor(r.stats.total_return_pct)}">{{ r.stats.total_return_pct }}%</b>
                      · 回撤 {{ r.stats.max_drawdown_pct }}% · 胜率 {{ r.stats.win_rate_pct }}%
                    </div>
                  </div>
                  <el-button size="small" text type="primary" @click="viewRun(r.id)">查看</el-button>
                  <el-button size="small" text type="danger" @click="removeRun(r.id)">删除</el-button>
                </div>
              </div>
            </div>
          </div>
        </el-tab-pane>

        <!-- ===== 回测结果 ===== -->
        <el-tab-pane label="回测结果" name="result" :disabled="!btResult">
          <template v-if="btResult">
            <div class="kpi">
              <div class="item"><div class="l">💰 期末权益</div>
                <div class="v" :style="{color: btColor(btResult.stats.total_return_pct)}">
                  {{ btResult.stats.final_equity?.toLocaleString() }}</div></div>
              <div class="item"><div class="l">📊 总收益率</div>
                <div class="v" :style="{color: btColor(btResult.stats.total_return_pct)}">
                  {{ btResult.stats.total_return_pct }}%</div></div>
              <div class="item"><div class="l">📅 年化收益</div>
                <div class="v" :style="{color: btColor(btResult.stats.cagr_pct)}">{{ btResult.stats.cagr_pct }}%</div></div>
              <div class="item"><div class="l">📉 最大回撤</div>
                <div class="v" style="color:var(--down)">{{ btResult.stats.max_drawdown_pct }}%</div></div>
              <div class="item"><div class="l">⚖️ 夏普比率</div><div class="v">{{ btResult.stats.sharpe }}</div></div>
              <div class="item"><div class="l">🧊 卡玛比率</div><div class="v">{{ btResult.stats.calmar ?? '-' }}</div>
                <div class="muted" style="font-size:11px">年化/最大回撤</div></div>
              <div class="item" v-if="btResult.stats.excess_return_pct !== undefined">
                <div class="l">🏆 超额({{ btResult.stats.benchmark_name || '基准' }})</div>
                <div class="v" :style="{color: btColor(btResult.stats.excess_return_pct)}">
                  {{ btResult.stats.excess_return_pct > 0 ? '+' : '' }}{{ btResult.stats.excess_return_pct }}%</div>
                <div class="muted" style="font-size:11px">基准 {{ btResult.stats.benchmark_return_pct }}% · 超额稳定性 {{ btResult.stats.info_ratio }}</div></div>
              <div class="item"><div class="l">🎯 胜率</div>
                <div class="v">{{ btResult.stats.win_rate_pct }}%
                  <span class="muted" style="font-size:12px">({{ btResult.stats.trades_count }}笔)</span></div></div>
              <div class="item"><div class="l">💹 盈亏比</div><div class="v">{{ btResult.stats.profit_loss_ratio }}</div></div>
              <div class="item"><div class="l">🧾 总费用</div>
                <div class="v" style="font-size:18px">{{ btResult.stats.total_fee?.toLocaleString() }} 元</div></div>
            </div>

            <div style="margin:12px 0">
              <el-button size="small" type="warning" @click="exportBattleCard">🏆 生成战绩图（发朋友圈）</el-button>
              <span class="muted">收益曲线 + 核心数字拼图，带水印与风险提示</span>
            </div>
            <div class="card" v-if="btResult.oos">
              <h3><span class="h-ico">🔬</span>样本内外检验
                <el-tag size="small" :type="btResult.oos.verdict_type" effect="dark"
                        style="margin-left:8px">{{ btResult.oos.verdict }}</el-tag>
                <span class="muted" style="font-weight:400;margin-left:auto">
                  前70%调参 / 后30%验证 · 验证段月胜率 {{ btResult.oos.test_month_win_rate }}%
                </span>
              </h3>
              <el-table :data="[
                {k:'总收益%', a: btResult.oos.train.stats.total_return_pct, b: btResult.oos.test.stats.total_return_pct},
                {k:'年化%', a: btResult.oos.train.stats.cagr_pct, b: btResult.oos.test.stats.cagr_pct},
                {k:'夏普比率', a: btResult.oos.train.stats.sharpe, b: btResult.oos.test.stats.sharpe},
                {k:'最大回撤%', a: btResult.oos.train.stats.max_drawdown_pct, b: btResult.oos.test.stats.max_drawdown_pct},
                {k:'胜率%', a: btResult.oos.train.stats.win_rate_pct, b: btResult.oos.test.stats.win_rate_pct},
                {k:'交易笔', a: btResult.oos.train.stats.trades_count, b: btResult.oos.test.stats.trades_count},
              ]" size="small" style="width:100%">
                <el-table-column label="指标" width="120">
                  <template #default="s"><b>{{ s.row.k }}</b></template>
                </el-table-column>
                <el-table-column label="样本内(70%)" width="160" align="right">
                  <template #default="s"><b :style="{color: btColor(s.row.a)}">{{ s.row.a }}</b></template>
                </el-table-column>
                <el-table-column label="样本外(30%)" width="160" align="right">
                  <template #default="s"><b :style="{color: btColor(s.row.b)}">{{ s.row.b }}</b></template>
                </el-table-column>
                <el-table-column label="解读" min-width="200">
                  <template #default="s"><span class="muted">{{ oosHint(s.row.k, s.row.a, s.row.b) }}</span></template>
                </el-table-column>
              </el-table>
            </div>

            <div class="card" v-if="btResult.mode!=='walkforward'">
              <h3><span class="h-ico">📈</span>权益曲线
                <span class="muted" style="font-weight:400;margin-left:auto">
                  等权合并 {{ btResult.stats.stocks }} 只 · 涨停跳过买入 {{ btResult.stats.skip_limit_up_buys }} 次 · 跌停顺延卖出 {{ btResult.stats.skip_limit_down_sells || 0 }} 次
                </span>
              </h3>
              <div ref="equityChart" style="width:100%;height:380px"></div>
            </div>

            <div class="card" v-if="btResult.stats.drawdown_detail && btResult.stats.drawdown_detail.depth_pct">
              <h3><span class="h-ico">🕳️</span>最大回撤复盘
                <span class="muted" style="font-weight:400;margin-left:auto">
                  这段是策略最难受的日子, 先看能不能接受, 再谈收益
                </span>
              </h3>
              <div class="dd-timeline">
                <div class="dd-node"><div class="l">📍 峰值</div>
                  <div class="v">{{ btResult.stats.drawdown_detail.peak_date }}</div></div>
                <div class="dd-arrow">→ 跌 {{ btResult.stats.drawdown_detail.depth_pct }}% →</div>
                <div class="dd-node"><div class="l">📉 谷底</div>
                  <div class="v">{{ btResult.stats.drawdown_detail.trough_date }}</div></div>
                <div class="dd-arrow">→</div>
                <div class="dd-node"><div class="l">♻️ 恢复</div>
                  <div class="v">{{ btResult.stats.drawdown_detail.recover_date || '尚未恢复' }}</div>
                  <div class="muted" v-if="btResult.stats.drawdown_detail.recover_days != null">
                    用时 {{ btResult.stats.drawdown_detail.recover_days }} 天</div></div>
              </div>
            </div>

            <div class="card" v-if="btResult.stats.monthly_returns && btResult.stats.monthly_returns.length">
              <h3><span class="h-ico">🗓️</span>月度收益
                <span class="muted" style="font-weight:400;margin-left:auto">
                  赢 {{ monthlyWins }} 个月 · 亏 {{ monthlyLosses }} 个月 · 月胜率 {{ monthlyWinRate }}%
                </span>
              </h3>
              <div class="month-grid">
                <div v-for="m in btResult.stats.monthly_returns" :key="m.ym" class="month-cell"
                     :class="{ win: m.ret_pct > 0, loss: m.ret_pct < 0 }">
                  <div class="ym">{{ m.ym }}</div>
                  <div class="ret" :style="{color: btColor(m.ret_pct)}">
                    {{ m.ret_pct > 0 ? '+' : '' }}{{ m.ret_pct }}%</div>
                </div>
              </div>
            </div>

            <div class="card">
              <h3><span class="h-ico">🧾</span>交易明细
                <span class="muted" style="font-weight:400;margin-left:auto">
                  信号日收盘触发 → 次日开盘成交 · 佣金万2.5/印花税万5/滑点万10双边
                </span>
              </h3>
              <el-table :data="btResult.trades" size="small" max-height="420">
                <el-table-column label="日期" width="110">
                  <template #default="s">{{ s.row.date }}</template>
                </el-table-column>
                <el-table-column label="操作" width="96">
                  <template #default="s">
                    <el-tag size="small" effect="light"
                            :type="s.row.action === 'buy' ? 'danger' : s.row.action === 'sell' ? 'success' : 'info'">
                      {{ {buy:'买入', sell:'卖出', skip_buy_limit:'涨停跳过', skip_sell_limit:'跌停顺延'}[s.row.action] || s.row.action }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="价格" width="90" align="right">
                  <template #default="s">{{ s.row.price }}</template>
                </el-table-column>
                <el-table-column label="收益率" width="92" align="right">
                  <template #default="s">
                    <b v-if="s.row.return_pct != null" :style="{color: btColor(s.row.return_pct)}">
                      {{ s.row.return_pct > 0 ? '+' : '' }}{{ s.row.return_pct }}%</b>
                    <span v-else class="muted">—</span>
                  </template>
                </el-table-column>
                <el-table-column label="盈亏" width="104" align="right">
                  <template #default="s">
                    <span v-if="s.row.realized_pnl != null" :style="{color: btColor(s.row.realized_pnl)}">
                      {{ s.row.realized_pnl?.toLocaleString() }}</span>
                    <span v-else class="muted">—</span>
                  </template>
                </el-table-column>
                <el-table-column label="持有" width="70" align="right">
                  <template #default="s">{{ s.row.hold_days != null ? s.row.hold_days + '日' : '—' }}</template>
                </el-table-column>
                <el-table-column label="原因" min-width="130">
                  <template #default="s"><span class="muted">{{ s.row.reason || '-' }}</span></template>
                </el-table-column>
                <el-table-column label="费用" width="86" align="right">
                  <template #default="s">{{ s.row.fee ?? '-' }}</template>
                </el-table-column>
              </el-table>
            </div>

            <div class="card" v-if="btResult.mode==='walkforward'">
              <h3><span class="h-ico">🔬</span>滚动窗口样本外检验
                <el-tag size="small" :type="btResult.consistency.positive_ratio_pct >= 60 ? 'success' : 'danger'"
                  style="margin-left:8px">{{ btResult.consistency.verdict }}</el-tag>
                <span class="muted" style="font-weight:400;margin-left:auto">
                  {{ btResult.consistency.positive_windows }}/{{ btResult.consistency.windows }} 窗口正收益 ·
                  中位 {{ btResult.consistency.median_return_pct }}% · 最差 {{ btResult.consistency.worst_return_pct }}%
                </span>
              </h3>
              <el-table :data="btResult.windows" size="small" stripe style="width:100%">
                <el-table-column label="窗口" width="70" align="center">
                  <template #default="s">第{{ s.row.window }}窗</template>
                </el-table-column>
                <el-table-column label="区间" width="210">
                  <template #default="s"><span class="muted">{{ s.row.from }} ~ {{ s.row.to }}</span></template>
                </el-table-column>
                <el-table-column label="收益%" width="100" align="right">
                  <template #default="s">
                    <b :style="{color: btColor(s.row.stats.total_return_pct)}">
                      {{ s.row.stats.total_return_pct > 0 ? '+' : '' }}{{ s.row.stats.total_return_pct }}%</b>
                  </template>
                </el-table-column>
                <el-table-column label="超额%" width="100" align="right">
                  <template #default="s"><span v-html="fmtPct(s.row.stats.excess_return_pct)"></span></template>
                </el-table-column>
                <el-table-column label="夏普" width="80" align="right">
                  <template #default="s">{{ s.row.stats.sharpe }}</template>
                </el-table-column>
                <el-table-column label="回撤%" width="90" align="right">
                  <template #default="s">{{ s.row.stats.max_drawdown_pct }}%</template>
                </el-table-column>
                <el-table-column label="交易笔" width="80" align="right">
                  <template #default="s">{{ s.row.stats.trades_count }}</template>
                </el-table-column>
                <el-table-column label="胜率%" width="80" align="right">
                  <template #default="s">{{ s.row.stats.win_rate_pct }}%</template>
                </el-table-column>
              </el-table>
            </div>
            <div class="card" v-if="btResult.mode==='portfolio'">
              <h3><span class="h-ico">🎯</span>收益归因
                <span class="muted" style="font-weight:400;margin-left:auto">
                  最大同时持仓 {{ btResult.stats.max_positions }} 只 · 等权槽位
                </span>
              </h3>
              <el-table :data="btResult.attribution" size="small" max-height="360">
                <el-table-column label="股票" min-width="130">
                  <template #default="s"><b>{{ s.row.name }}</b><span class="muted"> {{ s.row.code }}</span></template>
                </el-table-column>
                <el-table-column label="实现盈亏" width="120" align="right">
                  <template #default="s">
                    <b :style="{color: btColor(s.row.pnl)}">{{ s.row.pnl?.toLocaleString() }}</b>
                  </template>
                </el-table-column>
                <el-table-column label="贡献度" width="100" align="right">
                  <template #default="s">{{ s.row.contrib_pct }}%</template>
                </el-table-column>
                <el-table-column label="交易笔" width="90" align="right">
                  <template #default="s">{{ s.row.trades }}</template>
                </el-table-column>
                <el-table-column label="胜率%" width="90" align="right">
                  <template #default="s">{{ s.row.win_rate_pct }}%</template>
                </el-table-column>
              </el-table>
            </div>
            <div class="card" v-else>
              <h3><span class="h-ico">🧮</span>个股表现</h3>
              <el-table :data="btResult.per_stock" size="small" max-height="360">
                <el-table-column label="股票" min-width="130">
                  <template #default="s"><b>{{ s.row.name }}</b><span class="muted"> {{ s.row.code }}</span></template>
                </el-table-column>
                <el-table-column label="总收益%" width="100" align="right">
                  <template #default="s">
                    <b :style="{color: btColor(s.row.stats.total_return_pct)}">{{ s.row.stats.total_return_pct }}%</b>
                  </template>
                </el-table-column>
                <el-table-column label="年化%" width="96" align="right">
                  <template #default="s">{{ s.row.stats.cagr_pct }}%</template>
                </el-table-column>
                <el-table-column label="最大回撤%" width="104" align="right">
                  <template #default="s">{{ s.row.stats.max_drawdown_pct }}%</template>
                </el-table-column>
                <el-table-column label="夏普比率" width="96" align="right">
                  <template #default="s">{{ s.row.stats.sharpe }}</template>
                </el-table-column>
                <el-table-column label="交易数" width="80" align="right">
                  <template #default="s">{{ s.row.stats.trades_count }}</template>
                </el-table-column>
                <el-table-column label="胜率%" width="84" align="right">
                  <template #default="s">{{ s.row.stats.win_rate_pct }}%</template>
                </el-table-column>
              </el-table>
            </div>
          </template>
        </el-tab-pane>

        <!-- ===== 因子IC ===== -->
        <el-tab-pane label="因子IC" name="ic">
          <div class="page-head">
            <span class="sub">因子值 vs 未来20日收益 · 稳定性(IR)≥0.5 且方向一致≥60% 判有效</span>
            <span class="spacer"></span>
            <el-radio-group v-model="icUniverse" size="small">
              <el-radio-button label="watchlist">自选池</el-radio-button>
              <el-radio-button label="ashare">全A抽样300</el-radio-button>
            </el-radio-group>
            <el-button size="small" type="primary" :loading="icLoading" @click="runFactorIC">▶ 跑IC分析</el-button>
          </div>
          <div class="muted" v-if="icLoading" style="margin:6px 0">{{ icStage }}</div>
          <div class="card" v-if="icResult">
            <h3><span class="h-ico">🧪</span>因子有效性
              <span class="muted" style="font-weight:400">
                {{ icResult.stocks }} 只 × {{ icResult.snapshots }} 个月度快照 · 有效 {{ icResult.summary.good }}/{{ icResult.summary.total }}
              </span>
            </h3>
            <div class="evolve-stats" v-if="icResult.summary.good_factors.length">
              <span>有效因子: <b>{{ icResult.summary.good_factors.join('、') }}</b></span>
            </div>
            <el-table :data="icResult.factors" size="small" stripe style="width:100%;margin-top:8px">
              <el-table-column label="因子" width="150">
                <template #default="s"><b>{{ s.row.label }}</b><br /><span class="muted">{{ s.row.factor }}</span></template>
              </el-table-column>
              <el-table-column label="方向" width="70" align="center">
                <template #default="s">{{ s.row.direction }}</template>
              </el-table-column>
              <el-table-column label="平均IC" width="100" align="right">
                <template #default="s"><span v-html="fmtPct(s.row.ic_mean * 100)"></span></template>
              </el-table-column>
              <el-table-column label="稳定性" width="80" align="right">
                <template #default="s"><b>{{ s.row.ir }}</b></template>
              </el-table-column>
              <el-table-column label="同号占比" width="100" align="right">
                <template #default="s">{{ s.row.pos_ratio_pct }}%</template>
              </el-table-column>
              <el-table-column label="结论" width="90" align="center">
                <template #default="s">
                  <el-tag size="small" :type="s.row.verdict==='有效' ? 'success' : s.row.verdict==='待观察' ? 'warning' : 'info'">{{ s.row.verdict }}</el-tag>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>

        <!-- ===== 策略擂台 ===== -->
        <el-tab-pane label="策略擂台" name="arena">
          <div class="page-head">
            <span class="sub">勾选 2～4 条历史回测, 同场对比收益/超额/夏普/回撤</span>
            <span class="spacer"></span>
            <el-button size="small" type="primary" :loading="arenaLoading"
              :disabled="arenaSelected.length < 2" @click="runArena">⚔️ 开始对比</el-button>
          </div>
          <el-table :data="btRuns" size="small" stripe style="width:100%"
                    @selection-change="(v) => arenaSelected = v.slice(0, 4)">
            <el-table-column type="selection" width="50"></el-table-column>
            <el-table-column label="策略" min-width="150">
              <template #default="s"><b>{{ s.row.strategy_name }}</b><br />
                <span class="muted">{{ (s.row.created_at || '').slice(0, 16) }}</span></template>
            </el-table-column>
            <el-table-column label="收益%" width="100" align="right">
              <template #default="s"><span v-html="fmtPct(s.row.stats.total_return_pct)"></span></template>
            </el-table-column>
            <el-table-column label="超额%" width="100" align="right">
              <template #default="s"><span v-html="fmtPct(s.row.stats.excess_return_pct)"></span></template>
            </el-table-column>
            <el-table-column label="夏普" width="80" align="right">
              <template #default="s">{{ s.row.stats.sharpe }}</template>
            </el-table-column>
            <el-table-column label="回撤%" width="90" align="right">
              <template #default="s">{{ s.row.stats.max_drawdown_pct }}%</template>
            </el-table-column>
          </el-table>
          <div class="card" v-if="arenaResult" style="margin-top:12px">
            <h3><span class="h-ico">⚔️</span>对比结果</h3>
            <div ref="arenaRadar" style="width:100%;height:380px"></div>
            <div ref="arenaEquity" style="width:100%;height:340px;margin-top:8px"></div>
          </div>
        </el-tab-pane>
      </el-tabs>
    </section>

    <!-- ============ 自然语言选股 ============ -->
    <section v-if="page==='nl'">
      <div class="page-head">
        <h1>智能选股器</h1>
        <span class="sub">一句话描述形态 · 自动转量化规则 · 无前视后复权筛选</span>
        <span class="spacer"></span>
        <el-tag size="small" effect="plain" type="info">示例: 连续下跌出现止跌信号 / 连跌后放量长下影线</el-tag>
      </div>
      <div class="risk-line">⚠️ 选股结果基于历史数据回测，不代表未来收益，不构成投资建议。</div>
      <div class="card">
        <h3><span class="h-ico">💬</span>选股描述
          <span class="spacer" style="flex:1"></span>
          <el-button size="small" text type="primary" @click="loadRegime">🌡 大盘环境</el-button>
        </h3>
        <div v-if="regime" class="pros-line" style="margin-bottom:12px">
          <span>今日环境:</span><b>{{ regime.regime }}</b>
          <span class="muted">{{ regime.advice }}</span>
        </div>
        <el-input v-model="nlQuery" type="textarea" :rows="2"
          placeholder="比如: 我需要连续下跌、出现止跌信号的股票；或: 连跌止跌或超卖金叉的股票(用或表任一)"></el-input>
        <div class="toolbar" style="margin-top:12px;margin-bottom:0">
          <el-select v-model="nlUniverse" size="small" style="width:190px">
            <el-option label="🌐 A股 + 港股全市场" value="all"></el-option>
            <el-option label="🇨🇳 A股全市场" value="ashare"></el-option>
            <el-option label="🇭🇰 港股全市场" value="hk"></el-option>
            <el-option label="📋 仅自选池" value="watchlist"></el-option>
          </el-select>
          <el-date-picker v-model="nlAsof" type="date" size="small" placeholder="回放日期(空=最新)"
            format="YYYY-MM-DD" value-format="YYYY-MM-DD" style="width:170px" clearable></el-date-picker>
          <el-checkbox v-model="nlUseLlm" size="small" border>AI 增强解析</el-checkbox>
          <el-button type="primary" size="small" :loading="nlLoading" @click="runNlScreen">🔍 筛选</el-button>
          <span class="muted">试试:</span>
          <el-button v-for="ex in nlExamples" :key="ex" size="small" text type="primary"
                     @click="nlQuery = ex; runNlScreen()">{{ ex.slice(0, 10) }}…</el-button>
          <el-button size="small" @click="saveNlScheme" :disabled="!nlParsed">💾 存为方案</el-button>
          <span class="muted">支持"或"(任一满足) · 全市场约数千只, 需 2～5 分钟</span>
        </div>
        <el-progress v-if="nlLoading" :percentage="nlProgress" :stroke-width="8"
          style="margin-top:12px" striped striped-flow></el-progress>
        <div v-if="nlLoading" class="muted" style="margin-top:6px">{{ nlStage }}</div>
      </div>
      <div class="card" v-if="nlSchemes.length">
        <h3><span class="h-ico">📚</span>我的选股方案
          <span class="muted" style="font-weight:400">收盘定时跑 + 命中推送到重点信息/邮件</span>
        </h3>
        <div v-for="sc in nlSchemes" :key="sc.id" class="strategy-item">
          <b>{{ sc.name }}</b>
          <span class="muted">{{ sc.text.slice(0, 40) }}</span>
          <el-tag size="small" effect="plain">{{ {all:'A+港',ashare:'A股',hk:'港股',watchlist:'自选'}[sc.universe] }}</el-tag>
          <el-tag size="small" type="success" v-if="sc.last_hit!=null">上次命中 {{ sc.last_hit }} 只</el-tag>
          <el-tag size="small" type="warning" effect="dark" v-if="sc.last_new">新增 {{ sc.last_new }} 只</el-tag>
          <span class="muted" v-if="sc.last_date">{{ sc.last_date }}</span>
          <span style="flex:1"></span>
          <el-switch v-model="sc._sched" size="small" active-text="收盘定时"
            @change="(v) => setSchemeSchedule(sc, v ? 'daily_close' : 'off')"></el-switch>
          <el-button size="small" @click="rerunScheme(sc)">重跑</el-button>
          <el-button size="small" type="danger" text @click="delScheme(sc)">删</el-button>
        </div>
      </div>
      <div class="card" v-if="nlTasks.length">
        <h3><span class="h-ico">🕘</span>历史任务 <span class="muted" style="font-weight:400">服务重启不丢失</span></h3>
        <div v-for="(t,i) in nlTasks" :key="t.id" class="strategy-item">
          <span class="muted">{{ fmtTaskTs(t.created_at) }}</span>
          <b>{{ t.text.slice(0, 36) }}</b>
          <el-tag size="small" :type="t.status==='done' ? 'success' : t.status==='error' ? 'danger' : 'warning'">{{ t.status==='done' ? ('命中 ' + t.hits + ' 只') : t.status }}</el-tag>
          <span style="flex:1"></span>
          <el-button size="small" text type="primary" v-if="t.status==='done'" @click="loadTaskByIndex(i)">查看</el-button>
        </div>
      </div>
      <div class="card" v-if="nlParsed">
        <h3><span class="h-ico">🧩</span>筛选条件
          <el-tag size="small" :type="nlParsed.via==='llm' ? 'success' : 'info'" style="margin-left:6px">{{ nlParsed.via==='llm' ? 'AI 解析' : '本地解析' }}</el-tag>
          <el-tag size="small" effect="plain" type="info" style="margin-left:6px" v-if="nlResult">{{ nlResult.universe_label }}</el-tag>
          <span class="muted" style="font-weight:400;margin-left:auto" v-if="nlResult && nlResult.status==='done'">数据日期 {{ nlResult.date }} · 扫描 {{ nlResult.scanned }} 只 · 失败 {{ nlResult.failed }} 只</span>
        </h3>
        <div style="font-size:14px;line-height:2">
          <span class="muted">{{ (nlParsed.spec && nlParsed.spec.op)==='any' ? '满足任一：' : '同时满足：' }}</span>
          <el-tag v-for="(e,i) in nlParsed.explained" :key="i" size="small" type="warning" class="tag-many" style="margin-bottom:6px">✓ {{ e }}</el-tag>
        </div>
      </div>
      <div class="card" v-if="nlResult">
        <h3><span class="h-ico">🎯</span>命中 {{ nlResult.hits }} 只
          <el-tag size="small" effect="plain" type="info" style="margin-left:6px" v-if="nlResult.cached">缓存秒回</el-tag>
          <el-tag size="small" effect="plain" type="info" style="margin-left:6px" v-if="nlResult.asof">回放 {{ nlResult.asof }}</el-tag>
          <span class="muted" style="margin-left:8px" v-if="nlWrResult && nlWrResult.overall">
            近{{ nlWrResult.months }}个月胜率 <b :style="{color: btColor(nlWrResult.overall.win_rate_pct - 50)}">{{ nlWrResult.overall.win_rate_pct }}%</b>
            · {{ nlWrResult.overall.signals }} 次信号</span>
          <span class="spacer" style="flex:1"></span>
          <el-button size="small" @click="runNlBacktest" :loading="nlBtLoading" :disabled="!nlResult.items.length">📊 一键回测</el-button>
          <el-button size="small" @click="runNlWinrate" :loading="nlWrLoading" :disabled="!nlParsed">📈 条件胜率</el-button>
          <el-select v-model="nlWrUniverse" size="small" style="width:130px" title="胜率统计范围">
            <el-option label="自选池回放" value="watchlist"></el-option>
            <el-option label="全A回放(慢)" value="ashare"></el-option>
          </el-select>
          <el-button size="small" @click="runNlReview" :loading="nlReviewLoading" :disabled="!nlResult.items.length">🤖 AI 复核</el-button>
          <el-select v-model="nlPoolGroup" size="small" style="width:140px">
            <el-option v-for="g in poolGroupsList" :key="g" :label="'入池分组: ' + g" :value="g"></el-option>
          </el-select>
          <el-button size="small" @click="addNlHitsToPool" :disabled="!nlResult.items.length">+ 全部加入自选池</el-button>
          <el-button size="small" @click="copyCodes(nlResult.items)" :disabled="!nlResult.items.length">📋 复制代码</el-button>
        </h3>
        <div class="toolbar">
          <span class="muted">最少命中条件数</span>
          <el-input-number v-model="nlMinHits" :min="1" :max="12" size="small"></el-input-number>
          <span class="muted">排序</span>
          <el-select v-model="nlSort" size="small" style="width:150px">
            <el-option label="命中条件多 → 少" value="hits"></el-option>
            <el-option label="涨跌幅高 → 低" value="chg"></el-option>
            <el-option label="放量大 → 小" value="vol"></el-option>
          </el-select>
        </div>
        <el-table :data="nlFilteredItems" size="small" stripe style="width:100%"
          :row-class-name="(s) => s.row.hit ? 'screen-hit' : ''">
          <el-table-column prop="code" label="代码" width="90"></el-table-column>
          <el-table-column prop="name" label="名称" width="110"></el-table-column>
          <el-table-column label="数据" width="70" align="center">
            <template #default="s"><el-tag v-if="s.row.stale" size="small" type="danger" :title="s.row.stale_msg">过期</el-tag></template>
          </el-table-column>
          <el-table-column prop="date" label="日期" width="110"></el-table-column>
          <el-table-column prop="close" label="收盘" width="90" align="right">
            <template #default="s">{{ fmtNum(s.row.close) }}</template>
          </el-table-column>
          <el-table-column label="涨跌幅" width="90" align="right" sortable sort-by="change_pct">
            <template #default="s"><span v-html="fmtPct(s.row.change_pct)"></span></template>
          </el-table-column>
          <el-table-column label="命中/条件" width="110" align="center">
            <template #default="s">{{ nlHitCount(s.row) }}/{{ nlRuleCount }}
              <el-tag v-if="nlRuleCount > 1 && nlHitCount(s.row) >= nlRuleCount"
                      size="small" type="warning" effect="dark" style="margin-left:4px">★全中</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="AI" width="90" v-if="nlReviews.length">
            <template #default="s">{{ nlVerdict(s.row.code) }}</template>
          </el-table-column>
          <el-table-column label="关键因子" min-width="240">
            <template #default="s"><span class="muted">{{ nlFactorLine(s.row) }}</span></template>
          </el-table-column>
          <el-table-column label="操作" width="120">
            <template #default="s"><el-button size="small" text type="primary" @click="addOneToPool(s.row)">+ 自选</el-button></template>
          </el-table-column>
        </el-table>
        <div class="muted" v-if="!nlResult.items.length" style="margin-top:10px">暂无命中, 试试放宽条件(比如去掉"放量"或减少连跌天数)。</div>
        <div class="card drawer-card" v-if="nlBtResult" style="margin-top:14px">
          <h3><span class="h-ico">📊</span>组合回测
            <span class="muted" style="font-weight:400">近{{ nlBtResult.params.months }}个月 · 止损{{ nlBtResult.params.stop_loss_pct }}% · 止盈{{ nlBtResult.params.take_profit_pct }}% · 最长持有{{ nlBtResult.params.max_hold_days }}天</span>
          </h3>
          <div class="evolve-stats" v-if="nlBtResult.agg.stocks">
            <span>覆盖 <b>{{ nlBtResult.agg.stocks }}</b> 只</span>
            <span>平均收益 <b>{{ nlBtResult.agg.avg_return_pct }}%</b></span>
            <span>平均超额 <b>{{ nlBtResult.agg.avg_excess_pct }}%</b></span>
            <span>平均胜率 <b>{{ nlBtResult.agg.avg_win_rate }}%</b></span>
            <span>平均最大回撤 <b>{{ nlBtResult.agg.avg_max_dd }}%</b></span>
            <span>总交易 <b>{{ nlBtResult.agg.total_trades }}</b> 次</span>
          </div>
          <el-table :data="nlBtResult.items.slice(0, 20)" size="small" stripe style="width:100%;margin-top:10px">
            <el-table-column prop="code" label="代码" width="90"></el-table-column>
            <el-table-column prop="name" label="名称" width="110"></el-table-column>
            <el-table-column label="收益%" width="90" align="right">
              <template #default="s"><span v-html="fmtPct(s.row.ok ? s.row.stats.total_return_pct : null)"></span></template>
            </el-table-column>
            <el-table-column label="胜率%" width="80" align="right">
              <template #default="s">{{ s.row.ok ? s.row.stats.win_rate_pct + '%' : (s.row.error || '-') }}</template>
            </el-table-column>
            <el-table-column label="交易次" width="80" align="right">
              <template #default="s">{{ s.row.ok ? s.row.stats.trades_count : '-' }}</template>
            </el-table-column>
            <el-table-column label="最大回撤%" width="100" align="right">
              <template #default="s">{{ s.row.ok ? s.row.stats.max_drawdown_pct + '%' : '-' }}</template>
            </el-table-column>
            <el-table-column label="超额%" width="90" align="right">
              <template #default="s"><span v-if="s.row.ok && s.row.stats.excess_return_pct !== undefined" v-html="fmtPct(s.row.stats.excess_return_pct)"></span><span v-else>-</span></template>
            </el-table-column>
          </el-table>
        </div>
        <div class="card drawer-card" v-if="nlWrResult" style="margin-top:14px">
          <h3><span class="h-ico">📈</span>条件历史胜率
            <span class="muted" style="font-weight:400">近{{ nlWrResult.months }}个月逐日回放 · 信号后5日涨跌 · {{ nlWrResult.stocks }} 只覆盖</span>
          </h3>
          <div class="evolve-stats">
            <span>信号 <b>{{ nlWrResult.overall.signals }}</b> 次</span>
            <span>胜率 <b>{{ nlWrResult.overall.win_rate_pct }}%</b></span>
            <span>平均涨幅 <b>{{ nlWrResult.overall.avg_fwd5_pct }}%</b></span>
            <span>中位数 <b>{{ nlWrResult.overall.median_fwd5_pct }}%</b></span>
            <span>最佳 <b>{{ nlWrResult.overall.best_fwd5_pct }}%</b> / 最差 <b>{{ nlWrResult.overall.worst_fwd5_pct }}%</b></span>
          </div>
          <div class="muted" style="margin:8px 0 4px">分规则(哪个条件最有效)：</div>
          <el-table :data="nlWrResult.by_rule" size="small" stripe style="width:100%">
            <el-table-column prop="label" label="条件" width="150"></el-table-column>
            <el-table-column prop="signals" label="信号次" width="90" align="right"></el-table-column>
            <el-table-column prop="avg_fwd5_pct" label="平均涨幅%" width="110" align="right">
              <template #default="s"><span v-html="fmtPct(s.row.avg_fwd5_pct)"></span></template>
            </el-table-column>
            <el-table-column label="胜率%" width="90" align="right">
              <template #default="s">{{ s.row.win_rate_pct }}%</template>
            </el-table-column>
          </el-table>
          <div class="muted" style="margin:8px 0 4px">分月稳定性：</div>
          <div style="font-size:13px">
            <el-tag v-for="m in nlWrResult.by_month" :key="m.month" size="small"
              :type="m.win_rate_pct >= 55 ? 'success' : m.win_rate_pct >= 45 ? 'warning' : 'danger'"
              class="tag-many">
              {{ m.month }} {{ m.win_rate_pct }}%</el-tag>
          </div>
          <div class="muted" style="margin:8px 0 4px">信号常客 TOP：</div>
          <div style="font-size:13px">
            <span v-for="s in nlWrResult.top_stocks" :key="s.code" class="muted" style="margin-right:14px">
              {{ s.name }} {{ s.code }} ×{{ s.signals }} ({{ s.win_rate_pct }}%)</span>
          </div>
        </div>
      </div>
    </section>

    <!-- ============ 板块轮动 ============ -->
    <section v-if="page==='sectors'">
      <div class="page-head">
        <h1>板块轮动</h1>
        <span class="sub">先定行业再挑个股 · 数据日 {{ sectorHeat.date || '-' }}</span>
        <el-tag v-if="sectorHeat.mode==='intraday'" size="small" type="warning" effect="light">当日模式</el-tag>
        <span class="spacer"></span>
        <el-radio-group v-model="sectorKind" size="small" @change="loadSectors">
          <el-radio-button label="industry">行业板块</el-radio-button>
          <el-radio-button label="concept">概念板块</el-radio-button>
        </el-radio-group>
        <el-button size="small" :loading="sectorLoading" @click="loadSectors">刷新</el-button>
      </div>
      <div class="kpi" v-if="sectorHeat.items.length">
        <div class="item"><div class="l">🔥 领涨</div>
          <div class="v" style="font-size:16px;line-height:1.6">
            <span v-for="(b, i) in sectorTop3" :key="b.code" style="margin-right:14px;white-space:nowrap">
              <span class="muted">{{ i + 1 }}.</span> {{ b.name }}
              <b :style="{color: b[sectorValKey] > 0 ? 'var(--up)' : 'var(--down)'}">
                {{ fmtSigned(b[sectorValKey]) }}%</b></span>
          </div></div>
        <div class="item"><div class="l">🧊 领跌</div>
          <div class="v" style="font-size:16px;line-height:1.6">
            <span v-for="(b, i) in sectorBottom3" :key="b.code" style="margin-right:14px;white-space:nowrap">
              <span class="muted">{{ i + 1 }}.</span> {{ b.name }}
              <b :style="{color: b[sectorValKey] > 0 ? 'var(--up)' : 'var(--down)'}">
                {{ fmtSigned(b[sectorValKey]) }}%</b></span>
          </div></div>
        <div class="item"><div class="l">⚖️ 板块强弱</div>
          <div class="v" style="font-size:16px">{{ sectorBreadth.up }} 红 / {{ sectorBreadth.down }} 绿</div>
          <div class="cf-meter"><div class="cf-meter-bull" :style="{width: sectorBreadth.pct + '%'}"></div></div></div>
      </div>
      <div class="skel-kpi" v-else-if="sectorLoading">
        <div class="skel"></div><div class="skel"></div><div class="skel"></div>
      </div>
      <div class="card">
        <h3><span class="h-ico">🗺️</span>
          <span v-if="sectorZoom">🔍 {{ sectorZoom.name }} · 成分展开
            <span class="muted" style="font-weight:400">{{ sectorZoom.members.length }} 只 · 方块大小=|涨跌幅| · 点击个股看详情</span>
          </span>
          <span v-else>{{ sectorHeat.mode==='intraday' ? '当日动量热力' : '动量热力' }}
            <span class="muted" style="font-weight:400" v-if="sectorHeat.mode==='intraday'">颜色=今日加权涨幅 · {{ sectorHeat.note }}</span>
            <span class="muted" style="font-weight:400" v-else>颜色=近20日涨幅(红涨绿跌) · 方块大小=|涨幅|</span>
          </span>
          <span class="spacer"></span>
          <el-button v-if="sectorZoom" size="small" @click="sectorZoomBack">← 返回板块</el-button>
          <el-input v-if="!sectorZoom" v-model="sectorQuery" size="small" clearable placeholder="搜索板块"
                    style="width:150px" prefix-icon="Search" @input="renderSectorTreemap" @clear="renderSectorTreemap" />
          <el-select v-if="!sectorZoom" v-model="sectorSort" size="small" style="width:130px" @change="renderSectorTreemap">
            <el-option label="涨幅优先" value="desc" />
            <el-option label="跌幅优先" value="asc" />
            <el-option label="上涨占比优先" value="up" v-if="sectorHeat.mode==='intraday'" />
          </el-select>
        </h3>
        <div v-if="sectorLoading && !sectorHeat.items.length" class="skel-treemap">
          <i style="flex:2 1 22%;height:150px"></i><i style="flex:1 1 12%;height:150px"></i>
          <i style="flex:1 1 12%;height:150px"></i><i style="flex:1 1 10%;height:150px"></i>
          <i style="flex:1 1 9%;height:150px"></i><i style="flex:1 1 14%;height:150px"></i>
          <i style="flex:2 1 20%;height:120px"></i><i style="flex:1 1 11%;height:120px"></i>
          <i style="flex:1 1 11%;height:120px"></i><i style="flex:1 1 9%;height:120px"></i>
          <i style="flex:1 1 13%;height:120px"></i><i style="flex:1 1 8%;height:120px"></i>
          <i style="flex:1 1 10%;height:100px"></i><i style="flex:1 1 10%;height:100px"></i>
          <i style="flex:1 1 8%;height:100px"></i><i style="flex:1 1 12%;height:100px"></i>
          <i style="flex:1 1 9%;height:100px"></i><i style="flex:1 1 7%;height:100px"></i>
        </div>
        <div v-show="!sectorLoading || sectorHeat.items.length" ref="sectorChart" style="width:100%;height:560px"></div>
        <div class="muted" style="font-size:12px;margin-top:6px" v-if="!sectorZoom">点击板块展开成分股 · {{ sectorHeat.items.length }} 个板块</div>
      </div>
      <div class="sec-grid">
        <div class="card">
          <h3><span class="h-ico">📈</span>涨幅榜 <span class="muted" style="font-weight:400">TOP 10</span></h3>
          <div class="skel-rows" v-if="sectorLoading && !sectorHeat.items.length">
            <div class="skel-row" v-for="i in 10" :key="i">
              <div class="skel" style="width:18px"></div><div class="skel" style="width:88px"></div>
              <div class="skel" style="flex:1"></div><div class="skel" style="width:62px"></div>
            </div>
          </div>
          <div v-for="(b, i) in sectorRankUp" :key="b.code" class="sec-row" @click="loadSectorMembers(b)">
            <span class="sec-idx">{{ i + 1 }}</span>
            <span class="sec-name">{{ b.name }}</span>
            <span class="sec-bar"><i :style="{width: sectorBarW(b), background: 'var(--up)'}"></i></span>
            <b class="sec-val" style="color:var(--up)">{{ fmtSigned(b[sectorValKey]) }}%</b>
          </div>
        </div>
        <div class="card">
          <h3><span class="h-ico">📉</span>跌幅榜 <span class="muted" style="font-weight:400">TOP 10</span></h3>
          <div class="skel-rows" v-if="sectorLoading && !sectorHeat.items.length">
            <div class="skel-row" v-for="i in 10" :key="i">
              <div class="skel" style="width:18px"></div><div class="skel" style="width:88px"></div>
              <div class="skel" style="flex:1"></div><div class="skel" style="width:62px"></div>
            </div>
          </div>
          <div v-for="(b, i) in sectorRankDown" :key="b.code" class="sec-row" @click="loadSectorMembers(b)">
            <span class="sec-idx">{{ i + 1 }}</span>
            <span class="sec-name">{{ b.name }}</span>
            <span class="sec-bar"><i :style="{width: sectorBarW(b), background: 'var(--down)'}"></i></span>
            <b class="sec-val" style="color:var(--down)">{{ fmtSigned(b[sectorValKey]) }}%</b>
          </div>
        </div>
      </div>
      <div class="card" v-if="sectorBoard">
        <h3><span class="h-ico">🧩</span>{{ sectorBoard.name }} 成分股
          <span class="muted" style="font-weight:400" v-if="sectorBoard.r20 != null">近20日 {{ sectorBoard.r20 }}% · 主力净流入 {{ fmtMoney(sectorBoard.net_inflow) }}</span>
          <span class="muted" style="font-weight:400" v-else>今日加权 {{ sectorBoard.r1 }}% · 上涨 {{ sectorBoard.up_ratio }}% · {{ sectorBoard.count }}只</span>
          <span class="spacer"></span>
          <el-button size="small" type="primary" :loading="sectorAdding" @click="addSectorMembers">
            一键入自选池(前{{ sectorMembers.length }}只)</el-button>
        </h3>
        <el-table :data="sectorMembers" size="small" stripe style="width:100%"
                  v-loading="sectorMembersLoading" empty-text="点击热力图选择板块">
          <el-table-column label="股票" min-width="140">
            <template #default="s"><b>{{ s.row.name }}</b><span class="muted"> {{ s.row.code }}</span></template>
          </el-table-column>
          <el-table-column label="现价" width="100" align="right">
            <template #default="s">{{ s.row.price ?? '-' }}</template>
          </el-table-column>
          <el-table-column label="涨跌幅%" width="110" align="right">
            <template #default="s"><span v-html="fmtPct(s.row.change_pct)"></span></template>
          </el-table-column>
          <el-table-column label="操作" width="110" align="center">
            <template #default="s">
              <el-button size="small" text type="primary" @click="addOneMember(s.row)">入池</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </section>

    <!-- ============ 设置 ============ -->
    <section v-if="page==='settings'">
      <div class="page-head">
        <h1>设置</h1>
        <span class="sub">流水线 · 算法 · AI · 邮件通知</span>
      </div>
      <div class="card" v-if="settingsLoaded">
        <h3><span class="h-ico">⚙️</span>全局配置
          <el-button type="primary" style="margin-left:auto" :loading="savingSettings"
                     @click="saveSettings()">保存全部设置</el-button>
        </h3>
        <el-tabs>
          <el-tab-pane label="流水线">
            <div class="settings-grid">
              <div>
                <div class="section-title">运行</div>
                <el-form label-width="150px" label-position="left">
                  <el-form-item label="仅交易时段自动运行">
                    <el-switch v-model="cfg.trading_hours_only" />
                  </el-form-item>
                  <el-form-item label="自动运行间隔(分钟)">
                    <el-input-number v-model="cfg.pipeline_interval_min" :min="1" :max="240" />
                  </el-form-item>
                  <el-form-item label="并发分析股票数">
                    <el-input-number v-model="cfg.pipeline_concurrency" :min="1" :max="10" />
                  </el-form-item>
                  <el-form-item label="单只分析超时(秒)">
                    <el-input-number v-model="cfg.pipeline_stock_timeout" :min="60" :max="900" :step="30" />
                  </el-form-item>
                  <el-form-item label="自选池上限(只)">
                    <el-input-number v-model="cfg.max_pool_size" :min="1" :max="200" />
                  </el-form-item>
                  <el-form-item label="抓取间隔(秒)">
                    <el-input-number v-model="cfg.fetch_delay" :min="0" :max="5" :step="0.05" />
                  </el-form-item>
                </el-form>
              </div>
              <div>
                <div class="section-title">数据抓取</div>
                <el-form label-width="150px" label-position="left">
                  <el-form-item label="K线周期">
                    <el-select v-model="cfg.kline_period" style="width:160px">
                      <el-option label="日线" value="daily" />
                      <el-option label="周线" value="weekly" />
                    </el-select>
                  </el-form-item>
                  <el-form-item label="K线数量">
                    <el-input-number v-model="cfg.kline_count" :min="60" :max="500" :step="20" />
                  </el-form-item>
                  <el-form-item label="每只新闻条数">
                    <el-input-number v-model="cfg.news_per_stock" :min="0" :max="30" />
                  </el-form-item>
                </el-form>
              </div>
            </div>
          </el-tab-pane>

          <el-tab-pane label="算法权重">
            <el-form label-width="170px" label-position="left" style="max-width:640px">
              <el-form-item v-for="(label, key) in {
                weight_trend: '趋势因子', weight_momentum: '动量因子', weight_volume: '量能因子',
                weight_rsi: 'RSI 因子', weight_macd: 'MACD 因子', weight_financial: '财报因子'}" :key="key" :label="label">
                <el-slider v-model="cfg[key]" :min="0" :max="1" :step="0.05" show-input
                           :show-input-controls="false" input-size="small" style="width:100%" />
              </el-form-item>
              <el-form-item label="权重合计">
                <el-tag :type="Math.abs(weightSum-1)<0.01 ? 'success' : 'warning'">{{ weightSum }}</el-tag>
                <span class="muted" style="margin-left:8px">建议合计为 1.00</span>
              </el-form-item>
              <el-form-item label="重点信息评分阈值">
                <el-slider v-model="cfg.alert_score_threshold" :min="50" :max="95" :step="1" show-input
                           :show-input-controls="false" input-size="small" />
              </el-form-item>
            </el-form>
          </el-tab-pane>

          <el-tab-pane label="AI 分析">
            <el-form label-width="150px" label-position="left" style="max-width:640px">
              <el-form-item label="启用 AI 分析">
                <el-switch v-model="cfg.ai_enabled" />
              </el-form-item>
              <el-form-item label="API 地址">
                <el-input v-model="cfg.ai_base_url" placeholder="https://api.deepseek.com/v1" />
              </el-form-item>
              <el-form-item label="模型">
                <el-input v-model="cfg.ai_model" placeholder="deepseek-chat" />
              </el-form-item>
              <el-form-item label="API Key">
                <el-input v-model="cfg.ai_api_key" type="password" show-password
                          :placeholder="cfg.ai_api_key ? '已配置(不修改请保持原样)' : 'sk-...'" />
              </el-form-item>
              <el-form-item label="每日调用上限">
                <el-input-number v-model="cfg.ai_daily_limit" :min="1" :max="5000" />
              </el-form-item>
              <el-form-item label="今日已调用">
                <el-tag size="small">{{ cfg.ai_calls_today ?? 0 }} 次</el-tag>
              </el-form-item>
              <el-form-item label="">
                <el-button @click="testAI">测试 AI 连接</el-button>
              </el-form-item>
            </el-form>
          </el-tab-pane>

          <el-tab-pane label="邮件通知">
            <el-form label-width="150px" label-position="left" style="max-width:680px">
              <el-form-item label="启用邮件发送">
                <el-switch v-model="cfg.email_enabled" />
              </el-form-item>
              <el-form-item label="服务商预设">
                <el-select v-model="smtpPreset" placeholder="选择后自动填充" style="width:220px" @change="applyPreset">
                  <el-option v-for="(v, k) in (cfg.smtp_presets || {})" :key="k" :label="k" :value="k" />
                </el-select>
              </el-form-item>
              <el-form-item label="SMTP 服务器">
                <el-input v-model="cfg.smtp_host" />
              </el-form-item>
              <el-form-item label="端口">
                <el-input-number v-model="cfg.smtp_port" :min="1" :max="65535" />
                <el-checkbox v-model="cfg.smtp_ssl" label="SSL" style="margin-left:16px" />
              </el-form-item>
              <el-form-item label="发件邮箱">
                <el-input v-model="cfg.smtp_user" placeholder="yourname@163.com" />
              </el-form-item>
              <el-form-item label="SMTP 授权码">
                <el-input v-model="cfg.smtp_password" type="password" show-password
                          :placeholder="cfg.smtp_password ? '已配置(不修改请保持原样)' : '邮箱设置中生成的授权码'" />
              </el-form-item>
              <el-form-item label="发件人显示名">
                <el-input v-model="cfg.mail_from_name" />
              </el-form-item>
              <el-form-item label="收件邮箱(每行一个)">
                <el-input v-model="mailToText" type="textarea" :rows="3"
                          placeholder="填写真实收件邮箱, 如: 964468802@qq.com&#10;多个邮箱每行一个; 留空则无法发送邮件" />
              </el-form-item>
              <el-form-item label="">
                <el-button @click="testEmail">发送测试邮件</el-button>
              </el-form-item>
            </el-form>
          </el-tab-pane>
          <el-tab-pane label="授权管理">
            <div style="max-width:680px">
              <div class="section-title">本机授权</div>
              <div class="card drawer-card" style="margin-bottom:14px">
                <div style="display:flex;align-items:center;gap:10px">
                  <div style="flex:1">
                    <b>{{ license.mode === 'licensed' ? '正式版' : license.mode === 'trial' ? '试用版' : '已到期' }}</b>
                    <span class="muted" style="margin-left:8px">{{ licLeftText }} · 机器码 {{ license.machine }}</span>
                  </div>
                  <el-button size="small" type="primary" @click="licenseDlg = true">输入激活码</el-button>
                </div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </section>

    <!-- ============ 日志 ============ -->
    <section v-if="page==='logs'">
      <div class="page-head">
        <h1>运行日志</h1>
        <span class="sub">流水线执行记录 · 最近 200 条</span>
        <span class="spacer"></span>
        <el-button @click="loadLogs">刷新</el-button>
      </div>
      <div class="kpi">
        <div class="item"><div class="l">📜 日志条数</div><div class="v">{{ logs.length }}</div></div>
        <div class="item"><div class="l">🚨 错误</div>
          <div class="v" style="color:var(--up)">{{ logs.filter(l => l.level === 'ERROR').length }}</div></div>
        <div class="item"><div class="l">⚠️ 警告</div>
          <div class="v" style="color:#f5c542">{{ logs.filter(l => l.level === 'WARN').length }}</div></div>
      </div>
      <div class="card">
        <h3><span class="h-ico">📜</span>日志明细</h3>
        <el-table :data="logs" empty-text="暂无日志, 运行流水线后生成">
          <el-table-column label="时间" width="160">
            <template #default="s">{{ fmtTs(s.row.ts) }}</template>
          </el-table-column>
          <el-table-column label="级别" width="94">
            <template #default="s">
              <el-tag :type="s.row.level==='ERROR' ? 'danger' : s.row.level==='WARN' ? 'warning' : 'info'"
                      size="small" effect="light">{{ s.row.level }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="message" label="内容" min-width="600" show-overflow-tooltip />
        </el-table>
      </div>
    </section>
  <!-- 协议弹窗 -->
  <el-dialog v-model="agreement.visible" :title="agreement.title" width="640px">
    <div class="agreement-body" v-html="agreement.body"></div>
    <template #footer>
      <el-button type="primary" @click="agreement.visible=false">我知道了</el-button>
    </template>
  </el-dialog>
    
  </main>

  <!-- ============ 股票详情抽屉 ============ -->
  <el-drawer v-model="detail.visible" size="66%" destroy-on-close @opened="onDetailOpened" @closed="onDetailClosed">
    <template #header>
      <div>
        <b style="font-size:16px">{{ detail.name }}</b>
        <span class="muted"> {{ detail.code }}</span>
        <el-tag v-if="detail.klineSource==='sina-unadj'" size="small" type="warning" effect="light"
                title="备用通道, 不复权, 除权日有缺口">不复权K线</el-tag>
        
        <span v-if="detail.snap" style="margin-left:12px">
          <b>{{ fmtNum(detail.snap.price) }}</b>
          <span v-html="fmtPct(detail.snap.change_pct)"></span>
          <el-tag :type="signalType(detail.snap.signal)" size="small" style="margin-left:8px">{{ detail.snap.signal }}</el-tag>
        </span>
      </div>
    </template>
    <div v-loading="detail.loading">
      <div ref="klineChart" style="width:100%;height:540px"></div>

      <div class="card drawer-card">
        <h3>📐 技术指标</h3>
        <div class="ind-grid">
          <div class="ind-item" v-for="(v, k) in indDisplay" :key="k">
            <span class="k">{{ k }}</span><b>{{ v ?? '-' }}</b>
          </div>
        </div>
      </div>

      <div class="card drawer-card" v-if="finDisplay">
        <h3>🧾 财报分析
          <span class="muted" style="font-weight:400;margin-left:8px">
            {{ detail.fin?.report_name }} · 报告期 {{ detail.fin?.report_date }}
          </span>
        </h3>
        <div class="ind-grid">
          <div class="ind-item" v-for="(v, k) in finDisplay" :key="k">
            <span class="k">{{ k }}</span>
            <b v-html="typeof v === 'string' && v.indexOf('%') > 0 ? finColor(v) : (v ?? '-')"></b>
          </div>
        </div>
        <div v-if="detail.fin && (detail.fin.rev_yoy != null || detail.fin.profit_yoy != null)"
             class="muted" style="margin-top:8px">
          营收 {{ fmtPctText(detail.fin.rev_yoy) }} / 净利 {{ fmtPctText(detail.fin.profit_yoy) }} 同比;
          上期净利 {{ detail.fin.history?.[0]?.profit_yoy != null ? fmtPctText(detail.fin.history[0].profit_yoy) : '-' }}
        </div>
        <div v-else class="muted" style="margin-top:8px">该股票暂无财报数据(非A股或上市未满一个报告期)</div>
      </div>

      <div class="card drawer-card" v-if="prosperityDisplay">
        <h3>🌡️ 景气度分析
          <el-tag size="small" effect="plain"
                  :style="{color: prosperityDisplay.color, borderColor: prosperityDisplay.color}">
            {{ prosperityDisplay.icon }} {{ prosperityDisplay.level_label }} · {{ prosperityDisplay.score }}
          </el-tag>
          <span class="muted" style="font-weight:400">{{ prosperityDisplay.outlook }}</span>
        </h3>
        <div class="pros-grid">
          <div class="pros-item" v-for="(v, k) in prosperityDisplay.components" :key="k">
            <span class="pros-k">{{ prosLabel(k) }}</span>
            <div class="fbar"><i :style="{width: (v ?? 0) + '%', background: prosperityBarColor(k, v)}"></i></div>
            <b class="fv">{{ v ?? '-' }}</b>
          </div>
        </div>
        <div class="pros-meter">
          <div class="pros-meter-fill" :style="{width: (prosperityDisplay.score ?? 0) + '%', background: prosperityDisplay.color}"></div>
        </div>
        <div class="pros-ticks">
          <span>衰退20</span><span>低迷40</span><span>平稳65</span><span>景气80</span><span>过热</span>
        </div>
        <div v-for="n in (prosperityDisplay.notes||[])" :key="n" class="alert-line">• {{ n }}</div>
        <div v-if="prosperityDisplay.details" class="muted" style="margin-top:10px;font-size:11px">
          <span v-for="(arr, dk) in prosperityDisplay.details" :key="dk" class="pros-detail-tag">
            {{ prosLabel(String(dk).replace('_notes','')) }}: {{ arr.join(' · ') || '—' }}
          </span>
        </div>
      </div>

      <div class="card drawer-card" v-if="cfDisplay">
        <h3>🎯 技术面多维共振
          <el-tag size="small" :type="cfTagType" effect="dark" style="margin-left:8px">
            {{ cfDisplay.level_label }} {{ cfDisplay.direction }}
          </el-tag>
          <span class="muted" style="font-weight:400">
            多方 {{ cfDisplay.bull_count }} 项(权重 {{ cfDisplay.bull_weight }})
            / 空方 {{ cfDisplay.bear_count }} 项(权重 {{ cfDisplay.bear_weight }})
            / 共振度 {{ cfDisplay.ratio }}%
          </span>
        </h3>
        <div class="cf-meter">
          <div class="cf-meter-bear" :style="{flex: cfDisplay.bear_weight || 0.001}"></div>
          <div class="cf-meter-mid" :style="{flex: Math.max(cfDisplay.total * 1.2 - cfDisplay.bull_weight - cfDisplay.bear_weight, 0.001)}"></div>
          <div class="cf-meter-bull" :style="{flex: cfDisplay.bull_weight || 0.001}"></div>
        </div>
        <div class="cf-legend muted">
          <span>🟥 空头 {{ cfDisplay.bear_weight }}</span>
          <span>⬜ 中性 {{ cfDisplay.total - cfDisplay.bull_count - cfDisplay.bear_count }}</span>
          <span>🟩 多头 {{ cfDisplay.bull_weight }}</span>
        </div>
        <div class="cf-cols">
          <div class="cf-col">
            <div class="cf-col-title up">▲ 多头信号 ({{ cfDisplay.bull.length }})</div>
            <div v-for="s in cfDisplay.bull" :key="s.name" class="cf-item">
              <b>{{ s.name }}</b><span class="cf-w">权重{{ s.weight }}</span>
              <div class="muted">{{ s.detail }}</div>
            </div>
            <div v-if="!cfDisplay.bull.length" class="muted" style="padding:4px 0">无</div>
          </div>
          <div class="cf-col">
            <div class="cf-col-title down">▼ 空头信号 ({{ cfDisplay.bear.length }})</div>
            <div v-for="s in cfDisplay.bear" :key="s.name" class="cf-item">
              <b>{{ s.name }}</b><span class="cf-w">权重{{ s.weight }}</span>
              <div class="muted">{{ s.detail }}</div>
            </div>
            <div v-if="!cfDisplay.bear.length" class="muted" style="padding:4px 0">无</div>
          </div>
          <div class="cf-col">
            <div class="cf-col-title" style="color:#5f7191">◆ 中性信号 ({{ cfDisplay.neutral.length }})</div>
            <div v-for="s in cfDisplay.neutral" :key="s.name" class="cf-item">
              <b>{{ s.name }}</b><span class="cf-w">权重{{ s.weight }}</span>
              <div class="muted">{{ s.detail }}</div>
            </div>
            <div v-if="!cfDisplay.neutral.length" class="muted" style="padding:4px 0">无</div>
          </div>
        </div>
      </div>

      <div class="card drawer-card" v-if="detail.snap">
        <div class="section-title">算法评分: <b :style="{color: scoreColor(detail.snap.score)}">{{ detail.snap.score }}</b>
          ({{ detail.snap.signal }}) · 因子:
          <el-tag v-for="(v, k) in detail.snap.factors" :key="k" size="small" class="tag-many">
            {{ k }} {{ v }}
          </el-tag>
        </div>
        <div v-for="(n, i) in detail.snap.notes" :key="i" class="alert-line">• {{ n }}</div>
        <div class="muted" style="margin-top:6px">
          20日动量 {{ detail.snap.stats?.momentum_20d_pct ?? '-' }}% ·
          20日年化波动 {{ detail.snap.stats?.volatility_20d_pct ?? '-' }}% ·
          距60日高点 {{ detail.snap.stats?.near_high_60d_pct ?? '-' }}% ·
          布林位置 {{ detail.snap.stats?.boll_position_pct ?? '-' }}%
        </div>
        <div v-if="detail.snap.ai" class="ai-block">
          <b>🤖 AI 分析</b> <span class="muted">置信度 {{ detail.snap.ai.confidence ?? '-' }}</span>
          <div><b>趋势:</b> {{ detail.snap.ai.trend }}</div>
          <div><b>分析:</b> {{ detail.snap.ai.summary }}</div>
          <div><b>风险:</b> {{ detail.snap.ai.risk }}</div>
          <div><b>建议:</b> {{ detail.snap.ai.suggestion }}</div>
        </div>
      </div>

      <div class="card drawer-card" v-if="detail.history.length > 1">
        <h3>📉 评分历史</h3>
        <div ref="scoreChart" style="width:100%;height:180px"></div>
      </div>

      <div class="card drawer-card">
        <h3>📰 相关新闻 ({{ detail.news.length }})</h3>
        <template v-if="detail.news.length">
          <div v-for="(n, i) in detail.news" :key="i" class="alert-line">
            <div style="flex:1">
              <a class="news-title" :href="n.url" target="_blank" rel="noopener">{{ n.title }}</a>
              <span class="muted">{{ n.source }} {{ (n.published || '').slice(0, 16) }}</span>
            </div>
          </div>
        </template>
        <el-empty v-else description="暂无新闻" :image-size="48" />
      </div>
      <div class="card drawer-card">
        <h3>📢 公司公告 ({{ detail.anns.length }})
          <span class="muted" style="font-weight:400" v-if="detail.annsLoading">加载中…</span>
          <el-button size="small" text type="primary" style="margin-left:auto"
            @click="loadDetailAnns" v-if="!detail.anns.length && !detail.annsLoading">加载公告</el-button>
        </h3>
        <template v-if="detail.anns.length">
          <div v-for="(a, i) in detail.anns.slice(0, 15)" :key="i" class="alert-line">
            <el-tag size="small" :type="a.level==='good' ? 'success' : a.level==='bad' ? 'danger' : 'info'">{{ a.cat }}</el-tag>
            <div style="flex:1">
              <a class="news-title" :href="a.url" target="_blank" rel="noopener">{{ a.title }}</a>
              <span class="muted">{{ a.date }}</span>
            </div>
          </div>
        </template>
        <el-empty v-else-if="!detail.annsLoading" description="点击加载公告查看" :image-size="48" />
      </div>
    </div>
  </el-drawer>

  <!-- ============ 新增/编辑股票对话框 ============ -->
  <el-dialog v-model="stockDlg.visible" :title="stockDlg.mode === 'add' ? '新增自选股' : '编辑自选股'"
             width="440px" destroy-on-close>
    <el-form label-width="90px" @submit.prevent>
      <el-form-item v-if="stockDlg.mode === 'add'" label="股票代码">
        <el-select v-model="stockDlg.selected" filterable remote clearable allow-create
                   default-first-option :remote-method="searchStocks" :loading="stockDlg.searching"
                   placeholder="输入名称/拼音/代码, 如 茅台 / GZMT / 600519" style="width:100%"
                   @change="onStockPicked">
          <el-option v-for="o in stockDlg.options" :key="o.value" :label="o.label" :value="o.value">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
              <span>{{ o.name }}</span>
              <span class="muted">{{ o.code }} · {{ o.marketLabel }}</span>
            </div>
          </el-option>
        </el-select>
        <div class="muted" style="margin-top:4px">支持中文名 / 拼音首字母 / 代码, 也可直接手输代码回车</div>
      </el-form-item>
      <el-form-item v-else label="股票代码">
        <el-input v-model="stockDlg.code" disabled />
      </el-form-item>
      <el-form-item v-if="stockDlg.mode === 'add'" label="市场">
        <el-select v-model="stockDlg.market" style="width:100%">
          <el-option label="自动识别" value="auto" />
          <el-option label="沪市" value="sh" />
          <el-option label="深市" value="sz" />
          <el-option label="北交所" value="bj" />
          <el-option label="港股" value="hk" />
          <el-option label="美股" value="us" />
          <el-option label="美股(NYSE)" value="usny" />
          <el-option label="美股(AMEX)" value="usamx" />
        </el-select>
      </el-form-item>
      <el-form-item label="名称">
        <el-input v-model="stockDlg.name" placeholder="留空则自动获取" />
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="stockDlg.note" type="textarea" :rows="2" placeholder="可选, 如关注理由" />
      </el-form-item>
      <el-form-item label="分组">
        <el-select v-model="stockDlg.group_name" style="width:100%">
          <el-option v-for="g in poolGroupsList" :key="g" :label="g" :value="g"></el-option>
        </el-select>
      </el-form-item>
      <el-alert v-if="stockDlg.quote" type="success" :closable="false" style="margin-bottom:4px"
                :title="(stockDlg.quote.name || stockDlg.code) + '  最新价 ' + fmtNum(stockDlg.quote.price) + '  ' + fmtPctRaw(stockDlg.quote.change_pct)" />
    </el-form>
    <template #footer>
      <el-button @click="stockDlg.visible = false">取消</el-button>
      <el-button type="primary" @click="saveStock">保存</el-button>
    </template>
  </el-dialog>
</div>
`;

const app = createApp({
  template: TEMPLATE,
  data() {
    const q = new URLSearchParams(location.search);
    const startPage = q.get("page");
    return {
      page: ["dashboard", "pool", "hold", "analyses", "news", "alerts", "nl", "sectors", "quant", "settings", "logs"]
        .includes(startPage) ? startPage : "dashboard",
      pages: [
        { key: "dashboard", label: "仪表盘", icon: "🧭" },
        { key: "pool", label: "自选池", icon: "📋" },
        { key: "hold", label: "模拟持仓", icon: "💼" },
        { key: "analyses", label: "AI 分析", icon: "🤖" },
        { key: "news", label: "新闻资讯", icon: "📰" },
        { key: "alerts", label: "重点信息", icon: "🔥" },
        { key: "nl", label: "智能选股器", icon: "💬" },
        { key: "sectors", label: "板块轮动", icon: "🗺️" },
        { key: "quant", label: "量化实验室", icon: "🧪" },
        { key: "settings", label: "设置", icon: "⚙️" },
        { key: "logs", label: "运行日志", icon: "📜" },
      ],
      health: { trading: false, time: "" },
      dataHealth: null,
      healthLoading: false,
      sectorKind: "industry",
      sectorHeat: { items: [], date: "", mode: "history", note: "" },
      sectorLoading: false,
      sectorSort: "desc",
      sectorQuery: "",
      sectorZoom: null,
      sectorBoard: null,
      sectorMembers: [],
      sectorMembersLoading: false,
      sectorAdding: false,
      watchlist: [],
      watchGroups: [],
      poolFilterGroup: "全部",
      poolMax: 20,
      analyses: [],
      alerts: [],
      logs: [],
      newsItems: [],
      newsCode: "",
      eventsGroups: [],
      eventsTotal: 0,
      eventsDays: 14,
      eventsLoading: false,
      eventsScanning: false,
      settingsLoaded: false,
      cfg: {},
      smtpPreset: "",
      mailToText: "",
      savingSettings: false,
      /* 流水线状态 */
      status: { running: false, progress: "", stocks_done: 0, stocks_total: 0, errors: [], last_summary: null },
      runningPipeline: false,
      /* 自选池弹窗 */
      stockDlg: { visible: false, mode: "add", code: "", name: "", note: "", market: "auto",
                  group_name: "默认",
                  quote: null, quoteLoading: false, selected: "", options: [], searching: false },
      /* AI 分析页筛选 */
      aiFilter: "全部",
      aiSort: "score",
      aiQuery: "",
      /* 仪表盘分布筛选 {type:'dist'|'cf', key, label} */
      dashFilter: null,
      confidenceColor: [
        { color: "#00e5a0", percentage: 40 },
        { color: "#f5c542", percentage: 70 },
        { color: "#ff5c6e", percentage: 100 },
      ],
      /* 量化实验室 */
      quantTab: "strategy",
      qspec: null,
      quantStrategies: [],
      factorDefs: [],
      ruleOps: [],
      screenResult: null,
      btResult: null,
      btRuns: [],
      license: { ok: true, mode: "trial", machine: "", days_left: 7 },
      licenseDlg: false,
      licenseToken: "",
      licenseLoading: false,
      agreement: { visible: false, title: "", body: "" },
      plans: [
        { key: "trial", name: "试用版", price: "¥0", unit: "/7天",
          cta: "自动开通",
          feats: ["全部功能", "到期锁定数据接口", "输入激活码解锁"] },
        { key: "monthly", name: "月卡", price: "¥29.9", unit: "/月",
          cta: "联系卖家开通",
          feats: ["全部功能", "1 台设备", "微信答疑"] },
        { key: "yearly", name: "年卡", price: "¥299", unit: "/年",
          cta: "联系卖家开通",
          feats: ["全部功能", "1 台设备(可换机)", "版本升级", "选股方案模板", "微信答疑"] },
      ],
      qSaving: false,
      qScreening: false,
      qBacktesting: false,
      qOos: true,
      qStrategyId: null,
      qPortfolio: false,
      qMaxPositions: 5,
      qWindows: 0,
      icUniverse: "watchlist",
      icLoading: false,
      icStage: "",
      icResult: null,
      arenaSelected: [],
      arenaLoading: false,
      arenaResult: null,
      /* 智能选股器 */
      nlQuery: "连续下跌、出现止跌信号的股票",
      nlExamples: ["连续下跌后出现止跌信号的股票", "连跌后放量长下影线的股票", "超卖金叉的股票"],
      guideSeen: localStorage.getItem("ad_guide_seen") === "1",
      guideVisible: false, transferReq: "",
      holdings: [], holdSummary: null, holdDlg: false,
      holdForm: { code: "", buy_price: null, qty: 100, buy_date: "", note: "" },
      missedInfo: null, catchupLoading: false,
      nlUniverse: "all",
      nlUseLlm: false,
      nlLoading: false,
      nlProgress: 0,
      nlStage: "",
      nlParsed: null,
      nlResult: null,
      nlAsof: null,
      nlMinHits: 1,
      nlSort: "hits",
      nlSchemes: [],
      nlTasks: [],
      nlReviews: [],
      nlReviewLoading: false,
      nlWrResult: null,
      nlWrLoading: false,
      nlWrUniverse: "watchlist",
      nlBtResult: null,
      nlBtLoading: false,
      nlPoolGroup: "默认",
      regime: null,
      /* 自我进化 */
      evolveCfg: { generations: 5, population: 6, kline_count: 260 },
      evolveStatus: { running: false, progress: "", generation: 0, generations: 0,
                      tested: 0, skipped_dup: 0, invalid: 0, best_fitness: null,
                      error: null, leaderboard: [], best: null },
      evolveTimer: null,
      evolveRuns: [],
      /* 详情抽屉 */
      detail: {
        visible: false, opened: false, code: "", name: "", loading: false,
        klines: [], klineSource: "eastmoney", news: [], anns: [], annsLoading: false,
        history: [], snap: null, fin: null,
        confluenceLive: null, rendered: false,
      },
      charts: {},
      statusTimer: null,
      healthTimer: null,
    };
  },

  computed: {
    licLeftText() {
      // 侧栏授权徽: 永久版不显示天数, 试用/期限版显示剩余
      const l = this.license || {};
      if (!l.ok) return "已到期";
      if (l.mode === "licensed")
        return l.days_left == null ? "永久授权" : `剩 ${l.days_left} 天`;
      return `试用剩 ${l.days_left} 天`;
    },
    subBanner() {
      // 订阅体系已下线(私有化一机一码), 保留占位避免模板报错
      return null;
    },
    licenseBanner() {
      const l = this.license || {};
      if (l.mode === "licensed") {
        if (l.days_left != null && l.days_left <= 7)
          return { expired: false, text: `授权剩 ${l.days_left} 天到期, 到期后功能锁定, 请联系卖家续期。` };
        return null;
      }
      if (l.mode === "trial")
        return { expired: false,
                 text: `试用中, 剩 ${l.days_left} 天。正式使用请联系卖家获取激活码(一机一码)。` };
      return { expired: true, text: "授权已过期, 全部数据接口已锁定, 请输入激活码解锁。" };
    },
    quotaLow() {
      return false;
    },
    sectorValKey() {
      return this.sectorHeat.mode === "intraday" ? "r1" : "r20";
    },
    sectorSorted() {
      const k = this.sectorValKey;
      return (this.sectorHeat.items || []).filter((x) => x[k] != null)
        .slice().sort((a, b) => b[k] - a[k]);
    },
    sectorTop3() { return this.sectorSorted.slice(0, 3); },
    monthlyWins() {
      return ((this.btResult && this.btResult.stats.monthly_returns) || [])
        .filter((m) => m.ret_pct > 0).length;
    },
    monthlyLosses() {
      return ((this.btResult && this.btResult.stats.monthly_returns) || [])
        .filter((m) => m.ret_pct < 0).length;
    },
    monthlyWinRate() {
      const ms = (this.btResult && this.btResult.stats.monthly_returns) || [];
      return ms.length ? Math.round((this.monthlyWins / ms.length) * 100) : 0;
    },
    sectorBottom3() { return this.sectorSorted.slice(-3).reverse(); },
    sectorRankUp() { return this.sectorSorted.slice(0, 10); },
    sectorRankDown() { return this.sectorSorted.slice(-10).reverse(); },
    sectorMaxAbs() {
      const k = this.sectorValKey;
      return Math.max(0.5, ...(this.sectorHeat.items || []).map((x) => Math.abs(x[k] || 0)));
    },
    sectorBreadth() {
      const k = this.sectorValKey;
      const items = (this.sectorHeat.items || []).filter((x) => x[k] != null);
      const up = items.filter((x) => x[k] > 0).length;
      return { up, down: items.length - up, pct: items.length ? Math.round(up * 100 / items.length) : 0 };
    },
    nlRuleCount() {
      const spec = (this.nlParsed && this.nlParsed.spec) || {};
      return (spec.rules || []).length || 1;
    },
    nlFilteredItems() {
      if (!this.nlResult || !this.nlResult.items) return [];
      let items = this.nlResult.items.filter((r) => this.nlHitCount(r) >= (this.nlMinHits || 1));
      const f = (r, k) => (r.factors && r.factors[k]) || 0;
      if (this.nlSort === "chg") {
        items = items.slice().sort((a, b) => (b.change_pct || -999) - (a.change_pct || -999));
      } else if (this.nlSort === "vol") {
        items = items.slice().sort((a, b) => f(b, "vol_spike") - f(a, "vol_spike"));
      } else {
        items = items.slice().sort((a, b) => this.nlHitCount(b) - this.nlHitCount(a));
      }
      return items;
    },
    poolGroupsList() {
      const names = new Set(["默认"]);
      (this.watchGroups || []).forEach((g) => names.add(g.name));
      (this.watchlist || []).forEach((s) => names.add(s.group_name || "默认"));
      return [...names];
    },
    filteredWatchlist() {
      if (this.poolFilterGroup === "全部") return this.watchlist;
      return this.watchlist.filter((s) => (s.group_name || "默认") === this.poolFilterGroup);
    },
    avgScore() {
      const list = this.analyses.filter((a) => typeof a.payload?.score === "number");
      if (!list.length) return null;
      return (list.reduce((s, a) => s + a.payload.score, 0) / list.length).toFixed(1);
    },
    aiSummary() {
      let bull = 0, neutral = 0, bear = 0, sum = 0, n = 0, last = "";
      for (const a of this.analyses) {
        const p = a.payload || {};
        if (p.signal === "看多") bull++;
        else if (p.signal === "看空") bear++;
        else neutral++;
        if (typeof p.score === "number") { sum += p.score; n++; }
        if (a.ts && a.ts > last) last = a.ts;
      }
      return {
        bull, neutral, bear,
        avgScore: n ? (sum / n).toFixed(1) : "-",
        lastRun: last ? this.fmtTs(last).slice(5, 16) : "-",
      };
    },
    analysesView() {
      let list = this.analyses.slice();
      const q = (this.aiQuery || "").trim().toLowerCase();
      if (q) list = list.filter((a) => (a.code + " " + (a.name || "")).toLowerCase().indexOf(q) >= 0);
      if (this.aiFilter !== "全部") {
        list = list.filter((a) => (a.payload?.signal) === this.aiFilter);
      }
      const sig = this.aiSort || "score";
      const num = (a) => {
        if (sig === "confidence") return a.payload?.ai?.confidence;
        if (sig === "profit_yoy") return a.payload?.financials?.profit_yoy;
        return a.payload?.score;
      };
      if (sig === "code") {
        list.sort((x, y) => String(x.code).localeCompare(String(y.code)));
      } else {
        list.sort((x, y) => (num(y) ?? -99999) - (num(x) ?? -99999));
      }
      return list;
    },
    analysesByCode() {
      const m = {};
      this.analyses.forEach((a) => (m[a.code] = a));
      return m;
    },
    watchlistByName() {
      const m = {};
      this.watchlist.forEach((s) => (m[s.code] = s));
      return m;
    },
    newsFiltered() {
      const list = this.newsCode
        ? this.newsItems.filter((n) => n.code === this.newsCode)
        : this.newsItems;
      // 同批抓取的 ts 相同, 按发布时间倒序展示
      return list.slice().sort((a, b) => {
        const pa = a.published || "", pb = b.published || "";
        if (pa !== pb) return pa < pb ? 1 : -1;
        return (b.ts || 0) - (a.ts || 0);
      });
    },
    cfDisplay() {
      return this.detail.snap?.confluence || this.detail.confluenceLive || null;
    },
    prosperityDisplay() {
      return this.detail.snap?.prosperity || null;
    },
    distStats() {
      let up = 0, down = 0, flat = 0;
      for (const a of this.analyses) {
        const c = a.payload?.change_pct;
        if (c == null) flat++;
        else if (c > 0) up++;
        else if (c < 0) down++;
        else flat++;
      }
      return { up, down, flat };
    },
    distGroups() {
      const g = { up: [], down: [], flat: [] };
      for (const a of this.analyses) {
        const c = a.payload?.change_pct;
        if (c == null) g.flat.push(a);
        else if (c > 0) g.up.push(a);
        else if (c < 0) g.down.push(a);
        else g.flat.push(a);
      }
      return g;
    },
    distLegend() {
      return {
        down: { label: "下跌", list: this.distGroups.down },
        flat: { label: "平盘", list: this.distGroups.flat },
        up: { label: "上涨", list: this.distGroups.up },
      };
    },
    cfGroups() {
      const g = { strong_bull: [], bull: [], mixed: [], bear: [], strong_bear: [] };
      for (const a of this.analyses) {
        const lv = a.payload?.confluence?.level;
        if (lv && lv in g) g[lv].push(a);
      }
      return g;
    },
    analysesTable() {
      if (!this.dashFilter) return this.analyses;
      const { type, key } = this.dashFilter;
      if (type === "cf") {
        return this.analyses.filter((a) => (a.payload?.confluence?.level) === key);
      }
      return this.distGroups[key] || [];
    },
    cfDist() {
      const conf = { strong_bull: 0, bull: 0, mixed: 0, bear: 0, strong_bear: 0 };
      for (const a of this.analyses) {
        const lv = a.payload?.confluence?.level;
        if (lv && lv in conf) conf[lv]++;
      }
      return {
        strong_bull: { label: "强烈多头共振", count: conf.strong_bull },
        bull: { label: "多头共振", count: conf.bull },
        mixed: { label: "多空分歧", count: conf.mixed },
        bear: { label: "空头共振", count: conf.bear },
        strong_bear: { label: "强烈空头共振", count: conf.strong_bear },
      };
    },
    analyzedCount() {
      return this.watchlist.filter((s) => this.analysesByCode[s.code]).length;
    },
    factorGroups() {
      const groups = [];
      const byGroup = {};
      for (const f of this.factorDefs) {
        if (!byGroup[f.group]) {
          byGroup[f.group] = { group: f.group, items: [] };
          groups.push(byGroup[f.group]);
        }
        byGroup[f.group].items.push(f);
      }
      return groups;
    },
    screenFactorCols() {
      const keys = [];
      const seen = new Set();
      for (const g of ["entry", "exit"]) {
        for (const r of (this.qspec?.[g]?.rules || [])) {
          if (!seen.has(r.factor)) { seen.add(r.factor); keys.push(r.factor); }
        }
      }
      return keys;
    },
    evolvePct() {
      const s = this.evolveStatus;
      if (!s.running && s.progress) return 100;
      if (!s.generations) return 0;
      return Math.min(99, Math.round((s.generation / s.generations) * 100));
    },
    champStats() {
      const st = this.evolveStatus.best?.stats || {};
      return {
        "综合评分": fitScore(this.evolveStatus.best?.fitness),
        "总收益": (st.total_return_pct ?? '-') + "%",
        "年化": (st.cagr_pct ?? '-') + "%",
        "最大回撤": (st.max_drawdown_pct ?? '-') + "%",
        "夏普比率": st.sharpe ?? '-',
        "胜率": (st.win_rate_pct ?? '-') + "%",
        "交易次数": st.trades_count ?? '-',
        "盈亏比": st.profit_loss_ratio ?? '-',
        "覆盖股票": st.stocks ?? '-',
      };
    },
    cfLevelTagType() {
      return (lv) => (lv === "strong_bull" ? "danger"
        : lv === "bull" ? "warning"
        : lv === "strong_bear" || lv === "bear" ? "success" : "info");
    },
    cfTagType() {
      const lv = this.cfDisplay?.level;
      if (lv === "strong_bull") return "danger";
      if (lv === "bull") return "warning";
      if (lv === "strong_bear") return "success";
      if (lv === "bear") return "success";
      return "info";
    },
    finDisplay() {
      const f = this.detail.fin || this.detail.snap?.financials;
      if (!f || !f.report_date) return null;
      const yi = (v) => (v != null && v !== "" ? (Number(v) / 1e8).toFixed(2) : null);
      const pct2 = (v) => (v != null && v !== "" ? Number(v).toFixed(2) + "%" : null);
      const num2 = (v) => (v != null && v !== "" ? Number(v).toFixed(2) : null);
      return {
        "报告期": f.report_name || f.report_date,
        "营收(亿)": yi(f.rev),
        "营收同比": f.rev_yoy != null ? fmtPctText(f.rev_yoy) : null,
        "净利(亿)": yi(f.profit),
        "净利同比": f.profit_yoy != null ? fmtPctText(f.profit_yoy) : null,
        "EPS": num2(f.eps),
        "ROE(加权)": pct2(f.roe),
        "毛利率": pct2(f.gross_margin),
        "净利率": pct2(f.net_margin),
        "资产负债率": pct2(f.debt_ratio),
        "每股现金流": num2(f.ocf_per_share),
      };
    },
    indDisplay() {
      const snap = this.detail.snap?.indicators || {};
      const computed = this.detail.klines.length ? this.computedInd() : {};
      const pick = (a, b) => (a !== null && a !== undefined ? a : b);
      return {
        "MA5": pick(snap.ma5, computed.ma5), "MA10": pick(snap.ma10, computed.ma10),
        "MA20": pick(snap.ma20, computed.ma20), "MA60": pick(snap.ma60, computed.ma60),
        "MACD DIF": pick(snap.macd_dif, computed.dif), "DEA": pick(snap.macd_dea, computed.dea),
        "MACD 柱": pick(snap.macd_hist, computed.hist),
        "RSI6": pick(snap.rsi6, computed.rsi6), "RSI12": pick(snap.rsi12, computed.rsi12),
        "RSI24": pick(snap.rsi24, computed.rsi24),
        "KDJ K": snap.kdj_k, "KDJ D": snap.kdj_d, "KDJ J": snap.kdj_j,
        "BOLL 上轨": snap.boll_up, "BOLL 中轨": snap.boll_mid, "BOLL 下轨": snap.boll_low,
        "ATR14": snap.atr14,
        "5日均量(万手)": snap.vol_ma5 != null ? +(snap.vol_ma5 / 10000).toFixed(2) : null,
        "10日均量(万手)": snap.vol_ma10 != null ? +(snap.vol_ma10 / 10000).toFixed(2) : null,
      };
    },
  },

  async mounted() {
    // 私有化单机: 无账号体系, 先拉授权状态再加载数据
    await this.loadLicense();
    await this.refreshAll();
    // 自适应轮询: 运行中 3 秒, 空闲 15 秒(省日志 + 省本机开销)
    const tick = () => {
      this.pollStatus();
      clearInterval(this.statusTimer);
      this.statusTimer = setInterval(tick, this.status.running ? 3000 : 15000);
    };
    this.statusTimer = setInterval(tick, 3000);
    this.healthTimer = setInterval(() => this.loadHealth(), 30000);
    this.loadSchemes();
    this.loadNlTasks();
    this.loadRegime();
  },
  beforeUnmount() {
    clearInterval(this.statusTimer);
    clearInterval(this.healthTimer);
  },

  methods: {
    /* ---------- 格式化 ---------- */
    fmtSigned(v) {
      if (v === null || v === undefined || v === "") return "-";
      const n = +v;
      return `${n > 0 ? "+" : ""}${n.toFixed(2)}`;
    },
    sectorBarW(b) {
      const v = Math.abs(b[this.sectorValKey] || 0);
      return Math.max(4, Math.round(v / this.sectorMaxAbs * 100)) + "%";
    },
    fmtPct(v) {
      if (v === null || v === undefined || v === "") return "-";
      const n = +v;
      const cls = n > 0 ? "up" : n < 0 ? "down" : "flat";
      return `<span class="${cls}">${n > 0 ? "+" : ""}${n.toFixed(2)}%</span>`;
    },
    fmtNum(v, digits = 2) {
      return v === null || v === undefined || v === "" ? "-" : (+v).toFixed(digits);
    },
    fmtAmount(v) {
      if (v === null || v === undefined) return "-";
      if (v >= 1e8) return (v / 1e8).toFixed(2) + "亿";
      if (v >= 1e4) return (v / 1e4).toFixed(1) + "万";
      return String(v);
    },
    scoreColor(score) {
      if (score === null || score === undefined) return FLAT;
      return score >= 65 ? UP : score <= 35 ? DOWN : "#f5c542";
    },
    signalType(s) {
      return s === "看多" ? "danger" : s === "看空" ? "success" : "info";
    },
    levelType(l) {
      return { high: "danger", medium: "warning", low: "success" }[l] || "info";
    },
    fmtTs(ts) {
      if (!ts) return "-";
      return new Date(ts * 1000).toLocaleString("zh-CN", { hour12: false });
    },
    fmtIso(s) { return s || "-"; },
    fmtPctRaw(v) {
      if (v === null || v === undefined || v === "") return "-";
      const n = +v;
      return `${n > 0 ? "+" : ""}${n.toFixed(2)}%`;
    },
    finColor(v) {
      const n = parseFloat(v);
      if (isNaN(n)) return v;
      const cls = n > 0 ? "up" : n < 0 ? "down" : "flat";
      return `<span class="${cls}">${v}</span>`;
    },
    factorLabel(k) {
      return { trend: "趋势", momentum: "动量", volume: "量能", rsi: "RSI", macd: "MACD", financial: "财报" }[k] || k;
    },
    prosLabel(k) {
      return { trend: "趋势", momentum: "动量", volume: "量能",
               volatility: "波动稳定", fundamental: "基本面",
               fundamental_notes: "基本面" }[k] || k;
    },
    prosperityBarColor(k, v) {
      if (k === "volatility") {
        if ((Number(v) || 0) >= 65) return "#00e5a0";
        if ((Number(v) || 0) <= 35) return "#ff5c6e";
        return "#9fb0c9";
      }
      return this.factorColor(v);
    },
    factorColor(v) {
      const n = Number(v) || 0;
      if (n >= 65) return "#ff5c6e";
      if (n <= 35) return "#00e5a0";
      return "#9fb0c9";
    },
    aiTrendType(trend) {
      const t = (trend || "").toString();
      if (t.includes("看多") || t.includes("上行")) return "danger";
      if (t.includes("看空") || t.includes("下行")) return "success";
      return "info";
    },
    aiConf(v) { return Math.max(0, Math.min(100, Number(v) || 0)); },
    fmtPctText(v) {
      if (v === null || v === undefined || v === "") return "-";
      const n = +v;
      return (n > 0 ? "+" : "") + n.toFixed(1) + "%";
    },

    toggleDashFilter(type, key, label) {
      if (this.dashFilter && this.dashFilter.type === type && this.dashFilter.key === key) {
        this.dashFilter = null;
      } else {
        this.dashFilter = { type, key, label };
      }
    },
    isDashFilter(type, key) {
      return !!(this.dashFilter && this.dashFilter.type === type && this.dashFilter.key === key);
    },

    /* ---------- 量化实验室 ---------- */
    defaultSpec() {
      return {
        name: "",
        entry: { op: "all", rules: [
          { factor: "ma20_dev", op: "cross_above", value: 0 },
          { factor: "volume_ratio_5", op: "gte", value: 1.5 },
        ]},
        exit: { op: "any", rules: [
          { factor: "ma20_dev", op: "cross_below", value: 0 },
        ]},
        stop_loss_pct: 8,
        take_profit_pct: 20,
        max_hold_days: 30,
        initial_capital: 100000,
        kline_count: 260,
      };
    },
    resetSpec() {
      this.qspec = this.defaultSpec();
      this.qStrategyId = null;
    },
    async loadQuantMeta() {
      try {
        const d = await API.get("/api/quant/factors");
        this.factorDefs = d.factors || [];
        this.ruleOps = d.ops || [];
      } catch (e) { /* ignore */ }
    },
    async loadStrategies() {
      try {
        const d = await API.get("/api/quant/strategies");
        this.quantStrategies = d.items || [];
      } catch (e) { /* ignore */ }
    },
    async loadBtRuns() {
      try {
        const d = await API.get("/api/quant/backtest/runs");
        this.btRuns = d.items || [];
      } catch (e) { /* ignore */ }
    },
    factorLabel(k) {
      const f = this.factorDefs.find((x) => x.key === k);
      return f ? f.label : k;
    },
    factorDesc(k) {
      const f = this.factorDefs.find((x) => x.key === k);
      return f ? f.desc : "";
    },
    isBetween(op) { return op === "between"; },
    addRule(gkey) {
      this.qspec[gkey].rules.push({ factor: "ma20_dev", op: "gte", value: 0, value2: null });
    },
    strategySummary(spec) {
      const parts = (spec.entry?.rules || []).map(
        (r) => `${this.factorLabel(r.factor)} ${r.op === "between" ? "区间" : r.op} ${r.value ?? ""}`);
      return "买入: " + parts.join(" ∧ ");
    },
    async saveStrategy() {
      if (!this.qspec.name.trim()) { ElMessage.warning("请先填写策略名称"); return; }
      this.qSaving = true;
      try {
        await API.post("/api/quant/strategies" + (this.qStrategyId ? `?strategy_id=${this.qStrategyId}` : ""),
                       this.qspec);
        ElMessage.success("策略已保存");
        this.loadStrategies();
      } catch (e) { ElMessage.error(e.message); }
      this.qSaving = false;
    },
    loadSpec(s) {
      this.qspec = JSON.parse(JSON.stringify(s.spec));
      this.qspec.name = s.name;
      this.qStrategyId = s.id;
      this.quantTab = "strategy";
    },
    async removeStrategy(id) {
      try {
        await API.del(`/api/quant/strategies/${id}`);
        this.loadStrategies();
      } catch (e) { ElMessage.error(e.message); }
    },
    async removeRun(id) {
      try {
        await API.del(`/api/quant/backtest/runs/${id}`);
        this.loadBtRuns();
      } catch (e) { ElMessage.error(e.message); }
    },
    async runScreen() {
      this.qScreening = true;
      try {
        this.screenResult = await API.post("/api/quant/screen", this.qspec);
      } catch (e) { ElMessage.error(e.message); }
      this.qScreening = false;
    },
    async runBacktest() {
      this.qBacktesting = true;
      this.btResult = null;
      try {
        const q = this.qPortfolio
          ? `?portfolio=true&max_positions=${this.qMaxPositions || 5}&windows=${this.qWindows || 0}`
          : (this.qOos ? "?oos=true" : "");
        this.btResult = await API.post("/api/quant/backtest" + q, this.qspec);
        this.quantTab = "result";
        this.loadBtRuns();
        this.$nextTick(() => this.renderEquityChart());
      } catch (e) { ElMessage.error(e.message); }
      this.qBacktesting = false;
    },
    async viewRun(id) {
      try {
        this.btResult = await API.get(`/api/quant/backtest/runs/${id}`);
        this.quantTab = "result";
        this.$nextTick(() => this.renderEquityChart());
      } catch (e) { ElMessage.error(e.message); }
    },
    async runFactorIC() {
      this.icLoading = true;
      this.icResult = null;
      if (this._icTimer) { clearInterval(this._icTimer); this._icTimer = null; }
      let taskId;
      try {
        const r = await API.post("/api/quant/factor-ic", {
          months: 6, universe: this.icUniverse, limit: 300 });
        taskId = r.task_id;
      } catch (e) {
        this.icLoading = false;
        this.$message.error(String(e.message || e).slice(0, 200));
        return;
      }
      const poll = async () => {
        try {
          const t = await API.get("/api/nl/task/" + taskId);
          this.icStage = t.stage || "";
          if (t.status === "done") {
            clearInterval(this._icTimer); this._icTimer = null;
            this.icLoading = false;
            this.icResult = t.result;
            const g = t.result.summary || {};
            this.$message.success(`IC 完成: ${g.good || 0}/${g.total || 0} 个因子有效`);
          } else if (t.status === "error") {
            clearInterval(this._icTimer); this._icTimer = null;
            this.icLoading = false;
            this.$message.error("IC 失败: " + (t.error || "未知错误"));
          }
        } catch (e) {
          clearInterval(this._icTimer); this._icTimer = null;
          this.icLoading = false;
          this.$message.error(String(e.message || e).slice(0, 200));
        }
      };
      await poll();
      if (this.icLoading) this._icTimer = setInterval(poll, 2000);
    },
    async runArena() {
      const ids = this.arenaSelected.map((r) => r.id).slice(0, 4);
      if (ids.length < 2) { this.$message.warning("至少选 2 条回测"); return; }
      this.arenaLoading = true;
      try {
        const runs = await Promise.all(
          ids.map((id) => API.get(`/api/quant/backtest/runs/${id}`)));
        this.arenaResult = runs;
        this.$nextTick(() => { this.renderArenaRadar(); this.renderArenaEquity(); });
      } catch (e) {
        this.$message.error("加载回测失败: " + String(e.message || e).slice(0, 200));
      } finally { this.arenaLoading = false; }
    },
    renderArenaRadar() {
      const el = this.$refs.arenaRadar;
      if (!el || !this.arenaResult) return;
      if (this.charts.arenaRadar) this.charts.arenaRadar.dispose();
      const chart = EInit(el);
      this.charts.arenaRadar = chart;
      // 归一化到 0-100: 收益/超额按 ±50% 截断, 夏普按 ±3, 回撤反向
      const norm = (v, cap) => Math.max(0, Math.min(100, ((+v || 0) + cap) / (2 * cap) * 100));
      const normDD = (v) => Math.max(0, Math.min(100, 100 - (+v || 0) * 4));
      chart.setOption({
        tooltip: {},
        legend: { data: this.arenaResult.map((r) => r.strategy_name || ("回测#" + r.id)) },
        radar: { indicator: [
          { name: "总收益", max: 100 }, { name: "超额收益", max: 100 },
          { name: "夏普", max: 100 }, { name: "低回撤", max: 100 },
          { name: "胜率", max: 100 },
        ] },
        series: [{ type: "radar", data: this.arenaResult.map((r) => {
          const s = r.stats || {};
          return { name: r.strategy_name || ("回测#" + r.id), value: [
            norm(s.total_return_pct, 50), norm(s.excess_return_pct, 50),
            norm(s.sharpe, 3), normDD(s.max_drawdown_pct), +(s.win_rate_pct || 0),
          ] };
        }) }],
      });
    },
    renderArenaEquity() {
      const el = this.$refs.arenaEquity;
      if (!el || !this.arenaResult) return;
      if (this.charts.arenaEquity) this.charts.arenaEquity.dispose();
      const chart = EInit(el);
      this.charts.arenaEquity = chart;
      // 按日期对齐归一化(起点=100)
      const allDates = [...new Set(this.arenaResult.flatMap(
        (r) => (r.equity_curve || []).map((p) => p.date)))].sort();
      chart.setOption({
        tooltip: { trigger: "axis" },
        legend: { data: this.arenaResult.map((r) => r.strategy_name || ("回测#" + r.id)) },
        xAxis: { type: "category", data: allDates },
        yAxis: { type: "value", scale: true },
        series: this.arenaResult.map((r) => {
          const m = {};
          (r.equity_curve || []).forEach((p) => { m[p.date] = p.equity; });
          const base = (r.equity_curve || [])[0]?.equity || 1;
          return { name: r.strategy_name || ("回测#" + r.id), type: "line", showSymbol: false,
            data: allDates.map((d) => m[d] != null ? +(m[d] / base * 100).toFixed(2) : null),
            connectNulls: true };
        }),
      });
    },

    /* ---------- 自我进化 ---------- */
    async startEvolve() {
      try {
        await API.post("/api/quant/evolve/start", this.evolveCfg);
        ElMessage.success("进化已启动");
        if (this.evolveTimer) clearInterval(this.evolveTimer);
        this.evolveTimer = setInterval(() => this.pollEvolve(), 2500);
        this.pollEvolve();
      } catch (e) { ElMessage.error(e.message); }
    },
    async stopEvolve() {
      try {
        await API.post("/api/quant/evolve/stop");
        ElMessage.info("已请求停止, 当前代完成后退出");
      } catch (e) { ElMessage.error(e.message); }
    },
    async pollEvolve() {
      try {
        const s = await API.get("/api/quant/evolve/status");
        this.evolveStatus = Object.assign({}, this.evolveStatus, s);
        if (!s.running) {
          if (this.evolveTimer) { clearInterval(this.evolveTimer); this.evolveTimer = null; }
          this.loadEvolveRuns();
        }
      } catch (e) { /* ignore */ }
    },
    async loadEvolveRuns() {
      try {
        const d = await API.get("/api/quant/evolve/runs");
        this.evolveRuns = d.items || [];
      } catch (e) { /* ignore */ }
    },
    async adoptStrategy(fp) {
      try {
        await API.post(`/api/quant/evolve/adopt/${fp}`);
        ElMessage.success("已采用为正式策略, 可在「我的策略」中查看");
        this.loadStrategies();
      } catch (e) { ElMessage.error(e.message); }
    },
    rulesText(group) {
      const parts = (group?.rules || []).map((r) => {
        const v = r.op === "between" ? `${r.value}~${r.value2}` : (r.value ?? "");
        return `${this.factorLabel(r.factor)} ${this.opLabel(r.op)} ${v}`;
      });
      return parts.join(group?.op === "any" ? " 或 " : " 且 ");
    },
    opLabel(op) {
      // 后端算子 → 用户语言(全站规则展示统一走这里, 禁止裸奔英文算子)
      return { lt: "<", lte: "≤", gt: ">", gte: "≥", eq: "=",
               between: "介于", cross_above: "上穿", cross_below: "下穿" }[op] || op;
    },
    btColor(v) {
      if (v == null) return "inherit";
      return v > 0 ? "var(--up)" : v < 0 ? "var(--down)" : "inherit";
    },
    fitScore(f) {
      // 综合评分 0~100: fitness 原始分(约 -3~5)线性映射, 越高越好
      if (f == null) return "-";
      return Math.max(0, Math.min(100, Math.round(((f + 3) / 8) * 100)));
    },
    oosHint(k, a, b) {
      if (a == null || b == null) return "-";
      if (k === "交易笔") return b >= 5 ? "样本充足" : "样本过少, 结论仅供参考";
      if (k === "最大回撤%") return b <= a * 1.5 ? "回撤可控" : "样本外回撤放大, 注意风险";
      const ratio = a !== 0 ? b / a : (b > 0 ? 1 : -1);
      if (ratio >= 0.7) return "衰减小, 稳健";
      if (ratio >= 0.3) return "有所衰减, 谨慎使用";
      if (ratio >= 0) return "大幅衰减, 疑似过拟合";
      return "由正转负, 不可用";
    },
    fmtMoney(v) {
      if (v == null || v === "" || v === "-") return "-";
      const n = +v;
      if (!isFinite(n)) return "-";
      const a = Math.abs(n);
      if (a >= 1e8) return (n / 1e8).toFixed(2) + "亿";
      if (a >= 1e4) return (n / 1e4).toFixed(1) + "万";
      return n.toFixed(0);
    },
    fmtFactor(v) {
      if (v == null) return "-";
      const n = +v;
      return Math.abs(n) >= 100 ? n.toFixed(0) : n.toFixed(2);
    },
    isEventFactor(factor) {
      return ["ma_bull", "macd_cross", "kdj_cross", "macd_hist_rising"].includes(factor);
    },
    screenCellHit(row, factor) {
      return (row.rule_detail || []).some((d) => d.factor === factor && d.ok);
    },
    screenRowClass({ row }) {
      return row.hit ? "screen-hit" : "";
    },
    exportBattleCard() {
      // 战绩图: canvas 1080x1350, 标题 + 曲线 + KPI + 水印(买家自发传播)
      const r = this.btResult;
      if (!r || !r.equity_curve || !r.equity_curve.length) {
        ElMessage.warning("没有可导出的回测结果"); return;
      }
      const W = 1080, H = 1350;
      const cv = document.createElement("canvas");
      cv.width = W; cv.height = H;
      const g = cv.getContext("2d");
      const st = r.stats || {};
      const up = (st.total_return_pct || 0) >= 0;
      // 背景
      const bg = g.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, "#141821"); bg.addColorStop(1, "#0b0e11");
      g.fillStyle = bg; g.fillRect(0, 0, W, H);
      g.fillStyle = "#f0b90b"; g.fillRect(0, 0, W, 10);
      // 标题
      g.fillStyle = "#eaecef"; g.font = "bold 52px sans-serif";
      g.fillText("AlphaDesk 策略回测", 60, 100);
      g.fillStyle = "#9aa0ab"; g.font = "30px sans-serif";
      g.fillText((r.name || "我的策略") + "  ·  " + (st.period || ""), 60, 150);
      const ret = (up ? "+" : "") + (st.total_return_pct ?? "-") + "%";
      g.fillStyle = up ? "#f6465d" : "#0ecb81";
      g.font = "bold 120px sans-serif";
      g.fillText(ret, 60, 270);
      g.fillStyle = "#9aa0ab"; g.font = "28px sans-serif";
      g.fillText("区间总收益", 60, 310);
      // KPI 四格
      const kpis = [
        ["年化", (st.cagr_pct ?? "-") + "%"],
        ["最大回撤", (st.max_drawdown_pct ?? "-") + "%"],
        ["胜率", (st.win_rate_pct ?? "-") + "%(" + (st.trades_count ?? 0) + "笔)"],
        ["夏普", String(st.sharpe ?? "-")],
      ];
      kpis.forEach((k, i) => {
        const x = 60 + (i % 2) * 500, y = 360 + Math.floor(i / 2) * 110;
        g.fillStyle = "#9aa0ab"; g.font = "26px sans-serif";
        g.fillText(k[0], x, y);
        g.fillStyle = "#eaecef"; g.font = "bold 44px sans-serif";
        g.fillText(String(k[1]), x, y + 52);
      });
      // 曲线
      const pts = r.equity_curve;
      const cx = 60, cy = 640, cw = W - 120, ch = 380;
      const vals = pts.map((p) => +p.equity);
      const mn = Math.min(...vals), mx = Math.max(...vals);
      const X = (i) => cx + (i / Math.max(pts.length - 1, 1)) * cw;
      const Y = (v) => cy + ch - ((v - mn) / Math.max(mx - mn, 1e-9)) * ch;
      g.strokeStyle = "#232a35"; g.lineWidth = 1;
      for (let i = 1; i <= 4; i++) {
        g.beginPath(); g.moveTo(cx, cy + (ch / 4) * i); g.lineTo(cx + cw, cy + (ch / 4) * i); g.stroke();
      }
      g.strokeStyle = up ? "#f6465d" : "#0ecb81"; g.lineWidth = 5;
      g.beginPath();
      pts.forEach((p, i) => (i ? g.lineTo(X(i), Y(+p.equity)) : g.moveTo(X(i), Y(+p.equity))));
      g.stroke();
      g.fillStyle = "#9aa0ab"; g.font = "24px sans-serif";
      g.fillText(pts[0].date || "", cx, cy + ch + 36);
      g.fillText(pts[pts.length - 1].date || "", cx + cw - 180, cy + ch + 36);
      // 样本外徽章
      if (r.oos && r.oos.verdict) {
        const ok = /稳健|可用/.test(r.oos.verdict);
        g.fillStyle = ok ? "#0ecb81" : "#f6465d";
        const label = "样本外: " + r.oos.verdict;
        g.font = "bold 30px sans-serif";
        const w = g.measureText(label).width + 50;
        g.beginPath(); g.roundRect(W - 60 - w, 1080, w, 60, 12); g.fill();
        g.fillStyle = "#0b0e11"; g.fillText(label, W - 60 - w + 25, 1122);
      }
      // 风险提示 + 水印
      g.fillStyle = "#5f6b7a"; g.font = "24px sans-serif";
      g.fillText("历史回测不代表未来收益, 仅供学习研究, 不构成投资建议", 60, 1180);
      g.fillStyle = "#f0b90b"; g.font = "bold 30px sans-serif";
      g.fillText("AlphaDesk 量化研究终端", 60, 1260);
      g.fillStyle = "#5f6b7a"; g.font = "24px sans-serif";
      g.fillText("dennicliu.github.io/alphadesk-docs", 60, 1300);
      // 下载
      const a = document.createElement("a");
      a.download = "AlphaDesk战绩_" + (r.name || "策略") + ".png";
      a.href = cv.toDataURL("image/png");
      a.click();
      ElMessage.success("战绩图已下载，发朋友圈记得配文字哦");
    },
    renderEquityChart() {
      const el = this.$refs.equityChart;
      if (!el || !this.btResult || !this.btResult.equity_curve) return;
      if (this.charts.equity) this.charts.equity.dispose();
      const chart = EInit(el);
      this.charts.equity = chart;
      const c = this.btResult.equity_curve;
      chart.setOption({
        grid: { left: 70, right: 30, top: 40, bottom: 40 },
        tooltip: { trigger: "axis",
          valueFormatter: (v) => (+v).toLocaleString() + " 元" },
        xAxis: { type: "category", data: c.map((p) => p.date) },
        yAxis: { type: "value", scale: true,
          axisLabel: { formatter: (v) => (v / 1000).toFixed(0) + "k" } },
        series: [{
          name: "组合权益", type: "line", data: c.map((p) => p.equity),
          showSymbol: false, lineStyle: { width: 2, color: "#4d6bfe" },
          areaStyle: { color: {
            type: "linear", x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [{ offset: 0, color: "rgba(77,107,254,.25)" },
                         { offset: 1, color: "rgba(77,107,254,0)" }] } },
          markLine: { silent: true, symbol: "none",
            lineStyle: { type: "dashed", color: "#c2c7d2" },
            data: [{ yAxis: this.btResult.stats.initial_capital }] },
        }],
      });
    },

    /* ---------- 设备授权 ---------- */
    async loadLicense() {
      try { this.license = await API.get("/api/license/status"); }
      catch (e) { /* ignore */ }
    },
    licenseBanner() {
      const l = this.license || {};
      if (l.mode === "licensed") {
        if (l.days_left != null && l.days_left <= 7)
          return { expired: false, text: `授权剩 ${l.days_left} 天到期, 到期后功能锁定, 请联系卖家续期。` };
        return null;
      }
      if (l.mode === "trial")
        return { expired: false,
                 text: `试用中, 剩 ${l.days_left} 天。正式使用请联系卖家获取激活码(一机一码)。` };
      return { expired: true, text: "授权已过期, 全部数据接口已锁定, 请输入激活码解锁。" };
    },
    genTransferReq() {
      // 换机申请串: TR + base64(新机器码|旧激活码), 卖家工具一键签发
      try {
        const m = this.license.machine || "";
        const old = (this.licenseToken || "").trim();
        if (!m) { ElMessage.warning("机器码还没加载出来"); return; }
        const raw = m + "|" + old;
        this.transferReq = "TR-" + btoa(unescape(encodeURIComponent(raw)));
        ElMessage.success("申请串已生成，发给卖家即可");
      } catch (e) { ElMessage.error("生成失败"); }
    },
    copyTransferReq() {
      try {
        navigator.clipboard.writeText(this.transferReq || "");
        ElMessage.success("申请串已复制，发给卖家");
      } catch (e) { ElMessage.warning("复制失败, 请手动选择复制"); }
    },
    copyMachine() {
      try {
        navigator.clipboard.writeText(this.license.machine || "");
        ElMessage.success("机器码已复制");
      } catch (e) { ElMessage.warning("复制失败, 请手动选择复制"); }
    },
    async activateLicense() {
      if (!this.licenseToken.trim()) { ElMessage.warning("请粘贴激活码"); return; }
      this.licenseLoading = true;
      try {
        this.license = await API.post("/api/license/activate",
                                      { token: this.licenseToken.trim() });
        ElMessage.success("激活成功");
        this.licenseDlg = false;
        this.licenseToken = "";
        await this.refreshAll();
      } catch (e) { ElMessage.error(String(e.message || e).slice(0, 200)); }
      this.licenseLoading = false;
    },

    /* ---------- 数据加载 ---------- */
    async loadHealth() {
      try { this.health = await API.get("/api/health"); } catch (e) { /* ignore */ }
    },
    async runHealthCheck() {
      this.healthLoading = true;
      try {
        this.dataHealth = await API.post("/api/health/data");
        if (!this.dataHealth.ok) this.$message.warning("数据健康检查发现异常, 详情见下方");
        else this.$message.success("数据健康: 全部正常");
      } catch (e) {
        this.$message.error("健康检查失败: " + String(e.message || e).slice(0, 200));
      } finally { this.healthLoading = false; }
    },
    async loadWatchlist(retried = false) {
      try {
        const d = await API.get("/api/watchlist");
        this.watchlist = d.items || [];
        this.poolMax = d.max || 20;
        this.watchGroups = d.groups || [];
      } catch (e) {
        if (!retried && String(e.message).includes("fetch")) {
          setTimeout(() => this.loadWatchlist(true), 1500);
          return;
        }
        ElMessage.error("自选池加载失败: " + e.message);
      }
    },
    async loadAnalyses() {
      try {
        const d = await API.get("/api/analyses");
        this.analyses = d.items || [];
      } catch (e) { /* ignore */ }
    },
    async loadAlerts() {
      try {
        const d = await API.get("/api/alerts?limit=100");
        this.alerts = d.items || [];
      } catch (e) { /* ignore */ }
    },
    async loadLogs() {
      try {
        const d = await API.get("/api/logs?limit=200");
        this.logs = d.items || [];
      } catch (e) { /* ignore */ }
    },
    async loadNews() {
      try {
        const d = await API.get("/api/news?limit=120");
        this.newsItems = d.items || [];
      } catch (e) { /* ignore */ }
    },
    async loadEvents() {
      this.eventsLoading = true;
      try {
        const d = await API.get("/api/events/calendar?days=14");
        this.eventsGroups = d.groups || [];
        this.eventsTotal = d.total || 0;
        this.eventsDays = d.days || 14;
      } catch (e) {
        this.$message.error("事件日历加载失败: " + String(e.message || e).slice(0, 150));
      } finally { this.eventsLoading = false; }
    },
    async scanEvents() {
      this.eventsScanning = true;
      try {
        const d = await API.post("/api/events/scan?days=3");
        this.$message.success(`扫描完成: ${d.scanned || 0}只中发现${d.events || 0}起事件`);
        this.loadEvents();
        this.loadAlerts();
      } catch (e) {
        this.$message.error("扫描失败: " + String(e.message || e).slice(0, 150));
      } finally { this.eventsScanning = false; }
    },
    async loadSettings() {
      try {
        const d = await API.get("/api/settings");
        this.cfg = d;
        this.mailToText = (d.mail_to || []).join("\n");
        this.settingsLoaded = true;
      } catch (e) { ElMessage.error("设置加载失败: " + e.message); }
    },
    async refreshAll() {
      await Promise.all([this.loadHealth(), this.loadWatchlist(), this.loadAnalyses(),
        this.loadAlerts(), this.loadNews(), this.pollStatus(), this.loadMissed()]);
      if (!this.guideSeen && !(this.watchlist || []).length) this.guideVisible = true;
      if (this.page === "settings" && !this.settingsLoaded) await this.loadSettings();
      if (this.page === "logs") await this.loadLogs();
    },

    async importSamples() {
      try {
        const d = await API.post("/api/watchlist/samples");
        ElMessage.success(`已导入 ${d.added} 只示例`);
        this.guideVisible = false;
        await this.loadWatchlist();
      } catch (e) { ElMessage.error(e.message); }
    },
    async loadHoldings() {
      try {
        const d = await API.get("/api/holdings");
        this.holdings = d.items || [];
        this.holdSummary = { total_cost: d.total_cost, total_mv: d.total_mv, total_pnl: d.total_pnl };
      } catch (e) { ElMessage.error(e.message); }
    },
    async saveHolding() {
      try {
        await API.post("/api/holdings", { ...this.holdForm, qty: +this.holdForm.qty || 100 });
        this.holdDlg = false;
        this.holdForm = { code: "", buy_price: null, qty: 100, buy_date: "", note: "" };
        await this.loadHoldings();
      } catch (e) { ElMessage.error(e.message); }
    },
    async delHolding(id) {
      try {
        await ElMessageBox.confirm("删除这笔持仓？", "确认", { type: "warning" });
        await API.delete("/api/holdings/" + id);
        await this.loadHoldings();
      } catch (e) { if (e !== "cancel") ElMessage.error(e.message || e); }
    },
    async loadMissed() {
      try {
        this.missedInfo = await API.get("/api/pipeline/missed");
      } catch (e) { this.missedInfo = null; }
    },
    async runCatchup() {
      try {
        this.catchupLoading = true;
        const d = await API.post("/api/pipeline/catchup");
        ElMessage.success(d.message || "补跑已启动");
        setTimeout(() => this.loadMissed(), 30000);
      } catch (e) { ElMessage.error(e.message); }
      finally { this.catchupLoading = false; }
    },
    dismissGuide() {
      this.guideVisible = false;
      try { localStorage.setItem("ad_guide_seen", "1"); } catch (e) {}
      this.guideSeen = true;
    },
    async guideGoSamples() {
      await this.importSamples();
      this.dismissGuide();
      this.switchPage("screener");
    },
    copyCodes(items) {
      // 导出代码清单(一行一个, 去券商 App 粘贴下单)
      const list = (items || []).map((r) => r.code || r).filter(Boolean);
      if (!list.length) { ElMessage.warning("没有可导出的股票"); return; }
      const txt = list.join("\n");
      (navigator.clipboard ? navigator.clipboard.writeText(txt)
        : Promise.reject(new Error("no-clipboard")))
        .then(() => ElMessage.success(`已复制 ${list.length} 只代码，去券商 App 粘贴`))
        .catch(() => {
          try {
            const ta = document.createElement("textarea");
            ta.value = txt; document.body.appendChild(ta); ta.select();
            document.execCommand("copy"); ta.remove();
            ElMessage.success(`已复制 ${list.length} 只代码，去券商 App 粘贴`);
          } catch (e) { ElMessage.error("复制失败，请手动记录"); }
        });
    },
    switchPage(key) {
      this.page = key;
      if (key === "hold") this.loadHoldings();
      if (key === "settings" && !this.settingsLoaded) this.loadSettings();
      if (key === "logs") this.loadLogs();
      if (key === "news") this.loadNews();
      if (key === "alerts") this.loadAlerts();
      if (key === "sectors" && !this.sectorHeat.items.length) this.loadSectors();
      if (key === "quant") {
        this.loadQuantMeta();
        this.loadStrategies();
        this.loadBtRuns();
        this.loadEvolveRuns();
        this.pollEvolve();
        if (!this.qspec) this.resetSpec();
      }
      if (key === "analyses") this.loadAnalyses();
    },

    /* ---------- 智能选股器 ---------- */
    async loadRegime() {
      try { this.regime = await API.get("/api/market/regime"); }
      catch (e) { this.$message.error("环境判断失败: " + e.message); }
    },
    async loadSchemes() {
      try {
        const items = (await API.get("/api/nl/schemes")).items || [];
        this.nlSchemes = items.map((s) => ({ ...s, _sched: s.schedule === "daily_close" }));
      } catch (e) { /* 静默 */ }
    },
    async loadNlTasks() {
      try {
        this.nlTasks = (await API.get("/api/nl/tasks")).items || [];
      } catch (e) { /* 静默 */ }
    },
    fmtTaskTs(ts) {
      if (!ts) return "";
      const d = new Date(ts * 1000);
      const p = (n) => String(n).padStart(2, "0");
      return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
    },
    nlHitCount(row) {
      return (row.rule_detail || []).filter((x) => x.ok).length;
    },
    nlVerdict(code) {
      const r = this.nlReviews.find((x) => x.code === code);
      if (!r) return "-";
      const color = { "看多": "#00e5a0", "回避": "#ff5c6e" }[r.verdict] || "#5f7191";
      return `<span style="color:${color};font-weight:600">${r.verdict}</span>`;
    },
    async runNlScreen() {
      if (!this.nlQuery.trim()) { this.$message.warning("请先输入选股描述"); return; }
      this.nlLoading = true;
      this.nlProgress = 2;
      this.nlStage = "提交任务…";
      this.nlParsed = null;
      this.nlResult = null;
      this.nlReviews = [];
      this.nlBtResult = null;
      if (this._nlTimer) { clearInterval(this._nlTimer); this._nlTimer = null; }
      let taskId;
      try {
        const r = await API.post("/api/nl/screen", {
          text: this.nlQuery.trim(), use_llm: this.nlUseLlm,
          universe: this.nlUniverse, limit: 8000,
          asof: this.nlAsof || "",
        });
        taskId = r.task_id;
      } catch (e) {
        this.nlLoading = false;
        this.$message.error(String(e.message || e).slice(0, 200));
        return;
      }
      const poll = async () => {
        try {
          const t = await API.get("/api/nl/task/" + taskId);
          if (t.explained && t.explained.length) {
            this.nlParsed = { explained: t.explained, via: t.via || "local", spec: t.spec };
          }
          this.nlStage = (t.universe_label || "") + " " + (t.stage || "");
          if (t.scanned_total > 0) {
            this.nlProgress = Math.min(99, Math.round(t.scanned_done / t.scanned_total * 100));
          } else {
            this.nlProgress = Math.min(90, this.nlProgress + 3);
          }
          if (t.status === "done") {
            clearInterval(this._nlTimer); this._nlTimer = null;
            this.nlLoading = false;
            this.nlProgress = 100;
            this.nlResult = t;
            this.nlParsed = { explained: t.explained || [], via: t.via || "local", spec: t.spec };
            this.$message.success(
              t.cached ? `缓存命中: ${t.hits ?? 0} 只(当日已算过)` : `扫描 ${t.scanned ?? 0} 只, 命中 ${t.hits ?? 0} 只`);
            this.loadNlTasks();
            // 胜率前置: 结果出来自动跑一次自选池胜率(轻量, 给结论定心丸)
            if ((t.hits || 0) > 0 && !t.asof) {
              this.nlWrUniverse = "watchlist";
              this.runNlWinrate();
            }
          } else if (t.status === "error") {
            clearInterval(this._nlTimer); this._nlTimer = null;
            this.nlLoading = false;
            this.$message.error("筛选失败: " + (t.error || "未知错误"));
            this.loadNlTasks();
          }
        } catch (e) {
          clearInterval(this._nlTimer); this._nlTimer = null;
          this.nlLoading = false;
          this.$message.error(String(e.message || e).slice(0, 200));
        }
      };
      await poll();
      if (this.nlLoading) this._nlTimer = setInterval(poll, 2000);
    },
    async loadTaskByIndex(i) {
      try {
        const t = await API.get("/api/nl/task-by-index/" + i);
        this.nlResult = t;
        this.nlParsed = { explained: t.explained || [], via: t.via || "local", spec: t.spec };
        this.nlProgress = 100;
        this.nlReviews = [];
        this.nlBtResult = null;
        window.scrollTo({ top: 0, behavior: "smooth" });
      } catch (e) { this.$message.error("加载失败: " + e.message); }
    },
    async saveNlScheme() {
      try {
        const { value } = await ElMessageBox.prompt("方案名称(便于识别, 如: 止跌放量)", "保存选股方案",
          { inputValue: this.nlQuery.slice(0, 12), inputPattern: /\S+/, inputErrorMessage: "名称不能为空" });
        await API.post("/api/nl/schemes", {
          name: value.trim(), text: this.nlQuery.trim(),
          spec: (this.nlParsed && this.nlParsed.spec) || {},
          universe: this.nlUniverse,
        });
        this.$message.success("已保存, 可在下方开启收盘定时");
        this.loadSchemes();
      } catch (e) {
        if (e !== "cancel") this.$message.error(String(e.message || e).slice(0, 200));
      }
    },
    async setSchemeSchedule(sc, mode) {
      try {
        await API.post(`/api/nl/schemes/${sc.id}/schedule`, { schedule: mode });
        this.$message.success(mode === "off" ? "已关闭定时" : "已开启: 每个交易日收盘后自动跑");
      } catch (e) {
        sc._sched = !sc._sched;
        this.$message.error(String(e.message || e).slice(0, 200));
      }
    },
    async delScheme(sc) {
      try {
        await API.del(`/api/nl/schemes/${sc.id}`);
        this.$message.success("已删除");
        this.loadSchemes();
      } catch (e) { this.$message.error(String(e.message || e).slice(0, 200)); }
    },
    rerunScheme(sc) {
      this.nlQuery = sc.text;
      this.nlUniverse = sc.universe || "all";
      this.switchPage("nl");
      this.runNlScreen();
    },
    async runNlBacktest() {
      if (!this.nlResult || !this.nlResult.items.length) return;
      this.nlBtLoading = true;
      try {
        this.nlBtResult = await API.post("/api/nl/backtest", {
          codes: this.nlResult.items.slice(0, 40).map((x) => x.code),
          spec: (this.nlParsed && this.nlParsed.spec) || {},
          months: 6, stop_loss_pct: 8, take_profit_pct: 20, max_hold_days: 20,
        });
        this.$message.success(`回测完成, 覆盖 ${this.nlBtResult.agg.stocks || 0} 只`);
      } catch (e) {
        this.$message.error("回测失败: " + String(e.message || e).slice(0, 200));
      } finally { this.nlBtLoading = false; }
    },
    async runNlWinrate() {
      const spec = (this.nlParsed && this.nlParsed.spec) || {};
      if (!spec.rules || !spec.rules.length) {
        this.$message.warning("请先跑一次筛选, 解析出条件后再测胜率");
        return;
      }
      this.nlWrLoading = true;
      this.nlWrResult = null;
      if (this._nlTimer) { clearInterval(this._nlTimer); this._nlTimer = null; }
      let taskId;
      try {
        const r = await API.post("/api/nl/winrate", {
          spec, months: 6, universe: this.nlWrUniverse,
          limit: this.nlWrUniverse === "ashare" ? 500 : 0,
        });
        taskId = r.task_id;
      } catch (e) {
        this.nlWrLoading = false;
        this.$message.error(String(e.message || e).slice(0, 200));
        return;
      }
      const poll = async () => {
        try {
          const t = await API.get("/api/nl/task/" + taskId);
          if (t.status === "done") {
            clearInterval(this._nlTimer); this._nlTimer = null;
            this.nlWrLoading = false;
            this.nlWrResult = t.result;
            const o = t.result.overall || {};
            this.$message.success(
              `回放完成: ${o.signals || 0} 次信号, 胜率 ${o.win_rate_pct || 0}%`);
          } else if (t.status === "error") {
            clearInterval(this._nlTimer); this._nlTimer = null;
            this.nlWrLoading = false;
            this.$message.error("胜率统计失败: " + (t.error || "未知错误"));
          } else {
            this.nlStage = t.stage || "";
          }
        } catch (e) {
          clearInterval(this._nlTimer); this._nlTimer = null;
          this.nlWrLoading = false;
          this.$message.error(String(e.message || e).slice(0, 200));
        }
      };
      await poll();
      if (this.nlWrLoading) this._nlTimer = setInterval(poll, 2000);
    },
    async runNlReview() {
      if (!this.nlResult || !this.nlResult.items.length) return;
      this.nlReviewLoading = true;
      try {
        const r = await API.post("/api/nl/review", {
          items: this.nlResult.items.slice(0, 40), text: this.nlQuery,
        });
        this.nlReviews = r.reviews || [];
        this.$message.success(`AI 已复核 ${this.nlReviews.length} 只`);
      } catch (e) {
        this.$message.error("AI 复核失败: " + String(e.message || e).slice(0, 200));
      } finally { this.nlReviewLoading = false; }
    },
    nlFactorLine(row) {
      const CN = { down_days: "连跌", up_days: "连涨", stop_fall: "止跌", vol_spike: "放量",
        lower_shadow_pct: "下影%", upper_shadow_pct: "上影%", hammer: "锤子",
        rsi6: "RSI6", ret5: "5日涨跌%", macd_cross: "MACD交叉",
        gap_pct: "跳空%", limit_up_days: "连板", new_low_rebound: "新低反弹",
        ma_tangle: "粘合%", close: "收盘" };
      const f = row.factors || {};
      const pick = ["down_days", "stop_fall", "vol_spike", "lower_shadow_pct", "hammer",
        "limit_up_days", "gap_pct", "new_low_rebound", "ma_tangle", "rsi6", "ret5",
        "macd_cross", "close"];
      const parts = [];
      for (const k of pick) {
        if (f[k] !== null && f[k] !== undefined) {
          const v = typeof f[k] === "number" ? Math.round(f[k] * 100) / 100 : f[k];
          parts.push(`${CN[k] || k}=${v}`);
        }
      }
      const d = (row.rule_detail || []).filter((x) => x.ok).map((x) => CN[x.factor] || x.factor).join("、");
      return (d ? "✓ " + d + "  |  " : "") + parts.slice(0, 6).join("  ");
    },
    async addOneToPool(row) {
      try {
        await API.post("/api/watchlist", {
          code: row.code, name: row.name || "", market: "auto",
          group_name: this.nlPoolGroup || "默认",
        });
        this.$message.success(`${row.code} 已加入自选池${this.nlPoolGroup && this.nlPoolGroup !== "默认" ? "·" + this.nlPoolGroup : ""}`);
        this.loadWatchlist();
      } catch (e) {
        this.$message.error(String(e.message || e).slice(0, 200));
      }
    },
    async addNlHitsToPool() {
      const group = this.nlPoolGroup || "默认";
      let ok = 0, fail = 0;
      for (const r of (this.nlResult?.items || [])) {
        try {
          await API.post("/api/watchlist", {
            code: r.code, name: r.name || "", market: "auto", group_name: group,
          });
          ok++;
        } catch (e) { fail++; }
      }
      this.$message.success(`加入 ${ok} 只到「${group}」${fail ? `, 失败 ${fail} 只(可能超池上限)` : ""}`);
      this.loadWatchlist();
    },
    async movePoolGroup(row, group) {
      try {
        await API.post("/api/watchlist/groups/move", { codes: [row.code], group });
        this.$message.success(`${row.code} → ${group}`);
        this.loadWatchlist();
      } catch (e) { this.$message.error(String(e.message || e).slice(0, 200)); }
    },
    async delPoolGroup(name) {
      try {
        await API.del("/api/watchlist/groups/" + encodeURIComponent(name));
        this.$message.success("分组已删除, 股票回到默认分组");
        this.loadWatchlist();
      } catch (e) { this.$message.error(String(e.message || e).slice(0, 200)); }
    },
    async newPoolGroup() {
      try {
        const { value } = await ElMessageBox.prompt("新分组名称", "新建分组",
          { inputPattern: /\S+/, inputErrorMessage: "名称不能为空" });
        const name = value.trim();
        this.watchGroups = [...this.watchGroups, { name, count: 0, sort: 99 }];
        this.stockDlg.group_name = name;
        this.$message.success(`分组「${name}」已创建, 添加股票时可直接选用`);
      } catch (e) { /* cancel */ }
    },

    /* ---------- 流水线 ---------- */
    async pollStatus() {
      try {
        const prev = this.status.running;
        this.status = await API.get("/api/pipeline/status");
        if (prev && !this.status.running && this.runningPipeline) {
          this.runningPipeline = false;
          const s = this.status.last_summary || {};
          ElMessage.success(
            `流水线完成: 成功 ${s.analyzed ?? 0} / 失败 ${s.failed ?? 0}, 重点信号 ${s.alerts ?? 0}, AI ${s.ai_ok ?? 0}`);
          this.loadAnalyses();
          this.loadAlerts();
          this.loadWatchlist();
        }
      } catch (e) { /* ignore */ }
    },
    /* ---------- 登录/注册/订阅 ---------- */






    showAgreement(which) {
      this.agreement.visible = true;
      this.agreement.title = which === "terms" ? "用户协议" : "隐私政策";
      this.agreement.body = which === "terms" ? TERMS_HTML : PRIVACY_HTML;
    },


    fmtTsDay(ts) {
      if (!ts) return "长期";
      const d = new Date(ts * 1000);
      return `${d.getMonth() + 1}/${d.getDate()}`;
    },
    async runPipeline() {
      if (this.status.running) return;
      try {
        await API.post("/api/pipeline/run");
        this.runningPipeline = true;
        ElMessage.info("流水线已启动, 请稍候…");
        this.pollStatus();
      } catch (e) { ElMessage.error(e.message); }
    },
    async sendDigest() {
      try {
        await this.$confirm("将立即向配置的收件邮箱发送一次自选池摘要, 是否继续?", "发送摘要邮件", { type: "info" });
      } catch (e) { return; }
      try {
        await API.post("/api/pipeline/send-email");
        ElMessage.success("摘要邮件已发送");
      } catch (e) { ElMessage.error(e.message); }
    },

    /* ---------- 自选池 CRUD ---------- */
    openAdd() {
      this.stockDlg = { visible: true, mode: "add", code: "", name: "", note: "", market: "auto",
                        group_name: this.poolFilterGroup !== "全部" ? this.poolFilterGroup : "默认",
                        quote: null, quoteLoading: false, selected: "", options: [], searching: false };
    },
    openEdit(row) {
      this.stockDlg = {
        visible: true, mode: "edit", code: row.code, name: row.name || "",
        note: row.note || "", market: row.market || "auto",
        group_name: row.group_name || "默认",
        quote: null, quoteLoading: false,
        selected: "", options: [], searching: false,
      };
    },
    async loadSectors() {
      this.sectorLoading = true;
      try {
        const d = await API.get(`/api/sectors/heatmap?kind=${this.sectorKind}`);
        this.sectorHeat = { items: d.items || [], date: d.date || "",
                            mode: d.mode || "history", note: d.note || "" };
        this.$nextTick(() => this.renderSectorTreemap());
        if (!d.items || !d.items.length) this.$message.warning("板块数据为空, 稍后重试");
        else if (d.mode === "intraday") this.$message.warning("已切换当日动量模式");
      } catch (e) {
        this.$message.error("板块加载失败: " + String(e.message || e).slice(0, 200));
      } finally { this.sectorLoading = false; }
    },
    renderSectorTreemap() {
      const el = this.$refs.sectorChart;
      if (!el) return;
      if (this.charts.sector) this.charts.sector.dispose();
      // 下钻视图: 展开某板块的成分股
      if (this.sectorZoom && this.sectorZoom.members && this.sectorZoom.members.length) {
        this.renderSectorStocks();
        return;
      }
      const intraday = this.sectorHeat.mode === "intraday";
      const key = intraday ? "r1" : "r20";
      let items = (this.sectorHeat.items || []).filter((x) => x[key] != null);
      const q = (this.sectorQuery || "").trim();
      if (q) items = items.filter((x) => (x.name || "").includes(q));
      if (this.sectorSort === "asc") items = items.slice().sort((a, b) => a[key] - b[key]);
      else if (this.sectorSort === "up") items = items.slice().sort((a, b) => (b.up_ratio || 0) - (a.up_ratio || 0));
      else items = items.slice().sort((a, b) => b[key] - a[key]);
      items = items.slice(0, 80);
      const sel = this.sectorBoard && this.sectorBoard.code;
      const chart = EInit(el);
      this.charts.sector = chart;
      chart.setOption({
        tooltip: { formatter: (p) => {
          const d = p.data.ext || {};
          if (intraday) {
            const leaders = (d.leaders || []).map((l) => `${l.name}`).join("、");
            return `<b>${p.name}</b><br/>今日加权: ${d.r1}%<br/>中位数: ${d.median}%<br/>` +
              `上涨占比: ${d.up_ratio}% (${d.count}只)<br/>领涨: ${leaders || "-"}<br/>` +
              `<span style="color:#5f7191">点击查看成分股</span>`;
          }
          return `<b>${p.name}</b><br/>近20日: ${d.r20}%<br/>近5日: ${d.r5}%<br/>` +
            `今日: ${d.change_pct ?? "-"}%<br/>主力净流入: ${this.fmtMoney(d.net_inflow)}<br/>` +
            `${d.above_ma20 ? "站上20日线" : "20日线下"}<br/>` +
            `<span style="color:#5f7191">点击查看成分股</span>`;
        } },
        series: [{ type: "treemap", roam: false, nodeClick: "zoomToNode",
          breadcrumb: { show: false },
          label: { show: true, color: "#0b1220", fontWeight: 700,
            formatter: (p) => {
              const w = p.rect ? p.rect.width : 99;
              if (w < 52) return "";
              const v = p.value[1];
              if (w < 78) return `${(v > 0 ? "+" : "") + v}%`;
              return `${p.name}\n${(v > 0 ? "+" : "") + v}%`;
            } },
          upperLabel: { show: false },
          itemStyle: { borderColor: "#fff", borderWidth: 2, gapWidth: 2 },
          emphasis: { label: { show: true } },
          levels: [{ itemStyle: { borderWidth: 0, gapWidth: 3 } }],
          data: items.map((x) => ({
            name: x.name, value: [Math.max(Math.abs(x[key]), 0.5), x[key]],
            itemStyle: {
              color: x[key] > 0 ? "#ff5c6e" : x[key] < 0 ? "#00e5a0" : "#5f7191",
              borderColor: x.code === sel ? "#2f3bff" : "#fff",
              borderWidth: x.code === sel ? 4 : 2,
            },
            ext: x,
          })) }],
      });
      chart.on("click", (p) => {
        if (p.data && p.data.ext) this.loadSectorMembers(p.data.ext);
      });
    },
    renderSectorStocks() {
      const el = this.$refs.sectorChart;
      const chart = EInit(el);
      this.charts.sector = chart;
      const z = this.sectorZoom;
      const stocks = (z.members || []).filter((s) => s.change_pct != null);
      const vmax = Math.max(1, ...stocks.map((s) => Math.abs(s.change_pct || 0)));
      chart.setOption({
        tooltip: { formatter: (p) => {
          const d = p.data.ext || {};
          return `<b>${d.name}</b> ${d.code}<br/>` +
            `现价: ${d.price ?? "-"} · 涨跌: ${(d.change_pct > 0 ? "+" : "") + d.change_pct}%<br/>` +
            `<span style="color:#5f7191">点击查看个股详情</span>`;
        } },
        series: [{ type: "treemap", roam: false, nodeClick: false,
          breadcrumb: { show: false },
          label: { show: true, color: "#0b1220", fontWeight: 700,
            formatter: (p) => {
              const w = p.rect ? p.rect.width : 99;
              if (w < 52) return "";
              const v = p.value[1];
              if (w < 82) return `${(v > 0 ? "+" : "") + v}%`;
              return `${p.name}\n${(v > 0 ? "+" : "") + v}%`;
            } },
          upperLabel: { show: false },
          itemStyle: { borderColor: "#fff", borderWidth: 2, gapWidth: 2 },
          emphasis: { label: { show: true } },
          levels: [{ itemStyle: { borderWidth: 0, gapWidth: 3 } }],
          data: stocks.map((s) => ({
            name: s.name, value: [Math.max(Math.abs(s.change_pct) / vmax * 10, 0.4), s.change_pct],
            itemStyle: { color: s.change_pct > 0 ? "#ff5c6e" : s.change_pct < 0 ? "#00e5a0" : "#5f7191" },
            ext: s,
          })) }],
      });
      chart.on("click", (p) => {
        if (p.data && p.data.ext) this.openDetail({ code: p.data.ext.code, name: p.data.ext.name });
      });
    },
    sectorZoomBack() {
      this.sectorZoom = null;
      this.$nextTick(() => this.renderSectorTreemap());
    },
    async loadSectorMembers(board) {
      this.sectorBoard = board;
      this.sectorMembers = [];
      this.sectorMembersLoading = true;
      this.sectorZoom = null;
      this.renderSectorTreemap();  // 高亮选中板块
      try {
        const d = await API.get(`/api/sectors/${board.code}/members?limit=50`);
        this.sectorMembers = d.items || [];
        // 成分就绪 → 热力图下钻展开
        this.sectorZoom = { code: board.code, name: board.name, members: this.sectorMembers };
        this.$nextTick(() => this.renderSectorTreemap());
      } catch (e) {
        this.$message.error("成分股加载失败: " + String(e.message || e).slice(0, 200));
      } finally { this.sectorMembersLoading = false; }
    },
    async addOneMember(row) {
      try {
        await API.post("/api/watchlist", {
          code: row.code, name: row.name, market: row.market || "auto",
          note: `板块:${(this.sectorBoard || {}).name || ""}`, group_name: "默认",
        });
        this.$message.success(`${row.name} 已入池`);
        this.loadWatchlist();
      } catch (e) {
        this.$message.error(String(e.message || e).slice(0, 200));
      }
    },
    async addSectorMembers() {
      if (!this.sectorMembers.length) return;
      this.sectorAdding = true;
      let ok = 0, fail = 0;
      for (const m of this.sectorMembers.slice(0, 30)) {
        try {
          await API.post("/api/watchlist", {
            code: m.code, name: m.name, market: m.market || "auto",
            note: `板块:${(this.sectorBoard || {}).name || ""}`, group_name: "默认",
          });
          ok++;
        } catch (e) { fail++; }
      }
      this.sectorAdding = false;
      this.$message.success(`入池完成: 成功 ${ok} 只${fail ? `, 失败/重复 ${fail} 只` : ""}`);
      this.loadWatchlist();
    },
    async searchStocks(keyword) {
      const kw = (keyword || "").trim();
      if (!kw) { this.stockDlg.options = []; return; }
      this.stockDlg.searching = true;
      try {
        const d = await API.get("/api/stocks/search?limit=8&keyword=" + encodeURIComponent(kw));
        this.stockDlg.options = (d.items || []).map((it) => ({
          value: it.code + "|" + it.market,
          code: it.code,
          name: it.name,
          market: it.market,
          marketLabel: MARKET_NAMES[it.market] || it.market_type || it.market,
          label: it.name + " " + it.code,
        }));
      } catch (e) {
        this.stockDlg.options = [];
        ElMessage.error(e.message);
      } finally {
        this.stockDlg.searching = false;
      }
    },
    onStockPicked(value) {
      const hit = this.stockDlg.options.find((o) => o.value === value);
      if (hit) {
        this.stockDlg.code = hit.code;
        this.stockDlg.name = hit.name;
        this.stockDlg.market = hit.market;
        this.stockDlg.selected = hit.label;
        this.lookupCode();
        return;
      }
      /* allow-create 手输路径: 直接把输入当作代码, 名称由查询接口自动补全 */
      const raw = String(value || "").split("|")[0].trim().toUpperCase();
      if (raw) {
        this.stockDlg.code = raw;
        this.stockDlg.quote = null;
        this.lookupCode();
      }
    },
    async lookupCode() {
      const code = this.stockDlg.code.trim().toUpperCase();
      if (!code) { ElMessage.warning("请输入股票代码"); return; }
      this.stockDlg.quoteLoading = true;
      try {
        const d = await API.get(`/api/stocks/quote?code=${encodeURIComponent(code)}&market=${this.stockDlg.market}`);
        this.stockDlg.quote = d.quote;
        if (d.quote.name && !this.stockDlg.name) this.stockDlg.name = d.quote.name;
      } catch (e) {
        this.stockDlg.quote = null;
        ElMessage.error(e.message);
      } finally {
        this.stockDlg.quoteLoading = false;
      }
    },
    async saveStock() {
      const dlg = this.stockDlg;
      const code = dlg.code.trim().toUpperCase();
      if (!code) { ElMessage.warning("请先从下拉中选择股票, 或直接输入代码"); return; }
      try {
        if (dlg.mode === "add") {
          await API.post("/api/watchlist", { code, name: dlg.name, note: dlg.note, market: dlg.market,
                                             group_name: dlg.group_name || "默认" });
          ElMessage.success(`已添加 ${code}`);
        } else {
          await API.put(`/api/watchlist/${encodeURIComponent(code)}`, { code, name: dlg.name, note: dlg.note });
          await API.post("/api/watchlist/groups/move", { codes: [code], group: dlg.group_name || "默认" });
          ElMessage.success("已保存修改");
        }
        dlg.visible = false;
        this.loadWatchlist();
      } catch (e) { ElMessage.error(e.message); }
    },
    async removeStock(row) {
      try {
        await this.$confirm(`确定从自选池删除 ${row.name || ""}(${row.code}) 吗?`, "删除确认", { type: "warning" });
      } catch (e) { return; }
      try {
        await API.del(`/api/watchlist/${encodeURIComponent(row.code)}`);
        ElMessage.success("已删除");
        this.loadWatchlist();
      } catch (e) { ElMessage.error(e.message); }
    },

    /* ---------- 详情抽屉 ---------- */
    openDetail(row) {
      const code = row.code || row;
      const name = row.name || (this.watchlistByName[code] || {}).name || code;
      this.detail = {
        visible: true, opened: false, code, name, loading: true,
        klines: [], klineSource: "eastmoney", news: [], anns: [], annsLoading: false,
        history: [], snap: this.analysesByCode[code]?.payload || null,
        fin: this.analysesByCode[code]?.payload?.financials || null,
        confluenceLive: null, rendered: false,
      };
      this.loadDetail(code);
    },
    async loadDetailAnns() {      const d = this.detail;
      if (d.annsLoading || d.anns.length) return;
      d.annsLoading = true;
      try {
        const r = await API.get(`/api/stocks/${encodeURIComponent(d.code)}/announcements?limit=20`);
        d.anns = r.items || [];
        if (!r.ok && !d.anns.length) this.$message.warning("公告加载失败: " + (r.error || "接口异常"));
      } catch (e) {
        this.$message.warning("公告加载失败: " + String(e.message || e).slice(0, 120));
      } finally { d.annsLoading = false; }
    },
    async loadDetail(code) {
      const d = this.detail;
      try {
        const [k, n, h, f] = await Promise.all([
          API.get(`/api/stocks/${encodeURIComponent(code)}/kline?lmt=160`),
          API.get(`/api/stocks/${encodeURIComponent(code)}/news?limit=12`).catch(() => ({ items: [] })),
          API.get(`/api/analyses/${encodeURIComponent(code)}/history?limit=30`).catch(() => ({ items: [] })),
          API.get(`/api/stocks/${encodeURIComponent(code)}/financials`).catch(() => ({ financials: null })),
        ]);
        d.klines = k.klines || [];
        d.klineSource = k.source || "eastmoney";
        if (k.name) d.name = k.name;
        d.news = (n.items || []).slice().sort((x, y) => {
          const px = x.published || "", py = y.published || "";
          if (px !== py) return px < py ? 1 : -1;
          return 0;
        });
        d.history = (h.items || []).slice().reverse();
        d.fin = f.financials || null;
        if (!d.snap?.confluence && d.klines.length >= 30) {
          d.confluenceLive = clientConfluence(d.klines);
        }
        d.loading = false;
        this.tryRenderCharts();
      } catch (e) {
        d.loading = false;
        ElMessage.error(e.message);
      }
    },
    onDetailOpened() {
      this.detail.opened = true;
      this.tryRenderCharts();
    },
    onDetailClosed() {
      Object.values(this.charts).forEach((c) => c && c.dispose && c.dispose());
      this.charts = {};
      this.detail.rendered = false;
      this.detail.opened = false;
    },
    tryRenderCharts() {
      if (!this.detail.opened || this.detail.loading || this.detail.rendered) return;
      this.$nextTick(() => {
        if (this.detail.klines.length) this.renderKlineChart();
        if (this.detail.history.length) this.renderScoreChart();
        this.detail.rendered = true;
      });
    },
    computedInd() {
      const ks = this.detail.klines;
      const closes = ks.map((k) => k.close);
      const m = macdCalc(closes);
      const last = (a) => (a.length ? a[a.length - 1] : null);
      return {
        ma5: last(sma(closes, 5)), ma10: last(sma(closes, 10)),
        ma20: last(sma(closes, 20)), ma60: last(sma(closes, 60)),
        rsi6: last(rsiCalc(closes, 6)), rsi12: last(rsiCalc(closes, 12)),
        rsi24: last(rsiCalc(closes, 24)),
        dif: last(m.dif), dea: last(m.dea), hist: last(m.hist),
      };
    },
    renderKlineChart() {
      const el = this.$refs.klineChart;
      if (!el) return;
      if (this.charts.kline) this.charts.kline.dispose();
      const chart = EInit(el);
      this.charts.kline = chart;
      const ks = this.detail.klines;
      const dates = ks.map((k) => k.date);
      const closes = ks.map((k) => k.close);
      const candle = ks.map((k) => [k.open, k.close, k.low, k.high]);
      const vols = ks.map((k) => ({
        value: k.volume,
        itemStyle: { color: k.close >= k.open ? UP : DOWN },
      }));
      const mas = {
        MA5: sma(closes, 5), MA10: sma(closes, 10),
        MA20: sma(closes, 20), MA60: sma(closes, 60),
      };
      const maColors = { MA5: "#f5c542", MA10: "#22d3ee", MA20: "#c084fc", MA60: "#00e5a0" };
      const macd = macdCalc(closes);
      const rsi = { RSI6: rsiCalc(closes, 6), RSI12: rsiCalc(closes, 12), RSI24: rsiCalc(closes, 24) };
      const grid = [
        { left: 60, right: 20, top: 30, height: "46%" },
        { left: 60, right: 20, top: "60%", height: "10%" },
        { left: 60, right: 20, top: "74%", height: "10%" },
        { left: 60, right: 20, top: "88%", height: "9%" },
      ];
      const xAx = (idx) => ({
        type: "category", data: dates, gridIndex: idx, boundaryGap: true,
        axisLine: { lineStyle: { color: "#c9cdd4" } },
        axisLabel: { show: idx === 3, fontSize: 10 },
        axisTick: { show: false }, splitLine: { show: false },
      });
      // 业界做法(同花顺/TradingView): 大数字压缩为万/亿 + 标签防重叠
      const compact = (v) => {
        const n = Math.abs(v);
        if (n >= 1e8) return (v / 1e8).toFixed(1).replace(/\.0$/, "") + "亿";
        if (n >= 1e4) return (v / 1e4).toFixed(0) + "万";
        return String(Math.round(v));
      };
      const yAx = (idx, name, fmt) => ({
        type: "value", gridIndex: idx, scale: true, name,
        nameTextStyle: { fontSize: 10, color: "#5f7191" },
        axisLabel: { fontSize: 10, hideOverlap: true,
                     formatter: fmt || ((v) => String(v)) },
        splitLine: { lineStyle: { color: "rgba(120,160,220,.08)" } },
      });
      const zoomX = { type: "inside", xAxisIndex: [0, 1, 2, 3], start: 55, end: 100 };
      const series = [
        {
          name: "日K", type: "candlestick", data: candle, xAxisIndex: 0, yAxisIndex: 0,
          itemStyle: { color: UP, color0: DOWN, borderColor: UP, borderColor0: DOWN },
        },
        ...Object.entries(mas).map(([name, data]) => ({
          name, type: "line", data, xAxisIndex: 0, yAxisIndex: 0,
          symbol: "none", lineStyle: { width: 1, color: maColors[name] },
          itemStyle: { color: maColors[name] },
        })),
        { name: "成交量", type: "bar", data: vols, xAxisIndex: 1, yAxisIndex: 1 },
        {
          name: "MACD", type: "bar", data: macd.hist, xAxisIndex: 2, yAxisIndex: 2,
          itemStyle: { color: (p) => (p.value >= 0 ? UP : DOWN) },
        },
        { name: "DIF", type: "line", data: macd.dif, xAxisIndex: 2, yAxisIndex: 2, symbol: "none", lineStyle: { width: 1, color: "#22d3ee" } },
        { name: "DEA", type: "line", data: macd.dea, xAxisIndex: 2, yAxisIndex: 2, symbol: "none", lineStyle: { width: 1, color: "#f5c542" } },
        ...Object.entries(rsi).map(([name, data], i) => ({
          name, type: "line", data, xAxisIndex: 3, yAxisIndex: 3, symbol: "none",
          lineStyle: { width: 1, color: ["#f5c542", "#22d3ee", "#c084fc"][i] },
        })),
      ];
      chart.setOption({
        animation: false,
        tooltip: {
          trigger: "axis", axisPointer: { type: "cross" },
          backgroundColor: "#0d1728", borderColor: "rgba(34,211,238,.35)",
          textStyle: { color: "#e6edf7", fontSize: 12 },
        },
        axisPointer: { link: [{ xAxisIndex: "all" }] },
        legend: {
          top: 2, left: 60, itemWidth: 14, itemHeight: 8, textStyle: { fontSize: 11 },
          data: ["日K", "MA5", "MA10", "MA20", "MA60", "DIF", "DEA", "RSI6", "RSI12", "RSI24"],
        },
        grid, xAxis: [0, 1, 2, 3].map(xAx), yAxis: [
          yAx(0, ""), yAx(1, "成交量(手)", compact), yAx(2, "MACD"), yAx(3, "RSI"),
        ],
        dataZoom: [zoomX, {
          type: "slider", xAxisIndex: [0, 1, 2, 3], bottom: 2, height: 14,
          start: 55, end: 100, borderColor: "#e5e6eb",
        }],
        series,
      });
      window.addEventListener("resize", this._klineResize = () => chart.resize());
    },
    renderScoreChart() {
      const el = this.$refs.scoreChart;
      if (!el) return;
      if (this.charts.score) this.charts.score.dispose();
      const chart = EInit(el);
      this.charts.score = chart;
      const items = this.detail.history;
      chart.setOption({
        animation: false,
        grid: { left: 44, right: 16, top: 24, bottom: 24 },
        tooltip: {
          trigger: "axis",
          formatter: (ps) => {
            const p = ps[0];
            const it = items[p.dataIndex];
            return `${p.axisValue}<br/>评分 <b>${p.value}</b> (${it.payload?.signal || "-"})<br/>价格 ${it.payload?.price ?? "-"}`;
          },
        },
        xAxis: {
          type: "category", data: items.map((h) => new Date(h.ts * 1000).toLocaleDateString("zh-CN")),
          axisLabel: { fontSize: 10 },
        },
        yAxis: { type: "value", min: 0, max: 100 },
        visualMap: {
          show: false, dimension: 0, seriesIndex: 0,
          pieces: [{ lte: 35, color: DOWN }, { gt: 35, lt: 65, color: "#f5c542" }, { gte: 65, color: UP }],
        },
        series: [{
          name: "评分", type: "line", data: items.map((h) => h.payload?.score),
          symbolSize: 5, lineStyle: { width: 2 },
          markLine: {
            silent: true, symbol: "none", label: { fontSize: 10 },
            data: [{ yAxis: 65, name: "偏多" }, { yAxis: 35, name: "偏空" }],
            lineStyle: { type: "dashed", color: "#c9cdd4" },
          },
        }],
      });
    },

    /* ---------- 设置 ---------- */
    applyPreset(key) {
      const p = (this.cfg.smtp_presets || {})[key];
      if (!p) return;
      this.smtpPreset = key;
      this.cfg.smtp_host = p.smtp_host;
      this.cfg.smtp_port = p.smtp_port;
      this.cfg.smtp_ssl = p.smtp_ssl;
    },
    async saveSettings(silent = false) {
      this.savingSettings = true;
      try {
        const body = { ...this.cfg };
        delete body.smtp_presets;
        delete body.ai_calls_today;
        body.mail_to = this.mailToText.split(/[\n,;，；]/).map((s) => s.trim()).filter(Boolean);
        const d = await API.put("/api/settings", body);
        this.cfg = d.settings;
        this.mailToText = (d.settings.mail_to || []).join("\n");
        if (!silent) ElMessage.success("设置已保存");
        return true;
      } catch (e) {
        ElMessage.error(e.message);
        return false;
      } finally { this.savingSettings = false; }
    },
    async testEmail() {
      const hasTo = this.mailToText.split(/[\n,;，；]/).map((s) => s.trim()).filter(Boolean).length;
      if (!hasTo) {
        ElMessage.warning("请先在「收件邮箱(每行一个)」中填写收件地址, 例如你自己的邮箱");
        return;
      }
      if (!(await this.saveSettings(true))) return;
      try {
        await API.post("/api/settings/test-email");
        ElMessage.success("测试邮件发送成功, 请查收");
      } catch (e) { ElMessage.error(e.message); }
    },
    async testAI() {
      if (!(await this.saveSettings(true))) return;
      try {
        const d = await API.post("/api/settings/test-ai");
        ElMessage.success(`AI 连接成功, 模型回复: ${d.reply || "OK"}`);
      } catch (e) { ElMessage.error(e.message); }
    },
  },
});

app.use(ElementPlus, { locale: ElementPlusLocaleZhCn });
window.__AD__ = app.mount("#app");
