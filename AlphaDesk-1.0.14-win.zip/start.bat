@echo off
chcp 65001 >nul
REM AlphaDesk 启动器: 双击即用
cd /d "%~dp0AlphaDesk"

if not exist "AlphaDesk.exe" (
  echo [错误] 没找到 AlphaDesk.exe
  echo 请确认解压完整, 且路径不要有中文/特殊字符, 然后重试。
  pause
  exit /b 1
)

echo 正在启动 AlphaDesk ...
start "" "AlphaDesk.exe"

REM 等待服务就绪(最多 60 秒), 就绪后自动打开浏览器由程序负责;
REM 这里只做兜底提示, 避免"浏览器打开了但服务没起来"的困惑。
set /a N=0
:wait
set /a N+=1
powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',8200);$c.Close();exit 0}catch{exit 1}" >nul 2>&1
if %errorlevel%==0 goto ready
if %N% GEQ 60 goto timeout
timeout /t 1 /nobreak >nul
goto wait

:ready
echo AlphaDesk 已就绪: http://127.0.0.1:8200
exit /b 0

:timeout
echo.
echo [提示] 等了一分钟服务还没起来, 可能被安全软件拦截或启动异常。
echo   1) 看本目录 AlphaDesk\logs\alphadesk.log 末尾的报错
echo   2) 若杀毒/Windows Defender 拦截, 请把整个文件夹加白名单后重试
echo   3) 确认 8200 端口没被别的程序占用
echo 然后重新双击 start.bat。
pause
exit /b 1
