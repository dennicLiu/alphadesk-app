#!/bin/bash
# AlphaDesk 启动器: 双击即用
cd "$(dirname "$0")/AlphaDesk" || exit 1
./AlphaDesk
