#!/bin/bash
# AlphaDesk 启动器: chmod +x start.sh 后双击或 ./start.sh
cd "$(dirname "$0")/AlphaDesk" || exit 1
./AlphaDesk
