@echo off
REM AlphaDesk 启动器: 双击即用
cd /d "%~dp0AlphaDesk"
start "" AlphaDesk.exe
