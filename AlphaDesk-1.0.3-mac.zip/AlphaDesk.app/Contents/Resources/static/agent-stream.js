// SSE 流式智能体客户端: fetch + ReadableStream 解析 event/data
// 用法: AgentStream.send({text, history, onEvent})
(function () {
  function parseChunk(buf) {
    var events = [];
    var idx;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      var raw = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      var kind = "message";
      var dataLines = [];
      var lines = raw.split("\n");
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.indexOf("event:") === 0) kind = line.slice(6).trim();
        else if (line.indexOf("data:") === 0) dataLines.push(line.slice(5).trim());
      }
      var data = {};
      try { data = JSON.parse(dataLines.join("\n") || "{}"); } catch (e) { data = {}; }
      events.push({ kind: kind, data: data });
    }
    return { events: events, rest: buf };
  }

  function stream(opt) {
    var qs = new URLSearchParams({
      text: opt.text || "",
      history: JSON.stringify(opt.history || []),
    });
    return fetch("/api/agent/chat_stream?" + qs.toString(), {
      headers: { Accept: "text/event-stream" },
      signal: opt.signal,
    }).then(function (res) {
      if (!res.ok || !res.body) throw new Error("HTTP " + res.status);
      var reader = res.body.getReader();
      var dec = new TextDecoder();
      var buf = "";
      function pump() {
        return reader.read().then(function (r) {
          if (r.done) {
            if (buf.trim()) {
              var tail = parseChunk(buf + "\n\n");
              tail.events.forEach(function (ev) { opt.onEvent && opt.onEvent(ev.kind, ev.data); });
            }
            return;
          }
          buf += dec.decode(r.value, { stream: true });
          var parsed = parseChunk(buf);
          buf = parsed.rest;
          parsed.events.forEach(function (ev) { opt.onEvent && opt.onEvent(ev.kind, ev.data); });
          return pump();
        });
      }
      return pump();
    });
  }

  window.AgentStream = { send: stream };
})();
